﻿using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Enums.Booking;
using Microsoft.Extensions.DependencyInjection;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;
using Newtonsoft.Json;
using Scheduler.CrossCutting.Models.Entities;
using System.Linq;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Enums.RatePlan;
//using Microsoft.Extensions.Configuration;

namespace PPG.Scheduler.Implementation.ScheduleTasks.BookingFailUpdateStatus
{
    public class UpdateBookingStatusTask : IUpdateBookingStatusTask
    {
        IDatabaseUnitOfWork UnitOfWork { get; }
        private readonly IServiceScopeFactory _serviceScopeFactory;

        IConfiguration Configuration { get; }
        static IServiceProvider ServiceProvider { get; set; }
        public UpdateBookingStatusTask(IDatabaseUnitOfWork unitOfWork, IServiceProvider services, IConfiguration configuration)
        {
            UnitOfWork = unitOfWork;
            ServiceProvider = services;
            Configuration = configuration;
        }
        public Task UpdateFailStatus()
        {
            var scopedProcessingService = ServiceProvider.GetRequiredService<IDatabaseUnitOfWork>();
            ServiceProvider.GetRequiredService<IPropertyRepository>();
            ServiceProvider.GetRequiredService<IServiceRepository>();
            ServiceProvider.GetRequiredService<IAncillaryRepositary>();
            ServiceProvider.GetRequiredService<ITaxesRepository>();
            ServiceProvider.GetRequiredService<IRatePlanRepository>();
            ServiceProvider.GetRequiredService<IUserLogRepository>();
            ServiceProvider.GetRequiredService<IRoleClaimRepository>();
            ServiceProvider.GetRequiredService<IPropertyRepository>();
            ServiceProvider.GetRequiredService<IRoomClassRepository>();
            ServiceProvider.GetRequiredService<IAncillaryRatePlanRepository>();
            ServiceProvider.GetRequiredService<ITaxTypeRepository>();
            ServiceProvider.GetRequiredService<IChannelRepository>();
            ServiceProvider.GetRequiredService<ITaxesRepository>();
            ServiceProvider.GetRequiredService<ITaxesRatePlansRepository>();
            ServiceProvider.GetRequiredService<IRatePlanRepository>();
            ServiceProvider.GetRequiredService<IRatePlanParamRepository>();
            ServiceProvider.GetRequiredService<IInventoryPricingRepository>();
            ServiceProvider.GetRequiredService<IInventoryAvailabilityRepository>();
            ServiceProvider.GetRequiredService<ITermsAndConditionsRepository>();
            ServiceProvider.GetRequiredService<IInventoryRuleRepository>();
            ServiceProvider.GetRequiredService<IChannelServiceRateRepository>();
            ServiceProvider.GetRequiredService<IBookingsRepository>();
            ServiceProvider.GetRequiredService<IBookingServicesRepository>();
            ServiceProvider.GetRequiredService<IBookingAncillaryRepository>();
            ServiceProvider.GetRequiredService<IBookingGuestsRepository>();
            ServiceProvider.GetRequiredService<IOTAServiceRateRepository>();
            ServiceProvider.GetRequiredService<ITermsAndConditionsLinkedRatesRepository>();
            ServiceProvider.GetRequiredService<IUserPropertyMappingRepository>();
            ServiceProvider.GetRequiredService<IRatePlanServiceRepository>();

            ServiceProvider.GetRequiredService<IPromoCodeRepository>();
            //ServiceProvider.GetRequiredService<icompa>();

            var interval = Convert.ToInt32(Configuration.ConfigSettings.BookingFailUpdate.UpdateInterval);
            var maxInterval = Convert.ToInt32(Configuration.ConfigSettings.BookingFailUpdate.MaxInterval);


            //var testbookings = scopedProcessingService.Bookings.List(x => (x.Status == BookingStatus.PaymentPending
            //                            || x.Status == BookingStatus.PaymentError)
            //                            && ((DateTime.Now - x.BookingDate).TotalMinutes >= interval)
            //                                && ((DateTime.Now - x.BookingDate).TotalMinutes < interval + maxInterval),
            //                                y => y.Services);

            //foreach (var book in testbookings)
            //{
            //    var logDetails = new LogDetails();
            //    logDetails = GetLogDetails(null);
            //    var fromtime = DateTime.Now.Subtract(book.BookingDate);
            //    //var totime = 
            //    logDetails.Message = $"[First Booking]from time: {fromtime.TotalMinutes.ToString()}";// +
            //        //$"to tome: {DateTime.Now - book.BookingDate < TimeSpan.FromMinutes(interval + 20)}\n\n";
            //    Logger.WriteUsage(logDetails);
            //}


            var bookingDetails = scopedProcessingService.Bookings.List(x => (x.Status == BookingStatus.PaymentPending)
                                    && ((DateTime.Now.Subtract(x.BookingDate)).TotalMinutes >= interval)
                                        && ((DateTime.Now.Subtract(x.BookingDate)).TotalMinutes < interval + maxInterval),
                                        y => y.Services);

            var minSlot = DateTime.MinValue;
            var maxSlot = DateTime.MinValue;


            foreach (var booking in bookingDetails)
            {
                try
                {
                    if (booking.Services != null)
                    {
                        foreach (var service in booking.Services)
                        {

                            //Get Distinct dates from slots
                            var dateSlots = JsonConvert.DeserializeObject<List<BookingServicesSlotsDto>>(service.Slots);
                            var dates = dateSlots.Select(x => Convert.ToDateTime(x.DateSlot)).Distinct();

                            var inventoryEntity = scopedProcessingService.InventoryAvailability.List(x => dates.Contains(x.InvDate.Date)
                                && x.PropertyId == booking.PropertyId && x.RatePlanId == service.RatePlanId && x.ServiceId == service.ServiceId
                                );

                            foreach (var slot in dateSlots)
                            {
                                var dateSlot = Convert.ToDateTime(slot.DateSlot);
                                var timeSlot = slot.TimeSlot;

                                var inventoryAndPriceData = JsonConvert.DeserializeObject<IList<InventoryAndPriceData>>(inventoryEntity.Where(x => x.InvDate.Date == dateSlot).FirstOrDefault().Data);
                                var inventory = inventoryAndPriceData.Where(x => x.TimeSlot == timeSlot).FirstOrDefault();

                                if (PolicyPricing.PerRoom == service.PricingType)
                                {
                                    inventoryAndPriceData.Where(x => x.TimeSlot == timeSlot).FirstOrDefault().InvPriceCount
                                        = (Convert.ToInt32(inventory.InvPriceCount) + 1).ToString();

                                }
                                else
                                {
                                    inventoryAndPriceData.Where(x => x.TimeSlot == timeSlot).FirstOrDefault().InvPriceCount
                                    = (Convert.ToInt32(inventory.InvPriceCount) + Convert.ToInt32(service.AdultCount + service.Child1Count + service.Child2Count)).ToString();
                                }
                                scopedProcessingService.InventoryAvailability.SingleOrDefault(x => x.InvDate == dateSlot
                                && x.PropertyId == booking.PropertyId && x.RatePlanId == service.RatePlanId && x.ServiceId == service.ServiceId
                                ).Data = JsonConvert.SerializeObject(inventoryAndPriceData);

                            }

                        }
                    }

                    //Update the promo redeemption count in case of payment pending/failure
                    var promoModel = scopedProcessingService.PromoCodes.SingleOrDefault(x => x.PromoCodeName.ToUpper() == booking.PromoCode.ToUpper());
                    if (promoModel != null)
                    {
                        promoModel.RedeemedCount--;
                    }


                }
                catch (Exception ex)
                {
                    var logDetails = new LogDetails();
                    logDetails = GetLogDetails(ex);
                    Logger.WriteError(logDetails);
                }


                booking.Status = BookingStatus.PaymentFailed;
            }


            //scopedProcessingService.Bookings.Update(bookingModel);
            scopedProcessingService.SaveChanges();

            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Service",
                Location = "UpdateBookingStatusTask.cs",
                Hostname = Environment.MachineName,
                Message = ex != null ? ex.Message : string.Empty,
                UserName = Environment.UserName,
                Excep = ex
            };
        }



    }
}
