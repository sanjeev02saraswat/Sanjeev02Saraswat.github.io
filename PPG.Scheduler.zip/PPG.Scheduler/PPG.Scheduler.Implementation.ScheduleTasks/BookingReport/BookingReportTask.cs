﻿using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Enums.Booking;
using Microsoft.Extensions.DependencyInjection;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;
using Newtonsoft.Json;
using Scheduler.CrossCutting.Models.Entities;
using System.Linq;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using System.IO;
using System.Net;
using Microsoft.AspNetCore.Hosting;
using PPG.Scheduler.Implementation.ScheduleTasks.ExcelHandler;
using System.Net.Http;
using Scheduler.CrossCutting.Models;
using Scheduler.Infrastructure.AWS.SES;
using MySql.Data.MySqlClient;
using Dapper;
using System.Data;

namespace PPG.Scheduler.Implementation.ScheduleTasks.BookingReport
{
    public class BookingReportTask : IBookingReportTask
    {
        IDatabaseUnitOfWork UnitOfWork { get; }

        IConfiguration Configuration { get; }

        IHostingEnvironment Environment { get; }

        static IServiceProvider ServiceProvider { get; set; }

        private string connection = string.Empty;

        public BookingReportTask(IDatabaseUnitOfWork unitOfWork, IServiceProvider services, IConfiguration configuration, IHostingEnvironment environment)
        {
            UnitOfWork = unitOfWork;
            ServiceProvider = services;
            Configuration = configuration;
            Environment = environment;
            connection = Configuration.ConfigSettings.ConnectionStringsConfig.DatabaseContext;
        }

        public async Task SendBookingReportToJon()
        {
            DateTime Today = DateTime.Now;
            var NewDate = new DateTime(Today.Year, Today.Month, 22);
            var dateParameter = NewDate.ToString("yyyy-MM-dd");
            try
            {
                SqlReader reader = new SqlReader(Environment);
                var SQL = reader.FetchReportForJon();
                SQL = SQL.Replace("{dateParameter}", dateParameter);
                List<BookingReportForJonDto> T = new List<BookingReportForJonDto>();
                using (var con = new MySqlConnection(connection))
                {
                    T = con.Query<BookingReportForJonDto>(
                        sql: SQL,
                        commandTimeout: 60,
                        commandType: CommandType.Text
                        ).ToList();
                }
                BookingReportExcelHandler handler = new BookingReportExcelHandler(Configuration, Environment);
                handler.CreateBookingReportForJon(T);
                BookingReportEmailBuilder builder = new BookingReportEmailBuilder(Configuration, Environment);
                await builder.SendMailMessageForJon();
            }
            catch (Exception xe)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(xe);
                Logger.WriteError(logDetails);
            }
        }

        public async Task SendBookingReportToEsther()
        {
            DateTime Today = DateTime.UtcNow;
            var CurrentMonth = Today.Month;
            var CurrentYear = Today.Year;

            //DateTime JonBookingReportDate = DateTime.MinValue;
            DateTime EstherBookingReportDate = DateTime.MinValue;

            if (Configuration.ConfigSettings.EstherReportConfig.Day != "*")
            {
                //JonBookingReportDate = new DateTime(Today.Year, Today.Month, Convert.ToInt32(Configuration.ConfigSettings.JonReportConfig.Day));
                EstherBookingReportDate = new DateTime(CurrentYear, CurrentMonth, Convert.ToInt32(Configuration.ConfigSettings.EstherReportConfig.Day));
            }
            try
            {
                if (CurrentMonth == 1)
                {
                    CurrentYear = CurrentYear - 1;
                    CurrentMonth = 13;
                }
                var FirstDayOfPreviousMonth = new DateTime(CurrentYear, CurrentMonth - 1, 1).ToString("yyyy-MM-dd");
                var LarastDayOfPreviousMonth = new DateTime(CurrentYear, CurrentMonth - 1, DateTime.DaysInMonth(CurrentYear, CurrentMonth - 1)).ToString("yyyy-MM-dd");
                List<BookingReportForEstherDto> T = new List<BookingReportForEstherDto>();

                var result = GetBookingReportData(FirstDayOfPreviousMonth, LarastDayOfPreviousMonth).GetAwaiter().GetResult();

                if (result.IsSuccessStatusCode)
                {
                    T = JsonConvert.DeserializeObject<List<BookingReportForEstherDto>>(result.Content.ReadAsStringAsync().Result);
                    BookingReportExcelHandler handler = new BookingReportExcelHandler(Configuration, Environment);
                    handler.CreateBookingReportForEsther(T);
                    BookingReportEmailBuilder builder = new BookingReportEmailBuilder(Configuration, Environment);
                    if (Today.Date.Equals(EstherBookingReportDate.Date))
                    {
                        await builder.SendMailMessageForEsther();
                    }
                    //To Check on UAT Env
                    if (Configuration.ConfigSettings.EstherReportConfig.Day == "*")
                    {
                        await builder.SendMailMessageForEsther();
                    }
                }
                else
                {
                    var logDetails = new LogDetails();
                    logDetails = new LogDetails
                    {
                        Project = System.Environment.CurrentDirectory,
                        Layer = "PPG.Scheduler.Implementation.ScheduleTasks.BookingReport",
                        Location = "BookingReport.cs",
                        Hostname = System.Environment.MachineName,
                        Message = "0 row found OR Result is not get successfully",
                        UserName = System.Environment.UserName,
                        Excep = null
                    };
                    Logger.WriteError(logDetails);
                }
                
            }
            catch (Exception xe)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(xe);
                Logger.WriteError(logDetails);
            }
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = System.Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Implementation.ScheduleTasks",
                Location = "BookingReport.cs",
                Hostname = System.Environment.MachineName,
                Message = ex != null ? ex.Message : string.Empty,
                UserName = System.Environment.UserName,
                Excep = ex
            };
        }

        public async Task<HttpResponseMessage> GetBookingReportData(string fromDate, string toDate)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(Configuration.ConfigSettings.IBConfigSettings.BackOfficeApiEndPoint);
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                var url = string.Format("api/v1/BookingReport/getBookingReport?dateForm={0}&dateTo={1}", fromDate, toDate);
                return await client.GetAsync(url);
            }
        }

    }


}
