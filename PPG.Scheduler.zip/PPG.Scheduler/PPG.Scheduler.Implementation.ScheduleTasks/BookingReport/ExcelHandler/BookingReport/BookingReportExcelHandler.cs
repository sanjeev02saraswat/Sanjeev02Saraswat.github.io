﻿using Microsoft.AspNetCore.Hosting;
//using Microsoft.Extensions.Configuration;
using Scheduler.CrossCutting.Configuration;
using NPOI.HSSF.Util;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using Scheduler.CrossCutting.Models.DTOs;
using System;
using System.Collections.Generic;
using System.IO;
using Scheduler.CrossCutting.Models;
using System.Net.Http;
using System.Threading.Tasks;


namespace PPG.Scheduler.Implementation.ScheduleTasks.ExcelHandler
{
    public class BookingReportExcelHandler : BaseFileHandler
    {
        IConfiguration Configuration;
        IHostingEnvironment Environment;

        public BookingReportExcelHandler(IConfiguration _configuration, IHostingEnvironment _environment)
        {
            Configuration = _configuration;
            Environment = _environment;
        }

        public string CreateBookingReportForJon(List<BookingReportForJonDto> li)
        {
            string url = string.Empty;
            string filePath = string.Empty;
            //string FileName = @"\BookingReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".csv";
            string FileName = @"\BookingReport_" + DateTime.Now.ToString("YYYYDDMM") + ".csv";

            try
            {
                filePath = Path.Combine(Environment.WebRootPath, "Reports", "Jon");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                DeleteFiles(filePath);
                if (File.Exists(filePath + FileName))
                {
                    File.Delete(filePath + FileName);
                }
                //var v = new FileInfo(filePath + FileName);
                using (var fs = new FileStream(filePath + FileName, FileMode.Create, FileAccess.Write))
                {

                    IWorkbook workbook = new XSSFWorkbook();
                    ISheet Worksheet = workbook.CreateSheet("Bookings");

                    #region Header
                    IRow HeaderRow = Worksheet.CreateRow(0);
                    HeaderRow.CreateCell(0).SetCellValue("OrderRefNo");
                    HeaderRow.CreateCell(1).SetCellValue("BookingDate");
                    HeaderRow.CreateCell(2).SetCellValue("MaxSlotEndTime");
                    HeaderRow.CreateCell(3).SetCellValue("MinSlotStartTime");
                    HeaderRow.CreateCell(4).SetCellValue("PaymentID");
                    HeaderRow.CreateCell(5).SetCellValue("PaymentTransactionID");
                    HeaderRow.CreateCell(6).SetCellValue("FirstName");
                    HeaderRow.CreateCell(7).SetCellValue("LastName");
                    HeaderRow.CreateCell(8).SetCellValue("Email");
                    HeaderRow.CreateCell(9).SetCellValue("Transaction Amount Paid (USD)");
                    #endregion

                    #region Body
                    for (int i = 0; i < li.Count; i++)
                    {
                        IRow row = Worksheet.CreateRow(i + 1);
                        row.CreateCell(0).SetCellValue(li[i].OrderRefNo);
                        row.CreateCell(1).SetCellValue(li[i].BookingDate.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(2).SetCellValue(li[i].MaxSlotEndTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(3).SetCellValue(li[i].MinSlotStartTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(4).SetCellValue(li[i].PaymentID);
                        row.CreateCell(5).SetCellValue(li[i].PaymentTransactionID);
                        row.CreateCell(6).SetCellValue(li[i].FirstName);
                        row.CreateCell(7).SetCellValue(li[i].LastName);
                        row.CreateCell(8).SetCellValue(li[i].Email);
                        row.CreateCell(9).SetCellValue(li[i].TxnAmt);
                    }
                    #endregion

                    #region Sheet Style
                    IFont HeaderFont = workbook.CreateFont();
                    HeaderFont.IsBold = true;
                    HeaderFont.Boldweight = (short)FontBoldWeight.Bold;
                    XSSFCellStyle HeaderStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    HeaderStyle.FillPattern = FillPattern.SolidForeground;
                    HeaderStyle.SetFont(HeaderFont);
                    HeaderStyle.FillForegroundColor = IndexedColors.LightYellow.Index;
                    //HeaderRow.RowStyle = HeaderStyle;
                    int ColumnCount = typeof(BookingReportForJonDto).GetProperties().Length;
                    for (int i = 0; i < ColumnCount; i++)
                    {
                        HeaderRow.Cells[i].CellStyle = HeaderStyle;
                        Worksheet.AutoSizeColumn(i);
                    }
                    #endregion

                    workbook.Write(fs);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return url;
        }

        public string CreateBookingReportForEsther(List<BookingReportForEstherDto> li)
        {
            string url = string.Empty;
            string filePath = string.Empty;
            string FileName = @"\BookingReport_" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
             
            try
            {
                filePath = Path.Combine(Environment.WebRootPath, "Reports", "Esther");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                DeleteFiles(filePath);
                if (File.Exists(filePath + FileName))
                {
                    File.Delete(filePath + FileName);
                }
                using (var fs = new FileStream(filePath + FileName, FileMode.Create, FileAccess.Write))
                {
                    IWorkbook workbook = new XSSFWorkbook();
                    ISheet Worksheet = workbook.CreateSheet("Bookings");

                    #region Header
                    IRow HeaderRow = Worksheet.CreateRow(0);
                    HeaderRow.CreateCell(0).SetCellValue("OrderRefNo");
                    HeaderRow.CreateCell(1).SetCellValue("BookingDate (GMT +8)");
                    HeaderRow.CreateCell(2).SetCellValue("ServiceName");
                    HeaderRow.CreateCell(3).SetCellValue("MinSlotStartTime");
                    HeaderRow.CreateCell(4).SetCellValue("MaxSlotEndTime");
                    HeaderRow.CreateCell(5).SetCellValue("PaymentID");
                    HeaderRow.CreateCell(6).SetCellValue("PaymentTransactionID");
                    HeaderRow.CreateCell(7).SetCellValue("PaymentCurrency");
                    HeaderRow.CreateCell(8).SetCellValue("PaymentAmount");
                    HeaderRow.CreateCell(9).SetCellValue("TotalServicePrice");
                    HeaderRow.CreateCell(10).SetCellValue("PromoCode");
                    HeaderRow.CreateCell(11).SetCellValue("PromoCode Value");
                    HeaderRow.CreateCell(12).SetCellValue("PropertyCurrency");
                    HeaderRow.CreateCell(13).SetCellValue("PropertyCurrencyAmount");
                    HeaderRow.CreateCell(14).SetCellValue("DefaultCurrency");
                    HeaderRow.CreateCell(15).SetCellValue("DefaultCurrencyAmount");
                    HeaderRow.CreateCell(16).SetCellValue("FirstName");
                    HeaderRow.CreateCell(17).SetCellValue("LastName");
                    HeaderRow.CreateCell(18).SetCellValue("CountryofResidence");
                    HeaderRow.CreateCell(19).SetCellValue("Source");
                    HeaderRow.CreateCell(20).SetCellValue("Status");
                    HeaderRow.CreateCell(21).SetCellValue("GuestCount");
                    HeaderRow.CreateCell(22).SetCellValue("AdultCount");
                    HeaderRow.CreateCell(23).SetCellValue("ChildCount");
                    HeaderRow.CreateCell(24).SetCellValue("TravelType");
                    HeaderRow.CreateCell(25).SetCellValue("UserIP");
                    HeaderRow.CreateCell(26).SetCellValue("AirlineCode");
                    HeaderRow.CreateCell(27).SetCellValue("AirlineName");
                    HeaderRow.CreateCell(28).SetCellValue("FlightNumber");
                    HeaderRow.CreateCell(29).SetCellValue("Email");
                    HeaderRow.CreateCell(30).SetCellValue("RatePlanName");
                    #endregion

                    #region Body
                    for (int i = 0; i < li.Count; i++)
                    {
                        IRow row = Worksheet.CreateRow(i + 1);
                        row.CreateCell(0).SetCellValue(li[i].OrderRefNo);
                        row.CreateCell(1).SetCellValue(li[i].BookingDate.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(2).SetCellValue(li[i].ServiceName);
                        row.CreateCell(3).SetCellValue(li[i].MinSlotStartTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(4).SetCellValue(li[i].MaxSlotEndTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(5).SetCellValue(li[i].PaymentId);
                        row.CreateCell(6).SetCellValue(li[i].PaymentTransactionID);
                        row.CreateCell(7).SetCellValue(li[i].PaymentCurrency);
                        row.CreateCell(8).SetCellValue(Convert.ToDouble(li[i].PaymentAmount));
                        row.CreateCell(9).SetCellValue(Convert.ToDouble(li[i].TotalServicePrice));
                        row.CreateCell(10).SetCellValue(li[i].PromoCode);
                        row.CreateCell(11).SetCellValue(li[i].PromoCodeValue);
                        row.CreateCell(12).SetCellValue(li[i].PropertyCurrency);
                        row.CreateCell(13).SetCellValue(Convert.ToDouble(li[i].PropertyCurrencyAmount));
                        row.CreateCell(14).SetCellValue(li[i].DefaultCurrency);
                        row.CreateCell(15).SetCellValue(Convert.ToDouble(li[i].DefaultCurrencyAmount));
                        row.CreateCell(16).SetCellValue(li[i].FirstName);
                        row.CreateCell(17).SetCellValue(li[i].LastName);
                        row.CreateCell(18).SetCellValue(li[i].CountryofResidence);
                        row.CreateCell(19).SetCellValue(li[i].Source);
                        row.CreateCell(20).SetCellValue(li[i].Status);
                        row.CreateCell(21).SetCellValue(li[i].GuestCount);
                        row.CreateCell(22).SetCellValue(li[i].AdultCount);
                        row.CreateCell(23).SetCellValue(li[i].ChildCount);
                        row.CreateCell(24).SetCellValue(li[i].TravelType);
                        row.CreateCell(25).SetCellValue(li[i].UserIP);
                        row.CreateCell(26).SetCellValue(li[i].AirlineCode);
                        row.CreateCell(27).SetCellValue(li[i].AirlineName);
                        row.CreateCell(28).SetCellValue(li[i].FlightNumber);
                        row.CreateCell(29).SetCellValue(li[i].Email);
                        row.CreateCell(30).SetCellValue(li[i].RatePlanName);
                    }
                    #endregion

                    #region Sheet Style
                    IFont HeaderFont = workbook.CreateFont();
                    HeaderFont.IsBold = true;
                    XSSFCellStyle HeaderStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    HeaderStyle.FillPattern = FillPattern.SolidForeground;
                    HeaderStyle.SetFont(HeaderFont);
                    HeaderStyle.FillForegroundColor = IndexedColors.LightYellow.Index;
                    //HeaderRow.RowStyle = HeaderStyle;
                    int ColumnCount = typeof(BookingReportForEstherDto).GetProperties().Length;
                    for (int i = 0; i < ColumnCount; i++)
                    {
                        HeaderRow.Cells[i].CellStyle = HeaderStyle;
                        Worksheet.AutoSizeColumn(i);
                    }
                    #endregion

                    workbook.Write(fs);
                    workbook.Close();
                }
            }
            catch (Exception xe)
            {
                throw;
            }
            return url;
        }

        public string CreateServiceLevelBookingReport(List<ServiceLevelReportDto> li)
        {
            string url = string.Empty;
            string filePath = string.Empty;            
            string FileName = @"\ServiceLevelBookingReport_" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx";
            //string FileName = @"\ServiceLevelBookingReport_" + DateTime.Now.ToString("yyyyMMdd") + ".csv";

            try
            {
                filePath = Path.Combine(Environment.WebRootPath, "Reports", "ServiceLevelBookingReport");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                DeleteFiles(filePath);
                if (File.Exists(filePath + FileName))
                {
                    File.Delete(filePath + FileName);
                }
                //var v = new FileInfo(filePath + FileName);
                using (var fs = new FileStream(filePath + FileName, FileMode.Create, FileAccess.Write))
                {

                    IWorkbook workbook = new XSSFWorkbook();
                    ISheet Worksheet = workbook.CreateSheet("Service Level Bookings");

                    #region Header
                    IRow HeaderRow = Worksheet.CreateRow(0);
                    HeaderRow.CreateCell(0).SetCellValue("Brand");
                    HeaderRow.CreateCell(1).SetCellValue("Booking");
                    HeaderRow.CreateCell(2).SetCellValue("Creation Date And Time (GMT +8)");
                    HeaderRow.CreateCell(3).SetCellValue("Stay Duration (Hours)");
                    HeaderRow.CreateCell(4).SetCellValue("Service Category");
                    HeaderRow.CreateCell(5).SetCellValue("Core/Ancillary");
                    HeaderRow.CreateCell(6).SetCellValue("Service Booked");
                    HeaderRow.CreateCell(7).SetCellValue("Room/Service Quantity");
                    HeaderRow.CreateCell(8).SetCellValue("MinSlotStartTime (Property TimeZone)");
                    HeaderRow.CreateCell(9).SetCellValue("MaxSlotEndTime (Property TimeZone)");
                    HeaderRow.CreateCell(10).SetCellValue("RatePlanName");
                    HeaderRow.CreateCell(11).SetCellValue("FirstName");
                    HeaderRow.CreateCell(12).SetCellValue("LastName");
                    HeaderRow.CreateCell(13).SetCellValue("Email");
                    HeaderRow.CreateCell(14).SetCellValue("Channel / Source");
                    HeaderRow.CreateCell(15).SetCellValue("Booking Status");
                    HeaderRow.CreateCell(16).SetCellValue("No. of Adults");
                    HeaderRow.CreateCell(17).SetCellValue("No. of Children");
                    HeaderRow.CreateCell(18).SetCellValue("PaymentCurrency");
                    HeaderRow.CreateCell(19).SetCellValue("PaypalTransactionID");
                    HeaderRow.CreateCell(20).SetCellValue("PromoCode");
                    HeaderRow.CreateCell(21).SetCellValue("PromoCodeValue");
                    HeaderRow.CreateCell(22).SetCellValue("TotalServicePrice");
                    HeaderRow.CreateCell(23).SetCellValue("Amount Paid");
                    #endregion

                    #region Body
                    for (int i = 0; i < li.Count; i++)
                    {
                        IRow row = Worksheet.CreateRow(i + 1);
                        row.CreateCell(0).SetCellValue(li[i].Brand);
                        row.CreateCell(1).SetCellValue(li[i].Booking);
                        row.CreateCell(2).SetCellValue(FormatIntoGMT8(li[i].BookingDate));
                        row.CreateCell(3).SetCellValue(li[i].Duration);
                        row.CreateCell(4).SetCellValue(li[i].ServiceCategory);
                        row.CreateCell(5).SetCellValue(li[i].ServiceType);
                        row.CreateCell(6).SetCellValue(li[i].ServiceBooked);
                        row.CreateCell(7).SetCellValue(li[i].NoOfServices);
                        row.CreateCell(8).SetCellValue(li[i].MinSlotStartTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(9).SetCellValue(li[i].MaxSlotEndTime.ToString("dd-MM-yyyy  hh:mm:ss tt"));
                        row.CreateCell(10).SetCellValue(li[i].RatePlanName);
                        row.CreateCell(11).SetCellValue(li[i].FirstName);
                        row.CreateCell(12).SetCellValue(li[i].LastName);
                        row.CreateCell(13).SetCellValue(li[i].Email);
                        row.CreateCell(14).SetCellValue(li[i].Channel + " / " + li[i].Source);
                        row.CreateCell(15).SetCellValue(li[i].Status);
                        row.CreateCell(16).SetCellValue(li[i].AdultCount);
                        row.CreateCell(17).SetCellValue(li[i].ChildCount);
                        row.CreateCell(18).SetCellValue(li[i].PaymentCurrency);
                        row.CreateCell(19).SetCellValue(li[i].PaypalTransactionID);
                        row.CreateCell(20).SetCellValue(li[i].PromoCode);
                        row.CreateCell(21).SetCellValue(li[i].PromoCodeValue);
                        row.CreateCell(22).SetCellValue(li[i].TotalServicePrice);
                        row.CreateCell(23).SetCellValue(li[i].AmountPaid);
                    }
                    #endregion

                    #region Sheet Style
                    IFont HeaderFont = workbook.CreateFont();
                    HeaderFont.IsBold = true;
                    XSSFCellStyle HeaderStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    HeaderStyle.FillPattern = FillPattern.SolidForeground;
                    HeaderStyle.SetFont(HeaderFont);
                    HeaderStyle.FillForegroundColor = IndexedColors.LightYellow.Index;
                    //HeaderRow.RowStyle = HeaderStyle;
                    int ColumnCount = Worksheet.GetRow(0).LastCellNum;
                    for (int i = 0; i < ColumnCount; i++)
                    {
                        HeaderRow.Cells[i].CellStyle = HeaderStyle;
                        Worksheet.AutoSizeColumn(i);
                    }
                    #endregion

                    workbook.Write(fs);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return url;
        }

        public void DeleteFiles(string Path)
        {
            DirectoryInfo di = new DirectoryInfo(Path);
            foreach (FileInfo file in di.GetFiles())
            {
                if (file.CreationTimeUtc.Date < DateTime.Now.Date)
                    file.Delete();
            }
        }

        public string FormatIntoGMT8(DateTime BookingDate)
        {
            //To Convert UTC Date Into GMT +8 (HongKong/Singapore TimeZone)
            return BookingDate.AddHours(8).ToString("dd-MM-yyyy  hh:mm:ss tt");
        }

        public string ManageBuffer(DateTime MaxSlotEndTime)
        {
            //To Remove Extra 30 Min Buffer From MaxSlotEndTime
            return MaxSlotEndTime.AddMinutes(30).ToString("dd-MM-yyyy  hh:mm:ss tt");
        }
    }

    public class SESResponse
    {
        public string Message { get; set; }
        public bool Status { get; set; }
    }
}
