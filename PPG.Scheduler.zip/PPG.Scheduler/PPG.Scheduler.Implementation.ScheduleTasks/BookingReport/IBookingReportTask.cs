﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.BookingReport
{
    public interface IBookingReportTask
    {
        Task SendBookingReportToJon();

        Task SendBookingReportToEsther();
    }
}
