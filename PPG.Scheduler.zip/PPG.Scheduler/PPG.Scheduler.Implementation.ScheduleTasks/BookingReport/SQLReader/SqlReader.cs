﻿using Microsoft.AspNetCore.Hosting;
using Scheduler.CrossCutting.Configuration;
using System;
using System.IO;

namespace PPG.Scheduler.Implementation.ScheduleTasks
{
    public class SqlReader
    {
        private IConfiguration configuration;
        private IHostingEnvironment environment;

        public SqlReader(IHostingEnvironment _environment)
        {
            environment = _environment;
        }

        public string FetchReportForJon()
        {
            string sql = string.Empty;
            try
            {
                string SQLPath = Path.Combine(environment.WebRootPath, "Queries", "Jon", "BookingReport.sql");
                if (File.Exists(SQLPath))
                    sql = File.ReadAllText(SQLPath);
            }
            catch (Exception)
            {
            }
            return sql;
        }

        public string FetchReportForEsther()
        {
            string sql = string.Empty;
            try
            {
                string SQLPath = Path.Combine(environment.WebRootPath, "Queries", "Esther", "BookingReport.sql");
                if (File.Exists(SQLPath))
                    sql = File.ReadAllText(SQLPath);
            }
            catch (Exception)
            {
            }
            return sql;
        }

        public string FetchQueryForServiceLevelReport()
        {
            string sql = string.Empty;
            try
            {
                string SQLPath = Path.Combine(environment.WebRootPath, "Queries", "ServiceLevelBookingReport", "ServiceLevelBookingReport.sql");
                if (File.Exists(SQLPath))
                    sql = File.ReadAllText(SQLPath);
            }
            catch (Exception)
            {
            }
            return sql;
        }
    }
}
