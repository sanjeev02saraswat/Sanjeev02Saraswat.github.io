﻿using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Enums.Booking;
using Microsoft.Extensions.DependencyInjection;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;
using Newtonsoft.Json;
using Scheduler.CrossCutting.Models.Entities;
using System.Linq;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using System.IO;
using System.Net;
using Scheduler.CrossCutting.Models.DTOs;

namespace PPG.Scheduler.Implementation.ScheduleTasks.BookingStatusUpdateToOasis
{
    public class UpdateBookingToOasis : IUpdateBookingToOasis
    {
        IDatabaseUnitOfWork UnitOfWork { get; }        

        IConfiguration Configuration { get; }
        static IServiceProvider ServiceProvider { get; set; }

        public UpdateBookingToOasis(IDatabaseUnitOfWork unitOfWork, IServiceProvider services, IConfiguration configuration)
        {
            UnitOfWork = unitOfWork;
            ServiceProvider = services;
            Configuration = configuration;
        }

        public Task UpdateBookingStatusOasis()
        {
            var Database = ServiceProvider.GetRequiredService<IDatabaseUnitOfWork>();
            ServiceProvider.GetRequiredService<IPropertyRepository>();
            ServiceProvider.GetRequiredService<IServiceRepository>();
            ServiceProvider.GetRequiredService<IAncillaryRepositary>();
            ServiceProvider.GetRequiredService<ITaxesRepository>();
            ServiceProvider.GetRequiredService<IRatePlanRepository>();
            ServiceProvider.GetRequiredService<IUserLogRepository>();
            ServiceProvider.GetRequiredService<IRoleClaimRepository>();            
            ServiceProvider.GetRequiredService<IRoomClassRepository>();
            ServiceProvider.GetRequiredService<IAncillaryRatePlanRepository>();
            ServiceProvider.GetRequiredService<ITaxTypeRepository>();
            ServiceProvider.GetRequiredService<IChannelRepository>();            
            ServiceProvider.GetRequiredService<ITaxesRatePlansRepository>();            
            ServiceProvider.GetRequiredService<IRatePlanParamRepository>();
            ServiceProvider.GetRequiredService<IInventoryPricingRepository>();
            ServiceProvider.GetRequiredService<IInventoryAvailabilityRepository>();
            ServiceProvider.GetRequiredService<ITermsAndConditionsRepository>();
            ServiceProvider.GetRequiredService<IInventoryRuleRepository>();
            ServiceProvider.GetRequiredService<IChannelServiceRateRepository>();
            ServiceProvider.GetRequiredService<IBookingsRepository>();
            ServiceProvider.GetRequiredService<IBookingServicesRepository>();
            ServiceProvider.GetRequiredService<IBookingAncillaryRepository>();
            ServiceProvider.GetRequiredService<IBookingGuestsRepository>();
            ServiceProvider.GetRequiredService<IOTAServiceRateRepository>();
            ServiceProvider.GetRequiredService<ITermsAndConditionsLinkedRatesRepository>();
            ServiceProvider.GetRequiredService<IUserPropertyMappingRepository>();
            ServiceProvider.GetRequiredService<IRatePlanServiceRepository>();
            ServiceProvider.GetRequiredService<IBookingBackgroundProcessRepository>();
            var pendingProcessBookings = Database.BookingBackgroundProcess.List(x => (x.ProcessState == 0 && x.RetryCount < Configuration.ConfigSettings.BookingUpdateToOasis.MaxRetry)).GroupBy(x => x.BookingId).SelectMany(g => g.OrderBy(x => x.CreatedDate));

            var bookingidlst = pendingProcessBookings.Select(x => x.BookingId).Distinct();

            foreach (var item in bookingidlst)
            {
                var BookingDetails = Database.Bookings.SingleOrDefault(x => x.BookingId == item);
                var selectedBookings = pendingProcessBookings.Where(x => x.BookingId == item);
                foreach (var updatebookingtooasis in selectedBookings)
                {
                    try
                    {
                        string Response = this.CallWebRequest("", "GET", Configuration.ConfigSettings.BookingUpdateToOasis.PMSApiEndpoint+ "?confirmationID="+BookingDetails.OrderRefNo+ "&status="+ updatebookingtooasis.StatusString, "");
                        BookingPMSApiResponse bookingPMSApiResponse = JsonConvert.DeserializeObject<BookingPMSApiResponse>(Response);                    
                        var backgroundProcessData = new BookingBackgroundProcessModel()
                        {
                            BookingProcessId=updatebookingtooasis.BookingProcessId,
                            CreatedDate=updatebookingtooasis.CreatedDate,                            
                            BookingId = updatebookingtooasis.BookingId,
                            ProcessState = Convert.ToInt16(bookingPMSApiResponse.status),
                            RetryCount = ++updatebookingtooasis.RetryCount,
                            LastModifiedDate = DateTime.UtcNow,
                            OasisResponse= Response,
                            StatusString=updatebookingtooasis.StatusString
                        };
                        Database.BookingBackgroundProcess.Update(backgroundProcessData, updatebookingtooasis.BookingProcessId);
                        Database.SaveChanges();
                    }
                    catch (Exception xe)
                    {
                        var logDetails = new LogDetails();
                        logDetails = GetLogDetails(xe);
                        Logger.WriteError(logDetails);
                    }

                }
            }
            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Implementation.ScheduleTasks",
                Location = "BookingStatusUpdateToOasis",
                Hostname = Environment.MachineName,
                Message = ex != null ? ex.Message : string.Empty,
                UserName = Environment.UserName,
                Excep = ex
            };
        }

        private string CallWebRequest(string Request, string MethodType, string Url, string MethodName)
        {
            HttpWebRequest request = null;

            // serialize the request object into xml
            System.Net.ServicePointManager.ServerCertificateValidationCallback = (senderX, certificate, chain, sslPolicyErrors) => { return true; };
            // use a non-secure, standard HTTP connection
            request = (HttpWebRequest)WebRequest.Create(Url + MethodName);

            request.Method = MethodType;
            request.ContentType = "application/json";
            if (MethodType.ToUpper() == "POST" || MethodType.ToUpper() == "PUT")
            {
                byte[] requestBytes = Encoding.UTF8.GetBytes(Request);

                using (Stream s = request.GetRequestStream())
                {
                    s.Write(requestBytes, 0, requestBytes.Length);
                    s.Close();
                }
            }

            // Grab the response
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                MemoryStream ms = new MemoryStream();

                using (Stream s = response.GetResponseStream())
                {
                    // Copy from response stream into memory stream
                    byte[] buffer = new byte[4096];
                    int count = 0;
                    do
                    {
                        count = s.Read(buffer, 0, buffer.Length);
                        if (count > 0)
                        {
                            ms.Write(buffer, 0, count);
                        }
                    } while (count > 0);
                    ms.Position = 0;
                    // deserialize the response
                    string oResp = this.DeserialiseResponse(ms);
                    if (null == oResp)
                    {
                        //CommonUtilities.TraceAndThrowJSONGatewayException("Not able to reterieve result from FindFlightCache Service", _currentTransactionID);
                        return null;
                    }
                    else
                    {
                        //  logger.LogToXmlFileIfRequired(oResp, "MDA.XMLResponse_" + objrequesttype.ToString());
                    }


                    return oResp;

                }
            }
            catch (WebException xe)
            {
                using (WebResponse response = xe.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    using (Stream data = response.GetResponseStream())
                    {
                        string Message = new StreamReader(data).ReadToEnd();
                        return Message;
                    }
                }
            }
        }

        protected string DeserialiseResponse(MemoryStream response)
        {
            StreamReader reader = new StreamReader(response);
            string text = reader.ReadToEnd();
            return text;

        }
    }
}
