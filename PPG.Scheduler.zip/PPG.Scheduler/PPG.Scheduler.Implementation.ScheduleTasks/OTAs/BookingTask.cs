﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduer.Infrastructure.OTAApis;
using Scheduler.CrossCutting.Enums.OTAs;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OTAs
{
    public class BookingTask : IBookingTask
    {
        IOTAApi OTAApi { get; }
        public BookingTask(IOTAApi oTAApi)
        {
            OTAApi = oTAApi;
        }

        public Task AddBookingToQueue(ChannelType channelType)
        {
            var result = Task.Run(async () => { return await OTAApi.AddBookingsToQueue(channelType); }).Result;
            return Task.CompletedTask;
        }

        public Task ProcessBooking()
        {
            var result = Task.Run(async () => { return await OTAApi.ProcessBookingQueue(); }).Result;
            return Task.CompletedTask;
        }
    }
}
