﻿using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OTAs
{
    public interface IBookingTask
    {
        Task AddBookingToQueue(ChannelType channelType);
        Task ProcessBooking();        
    }
}
