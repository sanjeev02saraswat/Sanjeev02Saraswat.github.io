﻿using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OTAs
{
    public interface IInventoryTask
    {
        Task ProcessInventory();        
    }
}
