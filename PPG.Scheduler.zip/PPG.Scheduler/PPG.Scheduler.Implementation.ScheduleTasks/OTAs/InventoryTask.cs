﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduer.Infrastructure.OTAApis;
using Scheduler.CrossCutting.Enums.OTAs;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OTAs
{
    public class InventoryTask : IInventoryTask
    {
        IOTAApi OTAApi { get; }
        public InventoryTask(IOTAApi oTAApi)
        {
            OTAApi = oTAApi;
        }

        public Task ProcessInventory()
        {
            var result = Task.Run(async () => { return await OTAApi.ProcessInventoryQueue(); }).Result;
            return Task.CompletedTask;
        }
    }
}
