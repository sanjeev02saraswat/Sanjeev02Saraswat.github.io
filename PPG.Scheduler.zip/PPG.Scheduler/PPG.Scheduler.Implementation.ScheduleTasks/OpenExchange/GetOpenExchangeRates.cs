﻿using Scheduer.Infrastructure.OTAApis.OpenExchangeRates;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OpenExchange
{
    public class GetOpenExchangeRates : IGetOpenExchangeRates
    {
        IOpenExchangeRatesAPI OpenExchangeRatesAPI { get; }
        public GetOpenExchangeRates(IOpenExchangeRatesAPI openExchangeRatesAPI)
        {
            OpenExchangeRatesAPI = openExchangeRatesAPI;
        }
        public Task UpdateConversionRates()
        {
            var result = Task.Run(async () => { return await OpenExchangeRatesAPI.UpdateConversionRates(); }).Result;
            return Task.CompletedTask;
        }
    }
}
