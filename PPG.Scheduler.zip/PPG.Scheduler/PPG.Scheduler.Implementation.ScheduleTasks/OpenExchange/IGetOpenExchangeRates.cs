﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.OpenExchange
{
    public interface IGetOpenExchangeRates
    {
        Task UpdateConversionRates();
    }
}
