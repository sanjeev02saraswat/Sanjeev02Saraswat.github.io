﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.PasswordReminderEmails
{
    public interface IPasswordReminderEmailsTask
    {
        Task ChangePasswordReminderEmail();
    }
}
