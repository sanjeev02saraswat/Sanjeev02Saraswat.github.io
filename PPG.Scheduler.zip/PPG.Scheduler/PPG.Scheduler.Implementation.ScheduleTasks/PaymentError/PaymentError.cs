﻿using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Enums.Booking;
using Microsoft.Extensions.DependencyInjection;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;
using Newtonsoft.Json;
using Scheduler.CrossCutting.Models.Entities;
using System.Linq;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using System.IO;
using System.Net;
using Scheduer.Infrastructure.PaymentError;

namespace PPG.Scheduler.Implementation.ScheduleTasks.PaymentError
{
    public class PaymentError : IPaymentError
    {
        IPaymentErrorApi PaymentErrorApi { get; } 
        IConfiguration Configuration { get; }
        static IServiceProvider ServiceProvider { get; set; }

        public PaymentError(IPaymentErrorApi iPaymentErrorApi, IServiceProvider services, IConfiguration configuration)
        {
            PaymentErrorApi = iPaymentErrorApi;
            ServiceProvider = services;
            Configuration = configuration;
        }

        public Task CheckPaymentError()
        {
            var result = Task.Run(async () => { return await PaymentErrorApi.ValidatePaymentError(); }).Result;
            return Task.CompletedTask;
        }
        public Task PaymentErrorInventoryReverse()
        {
            var result = Task.Run(async () => { return await PaymentErrorApi.PaymentErrorInventoryReverse(); }).Result;
            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Implementation.ScheduleTasks",
                Location = "PaymentError",
                Hostname = Environment.MachineName,
                Message = ex != null ? ex.Message : string.Empty,
                UserName = Environment.UserName,
                Excep = ex
            };
        }

        protected string DeserialiseResponse(MemoryStream response)
        {
            StreamReader reader = new StreamReader(response);
            string text = reader.ReadToEnd();
            return text;

        }
    }
}
