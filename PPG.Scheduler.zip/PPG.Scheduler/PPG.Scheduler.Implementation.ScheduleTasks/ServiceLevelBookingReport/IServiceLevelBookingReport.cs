﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPG.Scheduler.Implementation.ScheduleTasks.ServiceLevelBookingReport
{
   public interface IServiceLevelBookingReport
    {
        Task SendServiceLevelBookingReport();
    }
}
