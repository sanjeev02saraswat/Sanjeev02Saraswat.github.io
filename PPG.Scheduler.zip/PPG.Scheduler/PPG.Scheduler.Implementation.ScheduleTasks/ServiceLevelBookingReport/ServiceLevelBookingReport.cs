﻿using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Enums.Booking;
using Microsoft.Extensions.DependencyInjection;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;
using Newtonsoft.Json;
using Scheduler.CrossCutting.Models.Entities;
using System.Linq;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using System.IO;
using System.Net;
using Microsoft.AspNetCore.Hosting;
using PPG.Scheduler.Implementation.ScheduleTasks.ExcelHandler;
using System.Net.Http;
using Scheduler.CrossCutting.Models;
using Scheduler.Infrastructure.AWS.SES;
using MySql.Data.MySqlClient;
using Dapper;
using System.Data;

namespace PPG.Scheduler.Implementation.ScheduleTasks.ServiceLevelBookingReport
{
    public class ServiceLevelBookingReport : IServiceLevelBookingReport
    {
        IConfiguration Configuration { get; }

        IHostingEnvironment Environment { get; }

        static IServiceProvider ServiceProvider { get; set; }

        public ServiceLevelBookingReport(IServiceProvider services, IConfiguration configuration, IHostingEnvironment environment)
        {
            ServiceProvider = services;
            Configuration = configuration;
            Environment = environment;
        }

        public async Task SendServiceLevelBookingReport()
        {
            DateTime Today = DateTime.UtcNow;
            var CurrentMonth = Today.Month;
            var CurrentYear = Today.Year;
            DateTime ServiceLevelBookingReportDate = DateTime.MinValue;
            try
            {
                if (Configuration.ConfigSettings.ServiceLevelReportConfig.Day != "*")
                {
                    ServiceLevelBookingReportDate = new DateTime(CurrentYear, CurrentMonth, Convert.ToInt32(Configuration.ConfigSettings.ServiceLevelReportConfig.Day));
                }
                //Last 365 days
                var DateParameter = new DateTime(CurrentYear - 1, CurrentMonth, 1).ToString("yyyy-MM-dd");
                SqlReader reader = new SqlReader(Environment);
                var SQL = reader.FetchQueryForServiceLevelReport();
                SQL = SQL.Replace("{dateParameter}", DateParameter);
                List<ServiceLevelReportDto> T = new List<ServiceLevelReportDto>();
                using (var con = new MySqlConnection(Configuration.ConfigSettings.ConnectionStringsConfig.DatabaseContext))
                {
                    T = con.Query<ServiceLevelReportDto>(
                        sql: SQL,
                        commandTimeout: 60,
                        commandType: CommandType.Text
                        ).ToList();
                }
                BookingReportExcelHandler handler = new BookingReportExcelHandler(Configuration, Environment);
                handler.CreateServiceLevelBookingReport(T);
                BookingReportEmailBuilder builder = new BookingReportEmailBuilder(Configuration, Environment);

                if (Today.Date.Equals(ServiceLevelBookingReportDate.Date))
                {
                    await builder.SendMailMessageForServiceLevelBookingReport();
                }
                //To Check on UAT Env
                if (Configuration.ConfigSettings.ServiceLevelReportConfig.Day == "*")
                {
                    await builder.SendMailMessageForServiceLevelBookingReport();
                }
            }
            catch (Exception xe)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(xe);
                Logger.WriteError(logDetails);
            }
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = System.Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Implementation.ScheduleTasks",
                Location = "Service Level BookingReport.cs",
                Hostname = System.Environment.MachineName,
                Message = ex != null ? ex.Message : string.Empty,
                UserName = System.Environment.UserName,
                Excep = ex
            };
        }

        private string CallWebRequest(string Request, string MethodType, string Url, string MethodName)
        {
            HttpWebRequest request = null;

            // serialize the request object into xml
            System.Net.ServicePointManager.ServerCertificateValidationCallback = (senderX, certificate, chain, sslPolicyErrors) => { return true; };
            // use a non-secure, standard HTTP connection
            request = (HttpWebRequest)WebRequest.Create(Url + MethodName);

            request.Method = MethodType;
            request.ContentType = "application/json";
            if (MethodType.ToUpper() == "POST" || MethodType.ToUpper() == "PUT")
            {
                byte[] requestBytes = Encoding.UTF8.GetBytes(Request);

                using (Stream s = request.GetRequestStream())
                {
                    s.Write(requestBytes, 0, requestBytes.Length);
                    s.Close();
                }
            }

            // Grab the response
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                MemoryStream ms = new MemoryStream();

                using (Stream s = response.GetResponseStream())
                {
                    // Copy from response stream into memory stream
                    byte[] buffer = new byte[4096];
                    int count = 0;
                    do
                    {
                        count = s.Read(buffer, 0, buffer.Length);
                        if (count > 0)
                        {
                            ms.Write(buffer, 0, count);
                        }
                    } while (count > 0);
                    ms.Position = 0;
                    // deserialize the response
                    string oResp = this.DeserialiseResponse(ms);
                    if (null == oResp)
                    {
                        //CommonUtilities.TraceAndThrowJSONGatewayException("Not able to reterieve result from FindFlightCache Service", _currentTransactionID);
                        return null;
                    }
                    else
                    {
                        //  logger.LogToXmlFileIfRequired(oResp, "MDA.XMLResponse_" + objrequesttype.ToString());
                    }


                    return oResp;

                }
            }
            catch (WebException xe)
            {
                using (WebResponse response = xe.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    using (Stream data = response.GetResponseStream())
                    {
                        string Message = new StreamReader(data).ReadToEnd();
                        return Message;
                    }
                }
            }
        }

        protected string DeserialiseResponse(MemoryStream response)
        {
            StreamReader reader = new StreamReader(response);
            string text = reader.ReadToEnd();
            return text;

        }
    }
}
