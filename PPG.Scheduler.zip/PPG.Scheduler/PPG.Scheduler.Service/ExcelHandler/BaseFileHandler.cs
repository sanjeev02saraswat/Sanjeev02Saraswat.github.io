﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PPG.Scheduler.Service.ExcelHandler
{
   public class BaseFileHandler
    {
        private const string XlsxContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }
}
