﻿using Microsoft.AspNetCore.Hosting;
//using Microsoft.Extensions.Configuration;
using Scheduler.CrossCutting.Configuration;
using NPOI.HSSF.Util;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using Scheduler.CrossCutting.Models.DTOs;
using System;
using System.Collections.Generic;
using System.IO;


namespace PPG.Scheduler.Implementation.ScheduleTasks.ExcelHandler
{
    public class BookingReportExcelHandler : BaseFileHandler
    {
        IConfiguration configuration;
        IHostingEnvironment environment;

        public BookingReportExcelHandler(IConfiguration _configuration, IHostingEnvironment _environment)
        {
            configuration = _configuration;
            environment = _environment;
        }
        public string CreateBookingReportForJon(List<BookingReportForJonDto> li)
        {
            string url = string.Empty;
            string filePath = string.Empty;
            string FileName = @"\BookingReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xlsx";

            try
            {
                filePath = Path.Combine(environment.WebRootPath, "Reports", "Jon");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                if (File.Exists(filePath + FileName))
                {
                    File.Delete(filePath + FileName);
                }
                //var v = new FileInfo(filePath + FileName);
                using (var fs = new FileStream(filePath + FileName, FileMode.Create, FileAccess.Write))
                {

                    IWorkbook workbook = new XSSFWorkbook();
                    ISheet Worksheet = workbook.CreateSheet("Bookings");

                    #region Header
                    IRow HeaderRow = Worksheet.CreateRow(0);
                    HeaderRow.CreateCell(0).SetCellValue("OrderRefNo");
                    HeaderRow.CreateCell(1).SetCellValue("BookingDate");
                    HeaderRow.CreateCell(2).SetCellValue("MaxSlotEndTime");
                    HeaderRow.CreateCell(3).SetCellValue("MinSlotStartTime");
                    HeaderRow.CreateCell(4).SetCellValue("PaymentID");
                    HeaderRow.CreateCell(5).SetCellValue("PaymentTransactionID");
                    HeaderRow.CreateCell(6).SetCellValue("FirstName");
                    HeaderRow.CreateCell(7).SetCellValue("LastName");
                    HeaderRow.CreateCell(8).SetCellValue("Email");
                    HeaderRow.CreateCell(9).SetCellValue("Transaction Amount Paid (USD)");
                    #endregion

                    #region Body
                    for (int i = 0; i < li.Count; i++)
                    {
                        IRow row = Worksheet.CreateRow(i + 1);
                        row.CreateCell(0).SetCellValue(li[i].OrderRefNo);
                        row.CreateCell(1).SetCellValue(li[i].BookingDate);
                        row.CreateCell(2).SetCellValue(li[i].MaxSlotEndTime);
                        row.CreateCell(3).SetCellValue(li[i].MinSlotStartTime);
                        row.CreateCell(4).SetCellValue(li[i].PaymentID);
                        row.CreateCell(5).SetCellValue(li[i].PaymentTransactionID);
                        row.CreateCell(6).SetCellValue(li[i].FirstName);
                        row.CreateCell(7).SetCellValue(li[i].LastName);
                        row.CreateCell(8).SetCellValue(li[i].Email);
                        row.CreateCell(9).SetCellValue(li[i].TxnAmt);
                    }
                    #endregion

                    #region Sheet Style
                    IFont HeaderFont = workbook.CreateFont();
                    HeaderFont.IsBold = true;
                    XSSFCellStyle HeaderStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    HeaderStyle.FillPattern = FillPattern.SolidForeground;
                    HeaderStyle.SetFont(HeaderFont);
                    HeaderStyle.FillForegroundColor = IndexedColors.LightYellow.Index;
                    HeaderRow.RowStyle = HeaderStyle;
                    int ColumnCount = typeof(BookingReportForJonDto).GetProperties().Length;
                    for (int i = 0; i < ColumnCount; i++)
                    {
                        Worksheet.AutoSizeColumn(i);
                    }
                    #endregion

                    workbook.Write(fs);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return url;
        }

        public string CreateBookingReportForEsther(List<BookingReportForEstherDto> li)
        {
            string url = string.Empty;
            string filePath = string.Empty;
            string FileName = @"\BookingReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xlsx";

            try
            {
                filePath = Path.Combine(environment.WebRootPath, "Reports", "Esther");
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                if (File.Exists(filePath + FileName))
                {
                    File.Delete(filePath + FileName);
                }
                //var v = new FileInfo(filePath + FileName);
                using (var fs = new FileStream(filePath + FileName, FileMode.Create, FileAccess.Write))
                {

                    IWorkbook workbook = new XSSFWorkbook();
                    ISheet Worksheet = workbook.CreateSheet("Bookings");

                    #region Header
                    IRow HeaderRow = Worksheet.CreateRow(0);
                    HeaderRow.CreateCell(0).SetCellValue("OrderRefNo");
                    HeaderRow.CreateCell(1).SetCellValue("BookingDate");
                    HeaderRow.CreateCell(2).SetCellValue("ServiceName");
                    HeaderRow.CreateCell(3).SetCellValue("MinSlotStartTime");
                    HeaderRow.CreateCell(4).SetCellValue("MaxSlotEndTime");
                    HeaderRow.CreateCell(5).SetCellValue("PaymentID");
                    HeaderRow.CreateCell(6).SetCellValue("PaymentTransactionID");
                    HeaderRow.CreateCell(7).SetCellValue("PaymentAmount");
                    HeaderRow.CreateCell(8).SetCellValue("TotalServicePrice");
                    HeaderRow.CreateCell(9).SetCellValue("PaymentCurrency");
                    HeaderRow.CreateCell(10).SetCellValue("CountryofResidence");
                    HeaderRow.CreateCell(11).SetCellValue("Source");
                    HeaderRow.CreateCell(12).SetCellValue("Status");
                    HeaderRow.CreateCell(13).SetCellValue("GuestCount");
                    HeaderRow.CreateCell(14).SetCellValue("Email");
                    #endregion

                    #region Body
                    for (int i = 0; i < li.Count; i++)
                    {
                        IRow row = Worksheet.CreateRow(i + 1);
                        row.CreateCell(0).SetCellValue(li[i].OrderRefNo);
                        row.CreateCell(1).SetCellValue(li[i].BookingDate);
                        row.CreateCell(2).SetCellValue(li[i].ServiceName);
                        row.CreateCell(3).SetCellValue(li[i].MinSlotStartTime);
                        row.CreateCell(4).SetCellValue(li[i].MaxSlotEndTime);
                        row.CreateCell(5).SetCellValue(li[i].PaymentId);
                        row.CreateCell(6).SetCellValue(li[i].PaymentTransactionID);
                        row.CreateCell(7).SetCellValue(li[i].PaymentAmount);
                        row.CreateCell(8).SetCellValue(li[i].TotalServicePrice);
                        row.CreateCell(9).SetCellValue(li[i].PaymentCurrency);
                        row.CreateCell(10).SetCellValue(li[i].CountryofResidence);
                        row.CreateCell(11).SetCellValue(li[i].Source);
                        row.CreateCell(12).SetCellValue(li[i].Status);
                        row.CreateCell(13).SetCellValue(li[i].GuestCount);
                        row.CreateCell(13).SetCellValue(li[i].Email);
                    }
                    #endregion

                    #region Sheet Style
                    IFont HeaderFont = workbook.CreateFont();
                    HeaderFont.IsBold = true;
                    XSSFCellStyle HeaderStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    HeaderStyle.FillPattern = FillPattern.SolidForeground;
                    HeaderStyle.SetFont(HeaderFont);
                    HeaderStyle.FillForegroundColor = IndexedColors.LightYellow.Index;
                    HeaderRow.RowStyle = HeaderStyle;
                    int ColumnCount = typeof(BookingReportForEstherDto).GetProperties().Length;
                    for (int i = 0; i < ColumnCount; i++)
                    {
                        Worksheet.AutoSizeColumn(i);
                    }
                    #endregion

                    workbook.Write(fs);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return url;
        }
    }
}
