﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using PPG.Scheduler.Implementation.ScheduleTasks.BookingFailUpdateStatus;
using PPG.Scheduler.Implementation.ScheduleTasks.BookingStatusUpdateToOasis;
using PPG.Scheduler.Implementation.ScheduleTasks.PaymentError;
using PPG.Scheduler.Implementation.ScheduleTasks.OTAs;
using PPG.Scheduler.Implementation.ScheduleTasks.PasswordReminderEmails;
using PPG.Scheduler.Service.Tasks;
using PPG.Scheduler.Service.Tasks.OTAs;
using Scheduler.CrossCutting.DependencyInjection;
using Scheduler.CrossCutting.Models;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.Database.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PPG.Scheduler.Implementation.ScheduleTasks.BookingReport;
using PPG.Scheduler.Implementation.ScheduleTasks.ServiceLevelBookingReport;
using PPG.Scheduler.Implementation.ScheduleTasks.OpenExchange;

namespace PPG.Scheduler.Service.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddDependencyInjectionCustom(this IServiceCollection services, IConfiguration configuration)
        {
            //Schedule Task
            services.AddHostedService<UpdateBookingFailStatusScheduleTask>();
            services.AddHostedService<UpdateBookingStatusToOasisScheduleTask>();
            services.AddHostedService<ExpediaAddBookingToQueueScheduleTask>();
            services.AddHostedService<ProcessBookingScheduleTask>();
            services.AddHostedService<ProcessInventoryScheduleTask>();
            services.AddHostedService<ExpediaUpdateBookingConfirmationScheduleTask>();
            services.AddHostedService<PaymentErrorScheduleTask>();
            services.AddHostedService<ChangePasswordEmailsScheduleTask>();
            services.AddHostedService<BookingReportScheduleTask>();
            services.AddHostedService<ServiceLevelBookingReportScheduleTask>();
            services.AddHostedService<OpenExchangeTask>();
            //Services required for following Tasks i.e. repository, configurations etc
            DependencyInjector.RegisterServices(services);

            //Actual Task
            services.AddScoped<IUpdateBookingStatusTask, UpdateBookingStatusTask>();
            services.AddScoped<IUpdateBookingToOasis, UpdateBookingToOasis>();
            services.AddScoped<IBookingTask, BookingTask>();
            services.AddScoped<IInventoryTask, InventoryTask>();
            services.AddScoped<IUpdateBookingConfirmationTask, UpdateBookingConfirmationTask>();
            services.AddScoped<IPaymentError, PaymentError>();
            services.AddScoped<IPasswordReminderEmailsTask, PasswordReminderEmailsTask>();
            services.AddScoped<IBookingReportTask, BookingReportTask>();
            services.AddScoped<IServiceLevelBookingReport, ServiceLevelBookingReport>();
            services.AddScoped<IGetOpenExchangeRates, GetOpenExchangeRates>();
            
            //Database setup
            DependencyInjector.AddDbContext<DatabaseContext>(configuration.GetConnectionString(nameof(DatabaseContext)));
            DependencyInjector.AddDbContext<DatabaseReadContext>(configuration.GetConnectionString(nameof(DatabaseReadContext)));
            DependencyInjector.CreateDatabase<DatabaseContext>();
            DependencyInjector.CreateDatabase<DatabaseReadContext>();
        }

        public static void AddMvcCustom(this IServiceCollection services)
        {
            void Mvc(MvcOptions mvc)
            {
                var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
                mvc.Filters.Add(new AuthorizeFilter(policy));
            }

            void Json(MvcJsonOptions json)
            {
                json.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
            }

            services.AddMvc(Mvc).SetCompatibilityVersion(CompatibilityVersion.Latest).AddJsonOptions(Json);
        }

        public static void AddConfigSettingsCustom(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton(configuration.GetSection("BookingFailUpdateConfigSettings").Get<BookingFailUpdateConfigSettings>());
            services.AddSingleton(configuration.GetSection("BookingUpdateToOasisConfigSettings").Get<BookingUpdateToOasisConfigSettings>());
            services.AddSingleton(configuration.GetSection("OTAConfigSettings").Get<OTAConfigSettings>());
            services.AddSingleton(configuration.GetSection("IBConfigSettings").Get<IBConfigSettings>());
            services.AddSingleton(configuration.GetSection("ChangePasswordConfigSettings").Get<ChangePasswordConfigSettings>());
            services.AddSingleton(configuration.GetSection("JonReportConfigSettings").Get<JonReportConfigSettings>());
            services.AddSingleton(configuration.GetSection("EstherReportConfigSettings").Get<EstherReportConfigSettings>());
            services.AddSingleton(configuration.GetSection("ConnectionStrings").Get<ConnectionStringsConfigSetting>());
            services.AddSingleton(configuration.GetSection("ServiceLevelReportConfigSettings").Get<ServiceLevelReportConfigSettings>());
            services.AddSingleton(configuration.GetSection("OpenExchange").Get<OpenExchange>());
        }
    }
}
