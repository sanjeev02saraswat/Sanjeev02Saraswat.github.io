﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Threading.Tasks;

namespace PPG.Scheduler.Service.Middlewares
{
    public class ExceptionMiddleware
    {
        readonly IHostingEnvironment _environment;
        readonly RequestDelegate _request;

        public ExceptionMiddleware(IHostingEnvironment environment, RequestDelegate request)
        {
            _environment = environment;
            _request = request;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _request(context).ConfigureAwait(false);
            }
            //catch (DomainException exception)
            //{
            //    context.Response.Clear();
                
            //    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                
            //    context.Response.ContentType = "application/json";

            //    var response = JsonConvert.SerializeObject(new { error_code = exception.ErrorCode, message = exception.Message });

            //    await context.Response.WriteAsync(response).ConfigureAwait(false);
            //}
            catch (Exception exception)
            {
                if (_environment.IsDevelopment())
                {
                    throw;
                }

                context.Response.Clear();
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                context.Response.ContentType = MediaTypeNames.Text.Plain;
                await context.Response.WriteAsync(exception.InnerException.Message + " -- " + exception.InnerException.StackTrace).ConfigureAwait(false);
            }
        }
    }
}
