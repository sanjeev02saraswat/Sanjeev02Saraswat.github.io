﻿using Microsoft.Extensions.DependencyInjection;
using NCrontab;
using PPG.Scheduler.Service.BackgroundService;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PPG.Scheduler.Service.Scheduler
{
    public abstract class ScheduledProcessor : ScopedProcessor
    {
        private CrontabSchedule _schedule;
        private DateTime _nextRun;
        protected abstract string Schedule { get; }
        public ScheduledProcessor(IServiceScopeFactory serviceScopeFactory) : base(serviceScopeFactory)
        {
            _schedule = CrontabSchedule.Parse(Schedule);
            _nextRun = _schedule.GetNextOccurrence(DateTime.Now);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var logDetails = new LogDetails();
            logDetails.Project = Environment.CurrentDirectory;
            logDetails.Layer = "PPG.Scheduler.Service.Scheduler";
            logDetails.Location = "ScheduledProcessor.cs";
            logDetails.Hostname = Environment.MachineName;
            logDetails.UserName = Environment.UserName;

            do
            {
                var now = DateTime.Now;
                //var nextrun = _schedule.GetNextOccurrence(now);
                if (now > _nextRun)
                {
                    //logDetails.Message = "Scheduler running at " + DateTime.Now;
                    //Logger.WriteUsage(logDetails);

                    await Process();
                    _nextRun = _schedule.GetNextOccurrence(DateTime.Now);
                }
                await Task.Delay(5000, stoppingToken); //5 seconds delay
            }
            while (!stoppingToken.IsCancellationRequested);

            logDetails.Message = "Scheduler stopped at " + DateTime.Now;
            Logger.WriteUsage(logDetails);
        }
    }
}
