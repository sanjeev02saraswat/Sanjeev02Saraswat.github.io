﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PPG.Scheduler.Service.Scheduler;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.CrossCutting.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PPG.Scheduler.Implementation.ScheduleTasks.BookingReport;

namespace PPG.Scheduler.Service.Tasks
{
    public class BookingReportScheduleTask : ScheduledProcessor
    {
        public BookingReportScheduleTask(IServiceScopeFactory serviceScopeFactory, IConfiguration configuration
             ) : base(serviceScopeFactory)
        {
            _serviceScopeFactory = serviceScopeFactory;
            Configuration = configuration;

        }
        IConfiguration Configuration { get; }
        IBookingReportTask BookingReport { get; set; }
        private readonly IServiceScopeFactory _serviceScopeFactory;
        static IServiceProvider ServiceProvider { get; set; }
        protected override string Schedule => "*/30 * * * *"; //For UAT Env
        //protected override string Schedule => "30 4 2 * *"; //For Production Env
        //Cron Expression (Minutes ,hour ,day ,months ,days_of_week)

        public override Task ProcessInScope(IServiceProvider serviceProvider)
        {
            try
            {
                var logDetails = new LogDetails
                {
                    Project = Environment.CurrentDirectory,
                    Layer = "PPG.Scheduler.Service.Tasks",
                    Location = "BookingReportScheduleTask.cs",
                    Hostname = Environment.MachineName,
                    UserName = Environment.UserName,
                    Message = "Scheduler running at " + DateTime.Now
                };
                Logger.WriteUsage(logDetails);
                var scopedProcessingService = serviceProvider.GetRequiredService<IBookingReportTask>();
                if (Configuration.ConfigSettings.EstherReportConfig.IsActive == true)
                {
                    scopedProcessingService.SendBookingReportToEsther();
                }
            }
            catch (Exception ex)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(ex);
                Logger.WriteError(logDetails);
            }

            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Service",
                Location = "BookingReportScheduleTask.cs",
                Hostname = Environment.MachineName,
                Message = "Some error occured",
                UserName = Environment.UserName,
                Excep = ex
            };
        }
    }
}
