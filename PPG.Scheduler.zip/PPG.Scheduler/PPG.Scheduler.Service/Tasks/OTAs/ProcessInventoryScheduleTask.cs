﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PPG.Scheduler.Implementation.ScheduleTasks.OTAs;
using PPG.Scheduler.Service.Scheduler;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Enums.OTAs;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PPG.Scheduler.Service.Tasks.OTAs
{
    public class ProcessInventoryScheduleTask : ScheduledProcessor
    {
        IConfiguration Configuration { get; }

        private readonly IServiceScopeFactory _serviceScopeFactory;
        static IServiceProvider ServiceProvider { get; set; }
        protected override string Schedule => "*/1 * * * *";

        public ProcessInventoryScheduleTask(
            IServiceScopeFactory serviceScopeFactory,
            IConfiguration configuration
           ) : base(serviceScopeFactory)
        {
            _serviceScopeFactory = serviceScopeFactory;
            Configuration = configuration;
        }

        public override Task ProcessInScope(IServiceProvider serviceProvider)
        {
            try
            {
                var logDetails = new LogDetails
                {
                    Project = Environment.CurrentDirectory,
                    Layer = "PPG.Scheduler.Service.Tasks.OTAs",
                    Location = "ProcessInventoryScheduleTask.cs",
                    Hostname = Environment.MachineName,
                    UserName = Environment.UserName,
                    Message = "Scheduler running at " + DateTime.Now
                };
                Logger.WriteUsage(logDetails);

                serviceProvider.GetRequiredService<IInventoryTask>().ProcessInventory();
            }
            catch (Exception ex)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(ex);
                Logger.WriteError(logDetails);
            }

            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Service.Tasks.OTAs",
                Location = "ProcessInventoryScheduleTask.cs",
                Hostname = Environment.MachineName,
                Message = "Some error occured",
                UserName = Environment.UserName,
                Excep = ex
            };
        }
    }
}
