﻿using Microsoft.Extensions.DependencyInjection;
using PPG.Scheduler.Implementation.ScheduleTasks.OpenExchange;
using PPG.Scheduler.Service.Scheduler;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Threading.Tasks;

namespace PPG.Scheduler.Service.Tasks
{
    public class OpenExchangeTask : ScheduledProcessor
    {
        public OpenExchangeTask(IServiceScopeFactory serviceScopeFactory, IConfiguration configuration
           ) : base(serviceScopeFactory)
        {
            _serviceScopeFactory = serviceScopeFactory;
            Configuration = configuration;
        }
        IConfiguration Configuration { get; }
        IGetOpenExchangeRates getOpenExchangeRates { get; }
        private readonly IServiceScopeFactory _serviceScopeFactory;
        static IServiceProvider ServiceProvider { get; set; }
        protected override string Schedule => "*/1 * * * *";

        public override Task ProcessInScope(IServiceProvider serviceProvider)
        {
            try
            {
                var logDetails = new LogDetails
                {
                    Project = Environment.CurrentDirectory,
                    Layer = "PPG.Scheduler.Service.Tasks",
                    Location = "OpenExchangeTask.cs",
                    Hostname = Environment.MachineName,
                    UserName = Environment.UserName,
                    Message = "Scheduler running at " + DateTime.Now
                };
                Logger.WriteUsage(logDetails);

                var scopedProcessingService = serviceProvider.GetRequiredService<IGetOpenExchangeRates>();

                scopedProcessingService.UpdateConversionRates();
            }
            catch (Exception ex)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(ex);
                Logger.WriteError(logDetails);
            }

            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Service",
                Location = "OpenExchangeTask.cs",
                Hostname = Environment.MachineName,
                Message = "Some error occured",
                UserName = Environment.UserName,
                Excep = ex
            };
        }
    }
}
