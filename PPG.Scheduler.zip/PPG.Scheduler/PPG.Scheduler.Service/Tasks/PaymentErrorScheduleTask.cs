﻿using Scheduler.CrossCutting.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PPG.Scheduler.Implementation.ScheduleTasks.PaymentError;
using PPG.Scheduler.Service.Scheduler;
using Scheduler.CrossCutting.Logging;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Threading.Tasks;

namespace PPG.Scheduler.Service.Tasks
{
    public class PaymentErrorScheduleTask : ScheduledProcessor
    {
        public PaymentErrorScheduleTask(IServiceScopeFactory serviceScopeFactory, IConfiguration configuration
                ) : base(serviceScopeFactory)
        {
            _serviceScopeFactory = serviceScopeFactory;
            Configuration = configuration;

        }
        IConfiguration Configuration { get; }

        private readonly IServiceScopeFactory _serviceScopeFactory;
        static IServiceProvider ServiceProvider { get; set; }
        IPaymentError PaymentError { get; }
        protected override string Schedule => "*/1 * * * *";
        public override Task ProcessInScope(IServiceProvider serviceProvider)
        {
            try
            {
                var logDetails = new LogDetails
                {
                    Project = Environment.CurrentDirectory,
                    Layer = "PPG.Scheduler.Service.Tasks",
                    Location = "PaymentErrorScheduleTask.cs",
                    Hostname = Environment.MachineName,
                    UserName = Environment.UserName,
                    Message = "Scheduler running at " + DateTime.Now
                };
                Logger.WriteUsage(logDetails);

                var scopedProcessingService = serviceProvider.GetRequiredService<IPaymentError>();                

                scopedProcessingService.CheckPaymentError();
                scopedProcessingService.PaymentErrorInventoryReverse();
            }
            catch (Exception ex)
            {
                var logDetails = new LogDetails();
                logDetails = GetLogDetails(ex);
                Logger.WriteError(logDetails);
            }

            return Task.CompletedTask;
        }

        private static LogDetails GetLogDetails(Exception ex)
        {
            return new LogDetails
            {
                Project = Environment.CurrentDirectory,
                Layer = "PPG.Scheduler.Service",
                Location = "PaymentErrorScheduleTask.cs",
                Hostname = Environment.MachineName,
                Message = "Some error occured",
                UserName = Environment.UserName,
                Excep = ex
            };
        }
    }
}
