SELECT 
OrderRefNo,
date_add(Bookings.BookingDate, INTERVAL 08 hour) As BookingDate,
ServiceName,
MinSlotStartTime,
date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE) As 'MaxSlotEndTime',
PaymentId,
SUBSTRING(Details, LOCATE('{"Sale":{"Id":"',Details)+15, 17) AS PaymentTransactionID,
TotalBookingPrice AS PaymentAmount, 
TotalBookingPrice + Discount As 'TotalServicePrice',
BookingGuests.FirstName, 
BookingGuests.LastName,
Currency AS PaymentCurrency,
IF(SUBSTRING(Address, LOCATE('"CountryName":',Address)+15, 2)='ul' OR SUBSTRING(Address, LOCATE('"CountryName":',Address)+15, 2) = '"}', '',  SUBSTRING(Address, LOCATE('"CountryName":',Address)+15, 2)) AS CountryofResidence,
IF(Source='','PPL',Source) AS Source,
Status,
BookingServices.AdultCount + BookingServices.Child1Count + BookingServices.Child2Count AS GuestCount,
BookingServices.AdultCount AS AdultCount,
BookingServices.Child1Count + BookingServices.Child2Count AS ChildCount,
Bookings.TravelType,
Bookings.UserIP,
SUBSTRING_INDEX(Bookings.FlightNumber, ' ', -1) AS FlightNumber,
SUBSTRING_INDEX(SUBSTRING_INDEX(Bookings.FlightNumber, ' ', -2), ' ', 1) AS AirlineCode,
SUBSTRING_INDEX(SUBSTRING_INDEX(Bookings.FlightNumber, '(', 1), ' ', 5) AS AirlineName,
Email,
Bookings.PromoCode,
Bookings.Discount As 'PromoCodeValue',
PropertyParam.Values As 'PropertyCurrency',
Bookings.Currency As 'DefaultCurrency',
Bookings.TotalBookingPrice + Bookings.Discount As 'DefaultCurrencyAmount',
BookingServices.RatePlanName
FROM Bookings LEFT JOIN BookingServices ON Bookings.BookingId = BookingServices.BookingId
              LEFT JOIN BookingGuests ON Bookings.BookingId = BookingGuests.BookingId
			  INNER jOIN PropertyParam ON Bookings.PropertyId = PropertyParam.PropertyId
              LEFT JOIN (SELECT max(BookingPaymentDetails.PaymentDetailID) AS PaymentDetailID,BookingPaymentDetails.BookingId,BookingPaymentDetails.Details 
              from BookingPaymentDetails group by BookingPaymentDetails.BookingId) AS UBPD ON Bookings.BookingId = UBPD.BookingId

Where
Bookings.BookingDate > '{fromDateParameter}' 
And Bookings.BookingDate < '{toDateParameter}' 
And PropertyParam.Key='Currency'
Order By Bookings.BookingDate ASC

