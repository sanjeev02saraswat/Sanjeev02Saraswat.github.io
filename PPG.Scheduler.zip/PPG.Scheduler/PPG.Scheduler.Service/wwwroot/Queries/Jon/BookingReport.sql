SELECT 
OrderRefNo, 
BookingDate, 
MaxSlotEndTime, 
MinSlotStartTime, 
PaymentID, 
PaymentTransactionID,
BookingGuests.FirstName, 
BookingGuests.LastName,
BookingGuests.Email,
Bookings.TotalBookingPrice AS `Transaction Amount Paid (USD)`
FROM Bookings 
LEFT JOIN BookingServices ON Bookings.BookingId = BookingServices.BookingId
LEFT JOIN BookingGuests ON BookingGuests.BookingId = Bookings.BookingId
WHERE Bookings.Status = 'Confirmed' AND Bookings.BookingDate < '{dateParameter}'
ORDER BY Bookings.BookingId;
