(#Core Services
Select 
IF(Bookings.ChannelName='ARBC','Aerotel','PPL') As Brand,
Bookings.OrderRefno As Booking,
date_add(Bookings.BookingDate, INTERVAL 8 hour) as 'BookingDate',
Truncate((TIMESTAMPDIFF(MINUTE,BookingServices.MinSlotStartTime,date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE)))/60,1) As Duration,
Service.ServiceType As 'ServiceCategory',
Case
When (Bookings.ParentOrderRefNo IS NULL) Then 'Core'
Else '' END
As 'ServiceType',
Service.ServiceName As 'ServiceBooked',
date_add(BookingServices.MinSlotStartTime, INTERVAL 30 MINUTE) As 'MinSlotStartTime',
date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE) As 'MaxSlotEndTime',
Bookings.Discount As 'PromoCodeValue',
BookingServices.RatePlanName,
BookingGuests.FirstName,
BookingGuests.LastName,
BookingGuests.Email,
Case
When Bookings.ChannelName='HKBC' Then 'Website'
When Bookings.ChannelName='ARBC' Then 'Website'
When Bookings.ChannelName='LBLB' Then 'LoungeBuddy'
When Bookings.ChannelName='WOTA' Then 'OTA'
When Bookings.ChannelName='MANB' Then 'Manual Entry'
When Bookings.ChannelName='PartnerPortal' Then 'Partner Portal'
When Bookings.ChannelName='GDS' Then 'GDS'
Else ''
END AS 'Channel',
IF(Bookings.Source='','PPL',Bookings.Source) As 'Source',
Bookings.Status ,
BookingServices.AdultCount,
BookingServices.Child1Count+BookingServices.Child2Count As 'ChildCount',
Bookings.Currency As 'PaymentCurrency',
SUBSTRING(Details, LOCATE('{"Sale":{"Id":"',Details)+15, 17) As 'PaypalTransactionID',
Bookings.PromoCode As 'PromoCode',

BookingServices.TotalServicePrice As 'TotalServicePrice',
Bookings.TotalBookingPrice As 'AmountPaid',
count(BookingServices.BookingID) As 'NoOfServices'
From Bookings
LEFT JOIN BookingServices ON Bookings.BookingId = BookingServices.BookingId
LEFT JOIN BookingGuests ON Bookings.BookingId = BookingGuests.BookingId
LEFT  JOIN Service On BookingServices.ServiceID = Service.ServiceId
Inner JOIN (SELECT max(BookingPaymentDetails.PaymentDetailID) AS PaymentDetailID,BookingPaymentDetails.BookingId,BookingPaymentDetails.Details 
              from BookingPaymentDetails group by BookingPaymentDetails.BookingId) AS UBPD ON Bookings.BookingId = UBPD.BookingId
WHERE Bookings.BookingDate > '{dateParameter}' 
AND Bookings.ParentOrderRefNo IS NULL
Group By BookingServices.BookingID 
)
UNION
(#Cross Sell Service 
Select 
IF(Bookings.ChannelName='ARBC','Aerotel','PPL') As Brand,
Concat(Bookings.ParentOrderRefno,' / ',Bookings.OrderRefno) As Booking,
date_add(Bookings.BookingDate, INTERVAL 8 hour) as 'BookingDate',
Truncate((TIMESTAMPDIFF(MINUTE,BookingServices.MinSlotStartTime,date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE)))/60,1) As Duration,
Service.ServiceType As 'ServiceCategory',
IF ((Select count(*) As 'cnt' From BookingAncillary Where BookingAncillary.BookingID=Bookings.BookingID)>0, 'Ancillary','CrossSell') As 'ServiceType',
Service.ServiceName As 'ServiceBooked',
date_add(BookingServices.MinSlotStartTime, INTERVAL 30 MINUTE) As 'MinSlotStartTime',
date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE) As 'MaxSlotEndTime',
BookingGuests.FirstName,
BookingGuests.LastName,
BookingGuests.Email,
Case
When Bookings.ChannelName='HKBC' Then 'Website'
When Bookings.ChannelName='ARBC' Then 'Website'
When Bookings.ChannelName='LBLB' Then 'LoungeBuddy'
When Bookings.ChannelName='WOTA' Then 'OTA'
When Bookings.ChannelName='MANB' Then 'Manual Entry'
When Bookings.ChannelName='PartnerPortal' Then 'Partner Portal'
When Bookings.ChannelName='GDS' Then 'GDS'
Else ''
END AS 'Channel',
IF(Bookings.Source='','PPL',Bookings.Source) As 'Source',
Bookings.Status ,
BookingServices.AdultCount,
BookingServices.Child1Count+BookingServices.Child2Count As 'ChildCount',
Bookings.Currency As 'PaymentCurrency',
SUBSTRING(Details, LOCATE('{"Sale":{"Id":"',Details)+15, 17) As 'PaypalTransactionID',
Bookings.PromoCode As 'PromoCode',
Bookings.Discount As 'PromoCodeValue',
BookingServices.RatePlanName,
BookingServices.TotalServicePrice As 'TotalServicePrice',
(Select a.TotalBookingPrice  From Bookings a Where a.BookingID IN (
	Select BookingID From Bookings As b Where b.OrderRefNo In(Bookings.ParentOrderRefno)))  As 'BookingTransactionAmount',
	count(BookingServices.BookingID) As 'NoOfServices'  
From Bookings
LEFT JOIN BookingServices ON Bookings.BookingId = BookingServices.BookingId
LEFT JOIN BookingGuests ON Bookings.BookingId = BookingGuests.BookingId
LEFT JOIN Service On BookingServices.ServiceID = Service.ServiceId
Inner  JOIN (SELECT max(BookingPaymentDetails.PaymentDetailID) AS PaymentDetailID,BookingPaymentDetails.BookingId,BookingPaymentDetails.Details 
              from BookingPaymentDetails group by BookingPaymentDetails.BookingId) AS UBPD ON Bookings.BookingId = UBPD.BookingId
WHERE Bookings.BookingDate > '{dateParameter}'

AND Bookings.ParentOrderRefNo In(Select OrderRefno From Bookings WHERE Bookings.IsCrosssell=1) 
Group By BookingServices.BookingID 
)
UNION
(#Anciliary Service
Select 
IF(Bookings.ChannelName='ARBC','Aerotel','PPL') As Brand,
Bookings.OrderRefno As Booking,
date_add(Bookings.BookingDate, INTERVAL 8 hour) as 'BookingDate',
Ancillary.Duration As Duration,
Service.ServiceType As 'ServiceCategory',
Case
When BookingAncillary.AncillaryID IS NOT NULL Then  'Ancillary'
Else '' END
As 'ServiceType',
BookingAncillary.AncillaryName As 'ServiceBooked',
date_add(BookingServices.MinSlotStartTime, INTERVAL 30 MINUTE) As 'MinSlotStartTime',
date_add(BookingServices.MaxSlotEndTime, INTERVAL 30 MINUTE) As 'MaxSlotEndTime',
BookingGuests.FirstName,
BookingGuests.LastName,
BookingGuests.Email,
Case
When Bookings.ChannelName='HKBC' Then 'Website'
When Bookings.ChannelName='ARBC' Then 'Website'
When Bookings.ChannelName='LBLB' Then 'LoungeBuddy'
When Bookings.ChannelName='WOTA' Then 'OTA'
When Bookings.ChannelName='MANB' Then 'Manual Entry'
When Bookings.ChannelName='PartnerPortal' Then 'Partner Portal'
When Bookings.ChannelName='GDS' Then 'GDS'
Else ''
END AS 'Channel',
IF(Bookings.Source='','PPL',Bookings.Source) As 'Source',
Bookings.Status ,
BookingServices.AdultCount,
BookingServices.Child1Count+BookingServices.Child2Count As 'ChildCount',
Bookings.Currency As 'PaymentCurrency',
SUBSTRING(Details, LOCATE('{"Sale":{"Id":"',Details)+15, 17) As 'PaypalTransactionID',
Bookings.PromoCode As 'PromoCode',
Bookings.Discount As 'PromoCodeValue',
BookingServices.RatePlanName,
BookingAncillary.Price * BookingAncillary.Quantity  As 'TotalServicePrice',
Bookings.TotalBookingPrice As 'AmountPaid',
count(BookingServices.BookingID) As 'NoOfServices'   
From Bookings
LEFT  JOIN BookingServices ON Bookings.BookingId = BookingServices.BookingId
LEFT JOIN BookingGuests ON Bookings.BookingId = BookingGuests.BookingId
LEFT  JOIN Service On BookingServices.ServiceID = Service.ServiceId
LEFT  JOIN BookingAncillary On Bookings.BookingId = BookingAncillary.BookingId
LEFT JOIN Ancillary On BookingAncillary.AncillaryId=Ancillary.AncillaryId
Inner JOIN (SELECT max(BookingPaymentDetails.PaymentDetailID) AS PaymentDetailID,BookingPaymentDetails.BookingId,BookingPaymentDetails.Details 
              from BookingPaymentDetails group by BookingPaymentDetails.BookingId) AS UBPD ON Bookings.BookingId = UBPD.BookingId
WHERE Bookings.BookingDate > '{dateParameter}'
AND BookingAncillary.AncillaryID IS NOT NULL
Group By BookingServices.BookingID, BookingAncillary.AncillaryID
)
Order by BookingDate Desc
 

