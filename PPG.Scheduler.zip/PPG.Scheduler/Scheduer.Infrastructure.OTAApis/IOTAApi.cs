﻿using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scheduer.Infrastructure.OTAApis
{
    public interface IOTAApi
    {
        Task<bool> AddBookingsToQueue(ChannelType type);
        Task<bool> ProcessBookingQueue();
        Task<bool> UpdateBookingConfimration(ChannelType type);
        Task<bool> ProcessInventoryQueue();
    }
}
