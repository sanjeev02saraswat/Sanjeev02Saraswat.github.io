﻿using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Scheduer.Infrastructure.OTAApis
{
    public class OTAApi : IOTAApi
    {
        IConfiguration Configuration { get; }
        public OTAApi(
            IConfiguration configuration
            )
        {
            Configuration = configuration;
        }

        HttpClient client = new HttpClient();

        public async Task<bool> AddBookingsToQueue(ChannelType type)
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.OTAConfigSettings.APIURL + "api/v1/OTA/" + type + "/bookings/queue");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ProcessBookingQueue()
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.OTAConfigSettings.APIURL + "api/v1/OTA/bookings/process");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateBookingConfimration(ChannelType type)
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.OTAConfigSettings.APIURL + "api/v1/OTA/" + type + "/bookings/confrim");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ProcessInventoryQueue()
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.OTAConfigSettings.APIURL + "api/v1/OTA/availability/process");
            return response.IsSuccessStatusCode;
        }
    }
}
