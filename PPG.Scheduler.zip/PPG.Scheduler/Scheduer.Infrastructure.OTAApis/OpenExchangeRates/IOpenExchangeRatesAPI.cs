﻿using System.Threading.Tasks;

namespace Scheduer.Infrastructure.OTAApis.OpenExchangeRates
{
    public interface IOpenExchangeRatesAPI
    {
        Task<bool> UpdateConversionRates();
    }
}
