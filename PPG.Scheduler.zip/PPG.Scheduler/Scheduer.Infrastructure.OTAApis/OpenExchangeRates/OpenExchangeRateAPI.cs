﻿using System.Net.Http;
using System.Threading.Tasks;
using Scheduler.CrossCutting.Configuration;

namespace Scheduer.Infrastructure.OTAApis.OpenExchangeRates
{
    public class OpenExchangeRateAPI : IOpenExchangeRatesAPI
    {
        IConfiguration Configuration { get; }
        public OpenExchangeRateAPI(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        HttpClient client = new HttpClient();
        public async Task<bool> UpdateConversionRates()
        {
            HttpResponseMessage response = await client.PutAsync(Configuration.ConfigSettings.OpenExchange.APIURL, null);
            return response.IsSuccessStatusCode;
        }
    }
}
