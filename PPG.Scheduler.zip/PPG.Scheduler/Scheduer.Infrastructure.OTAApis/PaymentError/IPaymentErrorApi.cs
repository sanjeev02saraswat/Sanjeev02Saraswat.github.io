﻿using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Scheduer.Infrastructure.PaymentError
{
    public interface IPaymentErrorApi
    {
        Task<bool> ValidatePaymentError();
        Task<bool> PaymentErrorInventoryReverse();

    }
}
