﻿using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Enums.OTAs;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Scheduer.Infrastructure.PaymentError
{
    public class PaymentErrorApi : IPaymentErrorApi
    {
        IConfiguration Configuration { get; }
        public PaymentErrorApi(
            IConfiguration configuration
            )
        {
            Configuration = configuration;
        }

        HttpClient client = new HttpClient();

        public async Task<bool> ValidatePaymentError()
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.IBConfigSettings.APIURL + "api/v1/bookings/send-payment-links");
            return response.IsSuccessStatusCode;
        }
        public async Task<bool> PaymentErrorInventoryReverse()
        {
            HttpResponseMessage response = await client.GetAsync(Configuration.ConfigSettings.IBConfigSettings.APIURL + "api/v1/bookings/PaymentErrorInventoryReverse");
            return response.IsSuccessStatusCode;
        }
    }
}
