﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Configuration.AppConfig
{
    public class Configuration : IConfiguration
    {
        public Configuration(IConfigSettingsConfiguration configSettingsConfiguration)
        {
            ConfigSettings = configSettingsConfiguration;
        }
        public IConfigSettingsConfiguration ConfigSettings { get; }
    }
}
