﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Configuration
{
    public interface IConfiguration
    {
        IConfigSettingsConfiguration ConfigSettings { get; }
    }
}
