﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models;

namespace Scheduler.CrossCutting.Configuration.Settings
{
    public class ConfigSettingsConfiguration : IConfigSettingsConfiguration
    {
        public ConfigSettingsConfiguration(
            ConnectionStringsConfigSetting connectionStringsConfigSetting,
            BookingFailUpdateConfigSettings bookingFailUpdateConfigSettings,
            BookingUpdateToOasisConfigSettings bookingUpdateToOasisConfigSettings,
            OTAConfigSettings oTAConfigSettings,
            IBConfigSettings iBConfigSettings,
            ChangePasswordConfigSettings changePasswordConfigSettings,
            JonReportConfigSettings jonReportConfigSettings,
            EstherReportConfigSettings estherReportConfigSettings,
            ServiceLevelReportConfigSettings serviceLevelReportConfigSettings,
            OpenExchange openExchange

            )
        {
            ConnectionStringsConfig = connectionStringsConfigSetting;
            BookingFailUpdate = bookingFailUpdateConfigSettings;
            BookingUpdateToOasis = bookingUpdateToOasisConfigSettings;
            OTAConfigSettings = oTAConfigSettings;
            IBConfigSettings = iBConfigSettings;
            ChangePasswordConfig = changePasswordConfigSettings;
            JonReportConfig = jonReportConfigSettings;
            EstherReportConfig = estherReportConfigSettings;
            ServiceLevelReportConfig = serviceLevelReportConfigSettings;
            OpenExchange = openExchange;

        }
        public ConnectionStringsConfigSetting ConnectionStringsConfig { get; }
        public BookingFailUpdateConfigSettings BookingFailUpdate { get; }
        public BookingUpdateToOasisConfigSettings BookingUpdateToOasis { get; }
        public OTAConfigSettings OTAConfigSettings { get; }
        public IBConfigSettings IBConfigSettings { get; }
        public ChangePasswordConfigSettings ChangePasswordConfig { get; }
        public JonReportConfigSettings JonReportConfig { get; }
        public EstherReportConfigSettings EstherReportConfig { get; }
        public OpenExchange OpenExchange { get; }
        public ServiceLevelReportConfigSettings ServiceLevelReportConfig {get;}
    }
}
