﻿using Scheduler.CrossCutting.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Configuration
{
    public interface IConfigSettingsConfiguration
    {

        ConnectionStringsConfigSetting ConnectionStringsConfig { get; }
        BookingFailUpdateConfigSettings BookingFailUpdate { get; }
        BookingUpdateToOasisConfigSettings BookingUpdateToOasis { get; }
        OTAConfigSettings OTAConfigSettings { get; }
        OpenExchange OpenExchange { get; }
        IBConfigSettings IBConfigSettings { get; }
        ChangePasswordConfigSettings ChangePasswordConfig { get; }
        JonReportConfigSettings JonReportConfig { get; }
        EstherReportConfigSettings EstherReportConfig { get; }
        ServiceLevelReportConfigSettings ServiceLevelReportConfig { get; }

    }
}
