﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Scheduer.Infrastructure.OTAApis;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Configuration.Settings;
using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Repositories;

using Scheduler.Persistence.Database.Repositories.RatePlan;
using Scheduer.Infrastructure.PaymentError;
using Scheduler.Persistence.Database.UnitOfWork;
using System;
using Scheduer.Infrastructure.OTAApis.OpenExchangeRates;

namespace Scheduler.CrossCutting.DependencyInjection
{
    public static class DependencyInjector
    {
        static IServiceProvider ServiceProvider { get; set; }

        static IServiceCollection Services { get; set; }

        public static void AddDbContext<T>(string connectionString) where T : DbContext
        {
            Services.AddDbContext<T>(options => options.UseMySql(connectionString));
        }

        public static void CreateDatabase<T>() where T : DbContext
        {
            var context = GetService<T>();
            context.Database.EnsureCreated();
            context.Database.Migrate();
        }
        public static T GetService<T>()
        {
            Services = Services ?? RegisterServices();
            ServiceProvider = ServiceProvider ?? Services.BuildServiceProvider();
            return ServiceProvider.GetService<T>();
        }

        public static IServiceCollection RegisterServices()
        {
            return RegisterServices(new ServiceCollection());
        }

        public static IServiceCollection RegisterServices(IServiceCollection services)
        {

            services.AddScoped<IDatabaseUnitOfWork, DatabaseUnitOfWork>();

            //services.AddSingleton<IHostedService, ScheduleTask>();
            #region "Repositories"
            services.AddScoped<IPropertyRepository, PropertyRepository>();
            services.AddScoped<IServiceRepository, ServiceRepository>();
            services.AddScoped<IAncillaryRepositary, AncillaryRepositary>();
            services.AddScoped<ITaxesRepository, TaxesRepository>();
            services.AddScoped<IRatePlanRepository, RatePlanRepository>();
            services.AddScoped<IUserLogRepository, UserLogRepository>();
            //services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IRoleClaimRepository, RoleClaimRepository>();
            services.AddScoped<IAncillaryRepositary, AncillaryRepositary>();
            services.AddScoped<IRoomClassRepository, RoomClassRepository>();
            services.AddScoped<IAncillaryRatePlanRepository, AncillaryRatePlanRepository>();
            services.AddScoped<ITaxTypeRepository, TaxTypeRepository>();
            services.AddScoped<IChannelRepository, ChannelRepository>();
            services.AddScoped<ITaxesRepository, TaxesRepository>();
            services.AddScoped<ITaxesRatePlansRepository, TaxesRatePlansRepository>();
            services.AddScoped<IRatePlanRepository, RatePlanRepository>();
            services.AddScoped<IRatePlanParamRepository, RatePlanParamRepository>();
            services.AddScoped<IInventoryPricingRepository, InventoryPricingRepository>();
            services.AddScoped<IInventoryAvailabilityRepository, InventoryAvailabilityRepository>();
            services.AddScoped<ITermsAndConditionsRepository, TermsAndConditionsRepository>();
            services.AddScoped<IInventoryRuleRepository, InventoryRuleRepository>();
            services.AddScoped<IChannelServiceRateRepository, ChannelServiceRatePlanRepository>();
            services.AddScoped<IBookingsRepository, BookingsRepository>();
            services.AddScoped<IBookingServicesRepository, BookingServicesRepository>();
            services.AddScoped<IBookingAncillaryRepository, BookingAncillaryRepository>();
            services.AddScoped<IBookingGuestsRepository, BookingGuestsRepository>();
            services.AddScoped<IOTAServiceRateRepository, OTAServiceRateRepository>();
            services.AddScoped<ITermsAndConditionsLinkedRatesRepository, TermsAndConditionsLinkedRatesRepository>();
            services.AddScoped<IUserPropertyMappingRepository, UserPropertyMappingRepository>();
            services.AddScoped<IRatePlanServiceRepository, RatePlanServiceRepository>();
            services.AddScoped<IBookingBackgroundProcessRepository, BookingBackgroundProcessRepository>();
            services.AddScoped<ICampaignRepository, CampaignRepository>();
            services.AddScoped<IPromoCodeRepository, PromoCodeRepository>();
            services.AddScoped<IUsersRepository, UsersRepository>();
            #endregion
            //services.AddSingleton<IUpdateBookingStatusTask, UpdateBookingStatusTask>();

            services.AddSingleton<IConfigSettingsConfiguration, ConfigSettingsConfiguration>();
            services.AddSingleton<IConfiguration, Scheduler.CrossCutting.Configuration.AppConfig.Configuration>();

            #region "Infrastructures"
            services.AddSingleton<IOTAApi, OTAApi>();
            services.AddSingleton<IPaymentErrorApi, PaymentErrorApi>();
            services.AddSingleton<IOpenExchangeRatesAPI, OpenExchangeRateAPI>();
            #endregion

            Services = services;
            return Services;
        }
    }

}
