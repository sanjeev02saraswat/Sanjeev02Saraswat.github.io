﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Ancillary
{
    public enum Calculation
    {
        PerPerson = 1,
        PerRoom = 2
    }
}
