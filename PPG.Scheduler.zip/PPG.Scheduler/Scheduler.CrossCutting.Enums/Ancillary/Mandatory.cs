﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Ancillary
{
    public enum Mandatory
    {
        Never=1,
        Always=2
    }
}
