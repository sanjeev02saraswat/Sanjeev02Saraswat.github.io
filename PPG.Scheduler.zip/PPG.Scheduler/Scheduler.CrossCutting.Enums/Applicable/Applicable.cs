﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum Applicable
    {
        Yes = 1,
        No = 2,
        NA = 3
    }
}
