﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum AvailabilityPax
    {
        BasePrice,
        Adult1,
        Child1,
        Child2
    }
}
