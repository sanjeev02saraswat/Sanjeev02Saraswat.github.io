﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Booking
{
    public enum BookingSearchType
    {
        Start,
        End,
        Creation
    }
}
