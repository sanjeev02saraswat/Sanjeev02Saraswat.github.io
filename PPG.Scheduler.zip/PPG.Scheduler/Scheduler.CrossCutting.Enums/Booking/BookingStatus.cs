﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Scheduler.CrossCutting.Enums.Booking
{
    public enum BookingStatus
    {
        [Description("ALL")]
        All = 0,
        [Description("Confirmed")]
        Confirmed = 1,
        [Description("Cancelled")]
        Cancelled = 2,
        [Description("Payment Pending")]
        PaymentPending = 3,
        [Description("Payment Failed")]
        PaymentFailed = 4,
        //[Description("Not Confirmed")]
        //NotConfirmed = 5,
        [Description("No Show")]
        NoShow = 6,
        [Description("Payment Error")]
        PaymentError = 7
    }
}
