﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum ClaimType
    {
        hasDashboardFullAccess = 1,
        hasDashboardSaveAccess = 2,
        hasDashboardReadAccess = 3,
        canAccessDashboard = 4,
        hasPropertySetupFullAccess = 5,
        hasPropertySetupSaveAccess = 6,
        hasPropertySetupReadAccess = 7,
        canAccessPropertySetup = 8,
        hasPricingAndAvailabilityFullAccess = 9,
        hasPricingAndAvailabilitySaveAccess = 10,
        hasPricingAndAvailabilityReadAccess = 11,
        canAccessPricingAndAvailability = 12,
        hasBookingsFullAccess = 13,
        hasBookingsSaveAccess = 14,
        hasBookingsReadAccess = 15,
        canAccessBookings = 16,
        hasMyAccountsFullAccess = 17,
        hasMyAccountsSaveAccess = 18,
        hasMyAccountsReadAccess = 19,
        canAccessMyAccounts = 20,
        hasReportingFullAccess = 21,
        hasReportingSaveAccess = 22,
        hasReportingReadAccess = 23,
        canAccessReporting = 24,
        hasDistributionManagerFullAccess = 25,
        hasDistributionManagerSaveAccess = 26,
        hasDistributionManagerReadAccess = 27,
        canAccessDistributionManager = 28,
        hasAddSupervisorAccess = 29,
        hasAddMasterAdministratorAccess = 30,
        hasAddAdministratorAccess = 31,
        hasAddFrontOfficeManagerAccess = 32,
        hasAddReportingAccess = 33,
        hasAddRestrictedAccess = 34
    }
}
