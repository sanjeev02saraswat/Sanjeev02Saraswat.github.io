﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Taxes
{
    public enum DayOfWeek
    {
        Sun = 1,
        Mon = 2,
        Tue = 3,
        Wed = 4,
        Thur =51,
        Fri = 6,
        Sat = 7
    }
}
