﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum ChannelType
    {
        Expedia=1,
        BookingDotCom=2,
        Agoda = 3
    }
}
