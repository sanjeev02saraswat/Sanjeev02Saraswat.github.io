﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    
    public enum EmailNotificationType
    {
        ResetPassword = 1,
        ChangePassword=2,
        Registration=3,
        PasswordExpiry=4
    }
}
