﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum MailContentType
    {
        HTML = 1,
        Text = 2
    }
}
