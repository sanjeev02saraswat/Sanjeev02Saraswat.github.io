﻿namespace Scheduler.CrossCutting.Enums
{
    public enum LogType
    {
        None = 0,
        Login = 1,
        Logout = 2,
        Create =3,
        Update =4,
        Delete=5
    }
}
