﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.OTAs
{
    public enum ChannelType
    {
        Expedia = 1,
        BookingDotCom = 2,
        Agoda = 3
    }
}
