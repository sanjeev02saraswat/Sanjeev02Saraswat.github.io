﻿using System;

namespace Scheduler.CrossCutting.Enums
{
   public enum PhotoType
    {
        Properties=1,
        RatePlans= 2,
        Services = 3,
        Ancillary=4
    }   
}
