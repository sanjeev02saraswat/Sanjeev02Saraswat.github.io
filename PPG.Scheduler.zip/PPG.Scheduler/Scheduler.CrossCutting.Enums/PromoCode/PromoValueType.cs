﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.PromoCode
{
    public enum PromoParamKeys
    {
    }

    public enum PromoValueType
    {
        Absolute = 0,
        Percentage = 1
    }

    public enum PromoApplicableFor
    {
        B2C = 0,
        B2B = 1
    }
}
