﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum PropertyLinkTo
    {
        Aerotel = 1,
        PPL = 2
    }
}
