﻿namespace Scheduler.CrossCutting.Enums.Property
{
    public enum PropertyParamKeys
    {
        SpokenLanguageDto,
        Currency,
        TimeZone,
        LocalLanguage,
        CheckInTime,
        CheckOutTime,
        Has24HourReception,
        MainEmailAddress,
        NotificationEmail,
        GeneralManagerName,
        GeneralManagerEmail,
        SalesManagerName,
        SalesManagerEmail,
        LinkTo,
        Photo
    }
}
