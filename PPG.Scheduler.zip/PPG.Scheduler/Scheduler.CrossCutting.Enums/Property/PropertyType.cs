﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Scheduler.CrossCutting.Enums
{
    public enum PropertyType
    {
        Hotel = 1,
        Lounge = 2,
        [Description("Other(for Private Resting Area / Shower Lounge)")]
        Other = 3
    }
}
