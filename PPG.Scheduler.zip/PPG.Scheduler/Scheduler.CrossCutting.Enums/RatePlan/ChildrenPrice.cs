﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum ChildrenPrice
    {
        NonPerChild = 1,
        StandardAddPerChild = 2,
        SpecialChildPriceAdultPrice=3
    }
}
