﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum DeltaType
    {
        Percentage=1,
        USD=2
    }
}
