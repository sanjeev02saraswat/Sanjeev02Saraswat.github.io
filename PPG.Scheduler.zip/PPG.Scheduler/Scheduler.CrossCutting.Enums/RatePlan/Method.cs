﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum Method
    {
        None=1,
        FixedDelta=2
    }
}
