﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum PeriodOfAvailability
    {
        [Description("Date of Day")]
        DateOfDay,
        [Description("First Arrival Date")]
        FirstArrivalDate,
        [Description("First/Last Arrival Date")]
        FirstLastArrivalDate,
        [Description("Fixed Arrival Date")]
        FixedArrivalDate,
        [Description("Fixed Stay (fixed date/nights)")]
        FixedStay,
        [Description("Fixed Length of Stay (fixed number of nights)")]
        FixedLengthOfStay,
        [Description("Fixed Date (Arrival/Booking)")]
        FixedArrivalOrBooking,
        [Description("Booking Lead Time")]
        BookingLeadTime
    }
}
