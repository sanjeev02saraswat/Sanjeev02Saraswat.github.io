﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum PolicyPricing
    {
        PerPerson = 1,
        PerRoom = 2
    }
}
