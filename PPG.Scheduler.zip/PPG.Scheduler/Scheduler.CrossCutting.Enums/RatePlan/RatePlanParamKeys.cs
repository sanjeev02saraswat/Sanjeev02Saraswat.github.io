﻿namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum RatePlanParamKeys
    {
        SalesTerms,
        Payment,
        CancellationModification,
        NoShowPenaltyValue,
        NoShowPenaltyUOM,

        PeriodOfAvailability,
        ArrivalDate,
        LastArrivalDate,
        BookingDate,
        LastBookingDate,
        FirstLastArrivalDate,
        FirstLastBookingDate,
        Hours,
        LeadTime,
        TotalDays,

        Visibility,
        TargetAudience,
        Publish,
        PromoCode,
        TimeZone,
        Pricing,
        ChildrenPricePolicy,        
        Currency,
        BasedOn,
        Method,
        DeltaType,
        DeltaValue,
        Photo
    }
}
