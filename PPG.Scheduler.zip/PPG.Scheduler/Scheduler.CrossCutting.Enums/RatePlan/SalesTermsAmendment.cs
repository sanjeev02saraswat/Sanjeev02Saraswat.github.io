﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum SalesTermsAmendment
    {
        CancellableModifiable = 1,
        NonCancellableNonModifiable = 2
    }
}
