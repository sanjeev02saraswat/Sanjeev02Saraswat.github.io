﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum SalesTermsPayment
    {
        NoPrepayment = 1,
        FullPrepayment = 2,
        Deposit = 3
    }
}
