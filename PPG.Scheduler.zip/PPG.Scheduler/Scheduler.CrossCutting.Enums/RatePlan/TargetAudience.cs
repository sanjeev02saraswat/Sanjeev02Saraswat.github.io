﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum TargetAudience
    {
        B2B,
        B2C,
        B2B2C
    }
}
