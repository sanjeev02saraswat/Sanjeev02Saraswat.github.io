﻿namespace Scheduler.CrossCutting.Enums.RatePlan
{
    public enum Visibility
    {
        Public,
        Private
    }
}
