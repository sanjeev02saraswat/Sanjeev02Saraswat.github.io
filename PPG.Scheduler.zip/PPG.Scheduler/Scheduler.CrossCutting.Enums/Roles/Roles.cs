﻿using System;

namespace Scheduler.CrossCutting.Enums
{
    [Flags]
    public enum Roles
    {
        MasterAdministrator = 1,
        Administrator = 2,
        Supervisor = 3,
        FrontOfficeManager = 4,
        Reporting = 5,
        Restricted = 6
    }
}
