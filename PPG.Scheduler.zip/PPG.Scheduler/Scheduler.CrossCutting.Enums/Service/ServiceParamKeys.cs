﻿namespace Scheduler.CrossCutting.Enums.Service
{
    public enum ServiceParamKeys
    {
        FloorArea,
        FloorAreaUOM,
        RoomClass,
        Smoking,
        MaxPerson,
        MaxAdults,
        MaxChild,
        MinOccupancy,
        Features,
        Beddings,
        Photos
    }
}
