﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Enums.Service
{
    public enum ServiceType
    {
        Room = 1,
        [Description("Nap Room")]
        NapRoom = 2,
        Shower = 3,
        Massage = 4,
        Lounge = 5
    }
}
