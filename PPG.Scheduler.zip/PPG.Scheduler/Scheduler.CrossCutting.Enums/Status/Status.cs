﻿namespace Scheduler.CrossCutting.Enums
{
    public enum Status
    {
        None = 0,
        Active = 1,
        Locked = 2,
        Inactive = 3,
        Terminatied = 4,
        PasswordExpired=5
    }
}
