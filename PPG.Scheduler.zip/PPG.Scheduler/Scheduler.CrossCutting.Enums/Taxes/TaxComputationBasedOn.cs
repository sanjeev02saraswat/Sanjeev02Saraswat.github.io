﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Taxes
{
    public enum TaxComputationBasedOn
    {
        NetPrice=1,
        NetPricePreviousTaxes = 2
    }
}
