﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Taxes
{
    public enum TaxComputationStay
    {
        PerStay = 1,
        PerDay = 2
    }
}
