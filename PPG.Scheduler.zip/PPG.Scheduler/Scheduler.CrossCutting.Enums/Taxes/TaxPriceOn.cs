﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.Taxes
{
    public enum TaxPriceOn
    {
        All = 1,
        None = 2
    }
}
