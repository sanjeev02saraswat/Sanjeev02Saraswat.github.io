﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Enums.UserLog
{
    public enum UserLogParamKeys
    {
            RoomClass,
            Property,
            Ancillary,
            Authentication,
            AvailabilityAndPricing,
            User,
            TaxType,
            Taxes,
            Channel,
            OTAServiceRateMapping,
            InventoryRuleDomain,
            ChannelServiceRateMapping,
            TermsAndConditions,
            RatePlan,
            Service
    }
    
}
