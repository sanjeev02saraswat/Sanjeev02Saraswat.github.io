﻿//using Microsoft.Extensions.Logging;
using Scheduler.CrossCutting.Models.Entities;
using Serilog;
using Serilog.Events;
using System;
using System.IO;

namespace Scheduler.CrossCutting.Logging
{
    public static class Logger //: ILogger
    {
        private static readonly ILogger perfLogger;
        private static readonly ILogger usageLogger;
        private static readonly ILogger errorLogger;
        private static readonly ILogger diagnosticLogger;

        static Logger()
        {

            perfLogger = new LoggerConfiguration()                
                .WriteTo.RollingFile("C:\\Data\\logs\\perf\\scheduler\\{Date}.txt")
                .CreateLogger();

            usageLogger = new LoggerConfiguration()               
               .WriteTo.RollingFile("C:\\Data\\logs\\usage\\scheduler\\{Date}.txt")
               .CreateLogger();

            errorLogger = new LoggerConfiguration()               
               .WriteTo.RollingFile("C:\\Data\\logs\\error\\scheduler\\{Date}.txt")
               .CreateLogger();

            diagnosticLogger = new LoggerConfiguration()              
               .WriteTo.RollingFile("C:\\Data\\logs\\diagnostics\\scheduler\\{Date}.txt")
               .CreateLogger();
        }

        public static void WritePerf(LogDetails infoToLog)
        {
            perfLogger.Write(LogEventLevel.Information, "{@LogDetails}", infoToLog);
        }
        public static void WriteUsage(LogDetails infoToLog)
        {
            usageLogger.Write(LogEventLevel.Information, "{@LogDetails}", infoToLog);
        }
        public static void WriteError(LogDetails infoToLog)
        {
            infoToLog.Message = GetMessageFromException(infoToLog.Excep);
            errorLogger.Write(LogEventLevel.Error, "{@LogDetails}", infoToLog);
        }
        public static void WriteDiagnostic(LogDetails infoToLog)
        {
            var writeDiagnostics = true;//Convert.ToBoolean(ConfigurationManager.AppSettings["EnableDiagnostics"]);
            if (!writeDiagnostics)
                return;

            diagnosticLogger.Write(LogEventLevel.Information, "{@LogDetails}", infoToLog);
        }

        private static string GetMessageFromException(Exception exception)
        {
            if (exception == null) return "";
            if (exception.InnerException != null)
            {
                return GetMessageFromException(exception.InnerException);
            }
            return exception.Message;
        }
    }
}