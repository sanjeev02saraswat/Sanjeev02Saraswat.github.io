﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models
{

    public class ConnectionStringsConfigSetting
    {
        public string DatabaseContext { get; set; }

        public string DatabaseReadContext { get; set; }
    }
    public class BookingFailUpdateConfigSettings
    {
        public string UpdateInterval { get; set; }
        public string MaxInterval { get; set; }
        public string UpdateBookingCronExpression { get; set; }

    }

    public class BookingUpdateToOasisConfigSettings
    {
        public int MaxRetry { get; set; }
        public string PMSApiEndpoint { get; set; }
        public string OasisCronExpression { get; set; }
    }

    public class OTAConfigSettings
    {
        public string APIURL { get; set; }
    }
    public class IBConfigSettings
    {
        public string APIURL { get; set; }
        public string BackOfficeApiEndPoint { get; set; }
    }
    public class OpenExchange
    {
        public string APIURL { get; set; }
    }
    public class ChangePasswordConfigSettings
    {
        public int AccountLockedDays { get; set; }
        public string EmailApiEndpoint { get; set; }
        public string UpdatePasswordLink { get; set; }
        public string ChangePasswordCronExpression { get; set; }
    }

    public class JonReportConfigSettings
    {
        public string EmailApiEndpoint { get; set; }
        public string To { get; set; }
        public string CC { get; set; }
        public string Subject { get; set; }
        public string FromTitle { get; set; }
        public string From { get; set; }
        public string Day { get; set; }
        public bool IsActive { get; set; }
    }

    public class EstherReportConfigSettings
    {
        public string EmailApiEndpoint { get; set; }
        public string To { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Subject { get; set; }
        public string FromTitle { get; set; }
        public string From { get; set; }
        public string Day { get; set; }
        public bool IsActive { get; set; }
    }

    public class ServiceLevelReportConfigSettings
    {
        public string EmailApiEndpoint { get; set; }
        public string To { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Subject { get; set; }
        public string FromTitle { get; set; }
        public string From { get; set; }
        public string Day { get; set; }
        public bool IsActive { get; set; }
    }
}
