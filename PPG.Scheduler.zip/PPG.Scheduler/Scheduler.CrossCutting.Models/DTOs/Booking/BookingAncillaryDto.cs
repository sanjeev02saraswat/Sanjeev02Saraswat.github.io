﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingAncillaryDto
    {
        public long AncillaryId { get; set; }
        public ushort Quantity { get; set; }
    }
}
