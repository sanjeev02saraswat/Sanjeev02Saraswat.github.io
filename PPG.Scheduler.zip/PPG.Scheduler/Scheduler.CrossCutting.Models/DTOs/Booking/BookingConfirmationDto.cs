﻿using Scheduler.CrossCutting.Enums.Booking;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingConfirmationDto
    {
        [Required]
        public BookingStatus Status { get; set; }
    }
}
