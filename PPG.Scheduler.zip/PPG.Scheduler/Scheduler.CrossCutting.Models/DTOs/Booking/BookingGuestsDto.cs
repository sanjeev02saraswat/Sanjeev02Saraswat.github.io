﻿
using Scheduler.CrossCutting.Enums.Booking;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingGuestsDto
    {
        public GuestType BuyerType { get; set; }
        public long BuyerId { get; set; }
        [Required]
        [RegularExpression(@"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$")]
        public string Email { get; set; }
        [Required]
        public string Phone { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public BookingGuestAddress Address { get; set; }
    }

    public class BookingGuestAddress
    {
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string CityName { get; set; }
        public string PostalCode { get; set; }
        public string StateProv { get; set; }
        public string CountryName { get; set; }
    }
}
