﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
  public  class BookingPMSApiResponse
    {
        public bool status { get; set; }

        public string Message { get; set; }

        public string RequestMessage { get; set; }
    }
}
