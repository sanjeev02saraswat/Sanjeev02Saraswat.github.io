﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingServicesDto
    {
        [Required]
        [Range(1, 10)]
        public ushort AdultCount { get; set; }
        public ushort Child1Count { get; set; }
        public ushort Child2Count { get; set; }
        [Required]
        public long ServiceId { get; set; }
        [Required]
        public long RateId { get; set; }
        [Required]
        public List<DateTime> Slots { get; set; }
        public ushort Child1Age { get; set; }
        public ushort Child2Age { get; set; }
        public BookingAncillaryDto[] Ancillaries { get; set; }
    }
}
