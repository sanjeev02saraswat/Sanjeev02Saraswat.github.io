﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingServicesSlotsDto
    {
        public string DateSlot { get; set; }
        public string TimeSlot { get; set; }
        public BookingServicesSlotsPriceDto Price { get; set; }
    }

    public class BookingServicesSlotsPriceDto
    {
        public decimal AdultPrice { get; set; }
        public decimal Adult1Price { get; set; }
        public decimal Child1Price { get; set; }
        public decimal Child2Price { get; set; }
    }
}
