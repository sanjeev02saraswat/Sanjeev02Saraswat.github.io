﻿namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingServicesTaxesDto
    {
        public long TaxId { get; set; }
        public string TaxName { get; set; }
        public string TaxType { get; set; }
        public string Value { get; set; }
        public string ValueType { get; set; }
        public string BasedOn { get; set; }
        public string Stay { get; set; }
        public bool ConfiguredPrice { get; set; }
        public string PriceOn { get; set; }
        public decimal TotalTaxAmount { get; set; }
    }
}
