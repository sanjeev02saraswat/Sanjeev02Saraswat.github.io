﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingsDto
    {
        [Required]
        public string Currency { get; set; }
        [Required]
        public decimal TotalPrice { get; set; }
        [Required]
        public string ChannelName { get; set; }
        public string Source { get; set; }
        [Required]
        public string PaymentGateway { get; set; }
        [Required]
        public BookingServicesDto[] Services { get; set; }
        [Required]
        public BookingGuestsDto Buyer { get; set; }
        public string Comments { get; set; }
        public string SpecialRequests { get; set; }
    }

    public class BookingsResponseDto
    {
        public string VerificationId { get; set; }
        public string Confirmation { get; set; }
        public string PaymentURL { get; set; }
    }
}
