﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Booking
{
    public class PayPalRequestDto
    {
        public string Intent { get; set; }
        public long TotalAmount { get; set; }
        public string Currency { get; set; }
        public string PaymentMethod { get; set; }
        public string InvoiceNumber { get; set; }
        public string ReturnUrl { get { return "http://localhost/AerotelIBE/pplibe/BookingConfirmation"; } }
        public string CancelUrl { get { return "http://localhost/AerotelIBE/pplibe/BookingPending"; } }
    }
}
