﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Booking
{
    public class PayPalResponseDto
    {
        public string PaymentId { get; set; }
        public string PaymentUrl { get; set; }
        public string ConfirmationNo { get; set; }
    }
}
