﻿using System;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingReportForEstherDto
    {
        public string OrderRefNo { get; set; }

        public DateTime BookingDate { get; set; }

        public string ServiceName { get; set; }

        public DateTime MinSlotStartTime { get; set; }

        public DateTime MaxSlotEndTime { get; set; }

        public string PaymentId { get; set; }

        public string PaymentTransactionID { get; set; }

        public Decimal? PaymentAmount { get; set; }

        public decimal? TotalServicePrice { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string PaymentCurrency { get; set; }
        public string PropertyCurrency { get; set; }
        public decimal PropertyCurrencyAmount { get; set; }
        public string DefaultCurrency { get; set; }
        public decimal DefaultCurrencyAmount { get; set; }

        public string CountryofResidence { get; set; }

        public string Source { get; set; }

        public string Status { get; set; }
        public int AdultCount { get; set; }

        public int GuestCount { get; set; }
        public int ChildCount { get; set; }
        public string TravelType { get; set; }
        public string UserIP { get; set; }
        public string AirlineName { get; set; }
        public string AirlineCode { get; set; }
        public string FlightNumber { get; set; }

        public string Email { get; set; }

        public string PromoCode { get; set; }

        public string PromoCodeValue { get; set; }

        public string RatePlanName { get; set; }
    }
}
