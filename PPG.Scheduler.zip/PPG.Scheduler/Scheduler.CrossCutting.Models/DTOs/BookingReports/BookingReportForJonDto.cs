﻿using System.ComponentModel.DataAnnotations;
using System;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class BookingReportForJonDto
    {
        public string OrderRefNo { get; set; }

        public DateTime BookingDate { get; set; }

        public DateTime MaxSlotEndTime { get; set; }

        public DateTime MinSlotStartTime { get; set; }

        public string PaymentID { get; set; }

        public string PaymentTransactionID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        [Display(Name = "Transaction Amount Paid(USD)")]
        public string TxnAmt { get; set; }
    }
}
