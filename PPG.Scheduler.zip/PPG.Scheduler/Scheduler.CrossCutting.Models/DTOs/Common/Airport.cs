﻿using Newtonsoft.Json;

namespace Scheduler.CrossCutting.Models
{
    public class Airport
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("code")]
        public string Code { get; set; }
        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }
    }
}
