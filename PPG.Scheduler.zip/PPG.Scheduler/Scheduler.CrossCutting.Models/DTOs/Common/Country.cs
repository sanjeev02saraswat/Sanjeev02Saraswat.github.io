﻿using Newtonsoft.Json;

namespace Scheduler.CrossCutting.Models
{
    public class Country
    {
        [JsonProperty("code")]
        public string CountryCode { get; set; }
        [JsonProperty("name")]
        public string CountryName { get; set; }
        [JsonProperty("dial_code")]
        public string DialCode { get; set; }
    }
}
