﻿using Scheduler.CrossCutting.Enums;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace Scheduler.CrossCutting.Models
{
    public class MailMessages
    {
        public string From { get; set; }
        public string FromTitle { get; set; }
        public string To { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Subject { get; set; }
        public string MailBody { get; set; }
        public string MailMessage { get; set; }
        public MailContentType ContentType { get; set; }
        public Attachment Attachment { get; set; }

        public List<Attachment> ExtraAttachments { get; set; }
        public MailMessages()
        {
            this.From = "uat.ibe@plazapremiumlounge.com";
            this.FromTitle = "Aerotel ";
        }
    }
}
