﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.LocationAndServices
{
    public class LocationServices
    {
        public string PropertyId { get; set; }
        public string PropertyName { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string CityCode { get; set; }
        public string CityName { get; set; }
        public string AirportCode { get; set; }
        public string AirportName { get; set; }
        public string AirportZone { get; set; }
        public string AirportTerminal { get; set; }
        public string LocationAddress { get; set; }
        public IList<Services> Services { get; set; }
    }
   
}
