﻿namespace Scheduler.CrossCutting.Models.DTOs.LocationAndServices
{
    public class Services
    {
        public string ServiceType { get; set; }
        public string ServiceId { get; set; }
        public string ServiceName { get; set; }
    }
}
