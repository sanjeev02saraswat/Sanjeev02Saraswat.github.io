﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.PMS
{
    public class InventoryDto
    {
        public long PropertyId { get; set; }
        public long RatePlanId { get; set; }
        public long ServiceId { get; set; }
        public DateTime InvDate { get; set; }
        public string Data { get; set; }
    }
}
