﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.PMS
{
    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://schemas.xmlsoap.org/soap/envelope/", IsNullable = false, ElementName = "Envelope")]
    public class OTA_HotelAvailNotifRQ_Envelope
    {

        private OTA_HotelAvailNotifRQ_EnvelopeHeader headerField;

        private OTA_HotelAvailNotifRQ_EnvelopeBody bodyField;

        public OTA_HotelAvailNotifRQ_EnvelopeHeader Header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
            }
        }

        public OTA_HotelAvailNotifRQ_EnvelopeBody Body
        {
            get
            {
                return this.bodyField;
            }
            set
            {
                this.bodyField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public class OTA_HotelAvailNotifRQ_EnvelopeHeader
    {
        private SoapHeaderSecurity securityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
        public SoapHeaderSecurity Security
        {
            get
            {
                return this.securityField;
            }
            set
            {
                this.securityField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public class OTA_HotelAvailNotifRQ_EnvelopeBody
    {
        private OTA_HotelAvailNotifRQ oTA_HotelAvailNotifRQField;

        [Required]
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://www.opentravel.org/OTA/2003/05")]
        public OTA_HotelAvailNotifRQ OTA_HotelAvailNotifRQ
        {
            get
            {
                return this.oTA_HotelAvailNotifRQField;
            }
            set
            {
                this.oTA_HotelAvailNotifRQField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://www.opentravel.org/OTA/2003/05", IsNullable = false)]
    public class OTA_HotelAvailNotifRQ
    {
        private OTA_HotelAvailNotifRQAvailStatusMessages availStatusMessagesField;

        private System.DateTime timeStampField;

        private string echoTokenField;

        private decimal versionField;

        /// <remarks/>
        public OTA_HotelAvailNotifRQAvailStatusMessages AvailStatusMessages
        {
            get
            {
                return this.availStatusMessagesField;
            }
            set
            {
                this.availStatusMessagesField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public System.DateTime TimeStamp
        {
            get
            {
                return this.timeStampField;
            }
            set
            {
                this.timeStampField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string EchoToken
        {
            get
            {
                return this.echoTokenField;
            }
            set
            {
                this.echoTokenField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public class OTA_HotelAvailNotifRQAvailStatusMessages
    {

        private OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessage[] availStatusMessageField;

        private string hotelCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AvailStatusMessage")]
        public OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessage[] AvailStatusMessage
        {
            get
            {
                return this.availStatusMessageField;
            }
            set
            {
                this.availStatusMessageField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string HotelCode
        {
            get
            {
                return this.hotelCodeField;
            }
            set
            {
                this.hotelCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public class OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessage
    {

        private OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessageStatusApplicationControl statusApplicationControlField;

        private short bookingLimitField;

        /// <remarks/>
        public OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessageStatusApplicationControl StatusApplicationControl
        {
            get
            {
                return this.statusApplicationControlField;
            }
            set
            {
                this.statusApplicationControlField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public short BookingLimit
        {
            get
            {
                return this.bookingLimitField;
            }
            set
            {
                this.bookingLimitField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public class OTA_HotelAvailNotifRQAvailStatusMessagesAvailStatusMessageStatusApplicationControl
    {
        private System.DateTime startField;

        private System.DateTime endField;

        private string invTypeCodeField;

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public System.DateTime Start
        {
            get
            {
                return this.startField;
            }
            set
            {
                this.startField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public System.DateTime End
        {
            get
            {
                return this.endField;
            }
            set
            {
                this.endField = value;
            }
        }

        /// <remarks/>
        [Required]
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string InvTypeCode
        {
            get
            {
                return this.invTypeCodeField;
            }
            set
            {
                this.invTypeCodeField = value;
            }
        }
    }
}
