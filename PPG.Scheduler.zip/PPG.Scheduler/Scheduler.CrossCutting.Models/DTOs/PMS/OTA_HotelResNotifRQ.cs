﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.PMS
{

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://www.opentravel.org/OTA/2003/05", IsNullable = false)]
    public partial class OTA_HotelResNotifRQ
    {
        private OTA_HotelResNotifRQHotelReservations hotelReservationsField;

        private string versionField;

        private string timeStampField;

        private string echoTokenField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservations HotelReservations
        {
            get
            {
                return this.hotelReservationsField;
            }
            set
            {
                this.hotelReservationsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string TimeStamp
        {
            get
            {
                return this.timeStampField;
            }
            set
            {
                this.timeStampField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string EchoToken
        {
            get
            {
                return this.echoTokenField;
            }
            set
            {
                this.echoTokenField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservations
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservation> hotelReservationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("HotelReservation")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservation> HotelReservation
        {
            get
            {
                return this.hotelReservationField;
            }
            set
            {
                this.hotelReservationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservation
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStays roomStaysField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuests resGuestsField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfo resGlobalInfoField;

        private string resStatusField;

        private string createDateTimeField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStays RoomStays
        {
            get
            {
                return this.roomStaysField;
            }
            set
            {
                this.roomStaysField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuests ResGuests
        {
            get
            {
                return this.resGuestsField;
            }
            set
            {
                this.resGuestsField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfo ResGlobalInfo
        {
            get
            {
                return this.resGlobalInfoField;
            }
            set
            {
                this.resGlobalInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ResStatus
        {
            get
            {
                return this.resStatusField;
            }
            set
            {
                this.resStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string CreateDateTime
        {
            get
            {
                return this.createDateTimeField;
            }
            set
            {
                this.createDateTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStays
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStay> roomStayField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("RoomStay")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStay> RoomStay
        {
            get
            {
                return this.roomStayField;
            }
            set
            {
                this.roomStayField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStay
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypes roomTypesField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlans ratePlansField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCounts guestCountsField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayTimeSpan timeSpanField;

        private byte resGuestRPHsField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayComments commentsField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequests specialRequestsField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypes RoomTypes
        {
            get
            {
                return this.roomTypesField;
            }
            set
            {
                this.roomTypesField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlans RatePlans
        {
            get
            {
                return this.ratePlansField;
            }
            set
            {
                this.ratePlansField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCounts GuestCounts
        {
            get
            {
                return this.guestCountsField;
            }
            set
            {
                this.guestCountsField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayTimeSpan TimeSpan
        {
            get
            {
                return this.timeSpanField;
            }
            set
            {
                this.timeSpanField = value;
            }
        }

        /// <remarks/>
        public byte ResGuestRPHs
        {
            get
            {
                return this.resGuestRPHsField;
            }
            set
            {
                this.resGuestRPHsField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayComments Comments
        {
            get
            {
                return this.commentsField;
            }
            set
            {
                this.commentsField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequests SpecialRequests
        {
            get
            {
                return this.specialRequestsField;
            }
            set
            {
                this.specialRequestsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypes
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomType> roomTypeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("RoomType")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomType> RoomType
        {
            get
            {
                return this.roomTypeField;
            }
            set
            {
                this.roomTypeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomType
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomTypeRoomDescription roomDescriptionField;

        private string roomTypeCodeField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomTypeRoomDescription RoomDescription
        {
            get
            {
                return this.roomDescriptionField;
            }
            set
            {
                this.roomDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RoomTypeCode
        {
            get
            {
                return this.roomTypeCodeField;
            }
            set
            {
                this.roomTypeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRoomTypesRoomTypeRoomDescription
    {

        private string textField;

        private string nameField;

        /// <remarks/>
        public string Text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlans
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlan> ratePlanField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("RatePlan")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlan> RatePlan
        {
            get
            {
                return this.ratePlanField;
            }
            set
            {
                this.ratePlanField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlan
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlanRatePlanDescription ratePlanDescriptionField;

        private string ratePlanCodeField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlanRatePlanDescription RatePlanDescription
        {
            get
            {
                return this.ratePlanDescriptionField;
            }
            set
            {
                this.ratePlanDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RatePlanCode
        {
            get
            {
                return this.ratePlanCodeField;
            }
            set
            {
                this.ratePlanCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayRatePlansRatePlanRatePlanDescription
    {

        private string textField;

        /// <remarks/>
        public string Text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCounts
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCountsGuestCount> guestCountField;

        private byte isPerRoomField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("GuestCount")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCountsGuestCount> GuestCount
        {
            get
            {
                return this.guestCountField;
            }
            set
            {
                this.guestCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte IsPerRoom
        {
            get
            {
                return this.isPerRoomField;
            }
            set
            {
                this.isPerRoomField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayGuestCountsGuestCount
    {

        private byte ageQualifyingCodeField;

        private byte countField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte AgeQualifyingCode
        {
            get
            {
                return this.ageQualifyingCodeField;
            }
            set
            {
                this.ageQualifyingCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte Count
        {
            get
            {
                return this.countField;
            }
            set
            {
                this.countField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayTimeSpan
    {

        private string startField;

        private string endField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Start
        {
            get
            {
                return this.startField;
            }
            set
            {
                this.startField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string End
        {
            get
            {
                return this.endField;
            }
            set
            {
                this.endField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayComments
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayCommentsComment> commentField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Comment")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayCommentsComment> Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStayCommentsComment
    {

        private string textField;

        /// <remarks/>
        public string Text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequests
    {

        private List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequestsSpecialRequest> specialRequestField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SpecialRequest")]
        public List<OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequestsSpecialRequest> SpecialRequest
        {
            get
            {
                return this.specialRequestField;
            }
            set
            {
                this.specialRequestField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationRoomStaysRoomStaySpecialRequestsSpecialRequest
    {

        private string textField;

        private string nameField;

        /// <remarks/>
        public string Text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuests
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuest[] resGuestField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuest[] ResGuest
        {
            get
            {
                return this.resGuestField;
            }
            set
            {
                this.resGuestField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuest
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfiles profilesField;

        private byte resGuestRPHField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfiles Profiles
        {
            get
            {
                return this.profilesField;
            }
            set
            {
                this.profilesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte ResGuestRPH
        {
            get
            {
                return this.resGuestRPHField;
            }
            set
            {
                this.resGuestRPHField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfiles
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfo profileInfoField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfo ProfileInfo
        {
            get
            {
                return this.profileInfoField;
            }
            set
            {
                this.profileInfoField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfo
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfile profileField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfile Profile
        {
            get
            {
                return this.profileField;
            }
            set
            {
                this.profileField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfile
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomer customerField;

        private byte profileTypeField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomer Customer
        {
            get
            {
                return this.customerField;
            }
            set
            {
                this.customerField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte ProfileType
        {
            get
            {
                return this.profileTypeField;
            }
            set
            {
                this.profileTypeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomer
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerPersonName personNameField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerTelephone telephoneField;

        private string emailField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddress addressField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerPersonName PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerTelephone Telephone
        {
            get
            {
                return this.telephoneField;
            }
            set
            {
                this.telephoneField = value;
            }
        }

        /// <remarks/>
        public string Email
        {
            get
            {
                return this.emailField;
            }
            set
            {
                this.emailField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddress Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerPersonName
    {

        private string givenNameField;

        private string surnameField;

        /// <remarks/>
        public string GivenName
        {
            get
            {
                return this.givenNameField;
            }
            set
            {
                this.givenNameField = value;
            }
        }

        /// <remarks/>
        public string Surname
        {
            get
            {
                return this.surnameField;
            }
            set
            {
                this.surnameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerTelephone
    {

        private ulong phoneNumberField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ulong PhoneNumber
        {
            get
            {
                return this.phoneNumberField;
            }
            set
            {
                this.phoneNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddress
    {

        private string[] addressLineField;

        private string cityNameField;

        private uint postalCodeField;

        private string stateProvField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddressCountryName countryNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AddressLine")]
        public string[] AddressLine
        {
            get
            {
                return this.addressLineField;
            }
            set
            {
                this.addressLineField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public uint PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/>
        public string StateProv
        {
            get
            {
                return this.stateProvField;
            }
            set
            {
                this.stateProvField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddressCountryName CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGuestsResGuestProfilesProfileInfoProfileCustomerAddressCountryName
    {

        private string codeField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfo
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotal totalField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDs hotelReservationIDsField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfiles profilesField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoBasicPropertyInfo basicPropertyInfoField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotal Total
        {
            get
            {
                return this.totalField;
            }
            set
            {
                this.totalField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDs HotelReservationIDs
        {
            get
            {
                return this.hotelReservationIDsField;
            }
            set
            {
                this.hotelReservationIDsField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfiles Profiles
        {
            get
            {
                return this.profilesField;
            }
            set
            {
                this.profilesField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoBasicPropertyInfo BasicPropertyInfo
        {
            get
            {
                return this.basicPropertyInfoField;
            }
            set
            {
                this.basicPropertyInfoField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotal
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxes taxesField;

        private string currencyCodeField;

        private decimal amountBeforeTaxField;

        private decimal amountAfterTaxField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxes Taxes
        {
            get
            {
                return this.taxesField;
            }
            set
            {
                this.taxesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal AmountBeforeTax
        {
            get
            {
                return this.amountBeforeTaxField;
            }
            set
            {
                this.amountBeforeTaxField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal AmountAfterTax
        {
            get
            {
                return this.amountAfterTaxField;
            }
            set
            {
                this.amountAfterTaxField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxes
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxesTax taxField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxesTax Tax
        {
            get
            {
                return this.taxField;
            }
            set
            {
                this.taxField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoTotalTaxesTax
    {

        private decimal amountField;

        private string currencyCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDs
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDsHotelReservationID hotelReservationIDField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDsHotelReservationID HotelReservationID
        {
            get
            {
                return this.hotelReservationIDField;
            }
            set
            {
                this.hotelReservationIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoHotelReservationIDsHotelReservationID
    {

        private string resID_ValueField;

        private string resID_SourceContextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ResID_Value
        {
            get
            {
                return this.resID_ValueField;
            }
            set
            {
                this.resID_ValueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string ResID_SourceContext
        {
            get
            {
                return this.resID_SourceContextField;
            }
            set
            {
                this.resID_SourceContextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfiles
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfo profileInfoField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfo ProfileInfo
        {
            get
            {
                return this.profileInfoField;
            }
            set
            {
                this.profileInfoField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfo
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfile profileField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfile Profile
        {
            get
            {
                return this.profileField;
            }
            set
            {
                this.profileField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfile
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomer customerField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomer Customer
        {
            get
            {
                return this.customerField;
            }
            set
            {
                this.customerField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomer
    {

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerPersonName personNameField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerTelephone telephoneField;

        private string emailField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddress addressField;

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerPersonName PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerTelephone Telephone
        {
            get
            {
                return this.telephoneField;
            }
            set
            {
                this.telephoneField = value;
            }
        }

        /// <remarks/>
        public string Email
        {
            get
            {
                return this.emailField;
            }
            set
            {
                this.emailField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddress Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerPersonName
    {

        private string givenNameField;

        private string surnameField;

        /// <remarks/>
        public string GivenName
        {
            get
            {
                return this.givenNameField;
            }
            set
            {
                this.givenNameField = value;
            }
        }

        /// <remarks/>
        public string Surname
        {
            get
            {
                return this.surnameField;
            }
            set
            {
                this.surnameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerTelephone
    {

        private ulong phoneNumberField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ulong PhoneNumber
        {
            get
            {
                return this.phoneNumberField;
            }
            set
            {
                this.phoneNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddress
    {

        private string[] addressLineField;

        private string cityNameField;

        private uint postalCodeField;

        private string stateProvField;

        private OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddressCountryName countryNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AddressLine")]
        public string[] AddressLine
        {
            get
            {
                return this.addressLineField;
            }
            set
            {
                this.addressLineField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public uint PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/>
        public string StateProv
        {
            get
            {
                return this.stateProvField;
            }
            set
            {
                this.stateProvField = value;
            }
        }

        /// <remarks/>
        public OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddressCountryName CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoProfilesProfileInfoProfileCustomerAddressCountryName
    {

        private string codeField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.opentravel.org/OTA/2003/05")]
    public partial class OTA_HotelResNotifRQHotelReservationsHotelReservationResGlobalInfoBasicPropertyInfo
    {

        private string hotelCodeField;

        private string hotelNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string HotelCode
        {
            get
            {
                return this.hotelCodeField;
            }
            set
            {
                this.hotelCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string HotelName
        {
            get
            {
                return this.hotelNameField;
            }
            set
            {
                this.hotelNameField = value;
            }
        }
    }
}
