﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Payment
{
    public class PayPalRequestDto
    {
        string cancelUrl = "https://ec2-35-169-47-90.compute-1.amazonaws.com/";
        string returnUrl = "https://ec2-35-169-47-90.compute-1.amazonaws.com/";

        public string Intent { get; set; }
        public string PaymentMethod { get; set; }
        public string InvoiceNumber { get; set; }
        public long TotalAmount { get; set; }
        public string Currency { get; set; }
        public string CancelUrl { get { return cancelUrl; } }
        public string ReturnUrl { get { return returnUrl; } }
    }

    public class PayPalResponseDto
    {
        public string PaymentId { get; set; }
        public string PaymentUrl { get; set; }
    }
}
