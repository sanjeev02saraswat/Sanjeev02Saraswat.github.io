﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Register
{
    public class UserRegister
    {
        [Required]
        public string Title { get; set; }
        [Required]
        [RegularExpression(@"^[A-z][A-z|\.|\s]+$", ErrorMessage = "First Name is not valid")]
        public string FirstName { get; set; }
        [Required]
        [RegularExpression(@"^[A-z][A-z|\.|\s]+$", ErrorMessage = "Last Name is not valid")]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Phone { get; set; }
        [Required]
        public string Password { get; set; }

    }
}
