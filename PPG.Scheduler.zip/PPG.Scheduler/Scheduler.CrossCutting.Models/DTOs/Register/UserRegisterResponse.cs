﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Register
{
    public class UserRegisterResponse
    {
        public int UserId { get; set; }
        public string Title { get; set; }
        public string Login { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Access_token { get; set; }
        public string Token_type { get; set; }
    }
}
