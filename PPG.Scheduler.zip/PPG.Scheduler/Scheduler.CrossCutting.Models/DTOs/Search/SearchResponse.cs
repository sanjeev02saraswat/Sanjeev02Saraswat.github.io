﻿using Scheduler.CrossCutting.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.Search_PPL
{
    public class SearchResponse
    {
        public string Currency { get; set; }
        public string AirportCode { get; set; }
        public string AirportName { get; set; }
        public List<long> Properties { get; set; }
        //public IList<PropertiesPPL> Properties { get; set; }

    }
    public class PropertiesPPL
    {
        public string PropertyId { get; set; }
        public string PropertyName { get; set; }
        public string AirportZone { get; set; }
        public string AirportTerminal { get; set; }
        public string LocationAddress { get; set; }
        public string CheckInTime { get; set; }
        public string CheckOutTime { get; set; }
        public IList<ServiceImages> PropertyImages { get; set; }
        public IList<ServicesPPL> Services { get; set; }
        public IList<AdditionalServices> AdditionalServices { get; set; }
    }
    public class AdditionalServices
    {
        public string AdditionalServiceId { get; set; }
        public string AdditionalServiceName { get; set; }
        public string AdditionalServiceDescription { get; set; }
        public int PricePerUnit { get; set; }
        public IList<ServiceImages> AdditionalServiceImages { get; set; }

    }
    public class ServicesPPL
    {
        public string ServiceType { get; set; }
        public string ServiceId { get; set; }
        public string ServiceName { get; set; }
        public string ServiceDescription { get; set; }
        public string Timings { get; set; }
        public IList<ServiceImages> ServiceImages { get; set; }
        public IList<ServiceAmenities> ServiceAmenities { get; set; }
        public IList<Rates> Rates { get; set; }

    }
    public class ServiceImages
    {
        public string Url { get; set; }
    }
    public class ServiceAmenities
    {
        public string Amenity { get; set; }
        public string Logo { get; set; }
    }
    public class Rates
    {
        public string RateId { get; set; }
        public string RateName { get; set; }
        public int Minlos { get; set; }
        public int Maxlos { get; set; }
        public string RateTC { get; set; }
        public string Pricing { get; set; }
        public string Child1AgeGroup { get; set; }
        public string Child2AgeGroup { get; set; }
        public IList<Taxes> Taxes { get; set; }
        public IList<Slots> Slots { get; set; }

    }
    public class Taxes
    {
        public string TaxType { get; set; }
        public string Value { get; set; }
        public string ValueType { get; set; }
        public string TaxName { get; set; }
        public string BasedOn { get; set; }
        public string Stay { get; set; }
        public bool ConfiguredPrice { get; set; }
        public string PriceOn { get; set; }
    }
    public class Slots
    {
        public string Slot { get; set; }
        public string AdultPrice { get; set; }
        public string AdultPlus1Price { get; set; }
        public string Child1Price { get; set; }
        public string Child2Price { get; set; }

    }
}
