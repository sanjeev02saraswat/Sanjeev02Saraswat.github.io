﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class ServiceLevelReportDto
    {
        public string Brand { get; set; }

        public string Booking { get; set; }

        public DateTime BookingDate { get; set; }

        public string Duration { get; set; }

        public string ServiceCategory { get; set; }

        public string ServiceType { get; set; }

        public string ServiceBooked { get; set; }

        public DateTime MinSlotStartTime { get; set; }
        public DateTime MaxSlotEndTime { get; set; }
        public string RatePlanName { get; set; }

        public string FirstName { get; set; }
        
        public string LastName { get; set; }
        
        public string Email { get; set; }

        public string Channel{ get; set; }

        public string Source { get; set; }
        
        public string Status { get; set; }

        public string TotalServicePrice { get; set; }

        public string AdultCount { get; set; }

        public string ChildCount { get; set; }

        public string PaymentCurrency { get; set; }

        public string PaypalTransactionID { get; set; }

        public string PromoCode { get; set; }
        public string PromoCodeValue { get; set; }
        public string NoOfServices { get; set; }

        public string AmountPaid { get; set; }

    }
}
