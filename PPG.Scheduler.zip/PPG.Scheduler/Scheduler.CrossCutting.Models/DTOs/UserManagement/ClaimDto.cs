﻿using Scheduler.CrossCutting.Enums;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class ClaimDto
    {
        public ClaimType TypeId { get; set; }
        public string Type {
            get
            {
                return TypeId.ToString();
            }
            
        }
        public string Value { get; set; }
    }
}
