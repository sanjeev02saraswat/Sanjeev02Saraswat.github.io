﻿using Scheduler.CrossCutting.Enums;
using System;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class UserLogDto
    {
        public DateTime LogDate{ get; set; }
        public string UserName { get; set; }
        public LogType Type { get; set; }
    }
}
