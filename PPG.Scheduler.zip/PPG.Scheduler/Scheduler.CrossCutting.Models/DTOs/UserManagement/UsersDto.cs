﻿using Scheduler.CrossCutting.Enums;
using System.Collections.Generic;

namespace Scheduler.CrossCutting.Models.DTOs
{
    public class UsersDto
    {
        public long UserId { get; set; }
        public string Login { get; set; }
        public string Name { get; set; }
        public string SurName { get; set; }
        public string Email { get; set; }
        public Status Status { get; set; }
        public Roles Role { get; set; }
        public string RoleName {
            get
            {
                return Role.ToString();
            }
         }

        public IEnumerable<ClaimDto> Claims { get; set; }

        public IEnumerable<UserLogDto> UserLogs { get; set; }
    }
}
