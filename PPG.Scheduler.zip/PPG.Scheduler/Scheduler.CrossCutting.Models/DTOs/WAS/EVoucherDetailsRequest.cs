﻿using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.DTOs.WAS
{
    public class EVoucherDetailsRequest
    {
        [Required]
        public EVoucherRequestAuthenticate Authenticate { get; set; }
    }

    public class EVoucherRequestAuthenticate
    {
        /// Username for WAS
        [Required]
        public string Username { get; set; }

        /// Password for WAS
        [Required]
        public string Password { get; set; }

        /// Unique Id of request
        [Required]
        public string RequestId { get; set; }

        /// Mapped with WAS Property ID
        [Required]
        public string PropertyId { get; set; }

        /// (-) 24 hours of request date 
        [Required]
        public System.DateTime DateFrom { get; set; }

        /// (+) 24 hours of request date
        [Required]
        public System.DateTime DateTo { get; set; }
    }
}
