﻿using Scheduler.CrossCutting.Enums.Booking;
//using Newtonsoft.Json;
using System.Collections.Generic;

namespace Scheduler.CrossCutting.Models.DTOs.WAS
{
    public class EVoucherDetailsResponse
    {
        public string RequestId { get; set; }
        public List<EVoucherDetailsBooking> Bookings { get; set; }
    }

    public class EVoucherDetailsBooking
    {
        public string OrderRefNo { get; set; }
        public string VerificationNo { get; set; }
        public System.DateTime BookingDate { get; set; }
        public System.DateTime StartTime { get; set; }
        public string Status { get; set; }
        public bool IsAvailed { get; set; }
        public EVoucherDetailsGuests GuestDetails { get; set; }
        public List<EVoucherDetailsService> Services { get; set; }
        public List<EVoucherDetailsAncillary> Ancillaries { get; set; }
    }

    public class EVoucherDetailsGuests
    {
        public string GuestType { get; set; }
        public string GuestName { get; set; }
    }

    public class EVoucherDetailsService
    {
        public string ServiceId { get; set; }
        public string ServiceName { get; set; }
        public double Duration { get; set; }
    }

    public class EVoucherDetailsAncillary
    {
        public long AncillaryId { get; set; }
        public string AncillaryName { get; set; }
        public int Quantity { get; set; }
    }

}
