﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.WAS
{
    public class EVoucherUpdateRequest
    {
        [Required]
        public EVoucherUpdateRequestAuthenticate Authenticate { get; set; }
    }

    public class EVoucherUpdateRequestAuthenticate
    {
        /// Username for WAS
        [Required]
        public string Username { get; set; }
        /// Password for WAS
        [Required]
        public string Password { get; set; }
        /// Unique Id of request
        [Required]
        public string RequestId { get; set; }
         
        [Required]
        public bool IsAvailed { get; set; }
    }
}
