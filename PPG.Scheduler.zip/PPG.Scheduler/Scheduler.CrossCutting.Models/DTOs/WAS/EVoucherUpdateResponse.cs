﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.DTOs.WAS
{
    public class EVoucherUpdateResponse
    {
        public string RequestId { get; set; }
        public string Status { get; set; }
    }
}
