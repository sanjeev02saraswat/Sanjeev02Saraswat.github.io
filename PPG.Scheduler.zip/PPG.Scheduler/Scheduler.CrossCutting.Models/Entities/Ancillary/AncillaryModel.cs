﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;
using Scheduler.CrossCutting.Enums.Ancillary;
using Scheduler.CrossCutting.Utils.Extensions;
using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.Entities
{
   public class AncillaryModel
    {
        public long PropertyId { get; set; }
        [Key]
        public long AncillaryId { get; set;}
        public string AncillaryName { get; set;}
        public string ShortDescription { get; set;}
        public decimal Price { get; set;}
        public decimal ChildPrice { get; set; }
        public string Currency {get; set;}
        [Column("Calculation")]
        public string CalculationString
        {
            get { return Calculation.ToString(); }
            private set
            {
                Calculation = value.ParseEnum<Calculation>();
            }
        }
        [NotMapped]
        public Calculation Calculation { get; set; }
        public PropertyModel Property { get; set; }
        public string Photo { get; set; }
        public ICollection<AncillaryRatePlanModel> AncillaryRatePlans { get; set; } = new List<AncillaryRatePlanModel>();
    }
}
