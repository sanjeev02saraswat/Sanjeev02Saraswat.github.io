﻿using Scheduler.CrossCutting.Enums.Ancillary;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class AncillaryRatePlanModel
    {
        [Key] 
        public long AncillaryRatePlanId { get; set;}
        public long AncillaryId { get; set; }
        public long RatePlanId { get; set; }
        [Column("Mandatory")]
        public string MandatoryString
        {
            get { return Mandatory.ToString(); }
            private set
            {
                Mandatory = value.ParseEnum<Mandatory>();
            }
        }
        [NotMapped]
        public Mandatory Mandatory { get; set; }
        public bool AddToPrice { get; set; }
        public string Order { get; set; }
        public PropertyRatePlanModel PropertyRatePlan { get; set; }
        public AncillaryModel Ancillary { get; set; }
    }
}
