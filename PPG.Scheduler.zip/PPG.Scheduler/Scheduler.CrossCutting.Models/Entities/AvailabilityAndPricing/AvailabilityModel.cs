﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class AvailabilityModel
    {
        [Key]
        public long Id { get; set; }
        public long PropertyId { get; set; }
        public long RatePlanId { get; set; }
        public long ServiceId { get; set; }

        [Column(TypeName = "date")]
        public DateTime InvDate { get; set; }
        public string Data { get; set; }
        public PropertyModel Property { get; set; }
        public ServiceModel Service { get; set; }
        public PropertyRatePlanModel RatePlan { get; set; }
        [NotMapped]
        public int IsProcessed { get; set; }
    }
}
