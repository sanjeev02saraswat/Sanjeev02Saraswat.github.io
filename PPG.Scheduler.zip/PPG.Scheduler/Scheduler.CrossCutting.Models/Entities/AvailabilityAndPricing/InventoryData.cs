﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class InventoryAndPriceData
    {
        public string TimeSlot { get; set; }
        public string InvPriceCount { get; set; }
    }
}
