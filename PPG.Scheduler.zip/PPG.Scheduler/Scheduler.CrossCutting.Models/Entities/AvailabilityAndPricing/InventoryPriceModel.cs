﻿//using Scheduler.CrossCutting.Models.DTOs.AvailabilityAndPricing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace Scheduler.CrossCutting.Models.Entities
{
    public class InventoryPriceModel
    {
        [Key]
        public long Id { get; set; }
        public long PropertyId { get; set; }
        public long RatePlanId { get; set; }
        public long ServiceId { get; set; }
        [Column(TypeName = "date")]
        public DateTime InvtPriceDate { get; set; }
        public string Data { get; set; }
        public string Pax { get; set; }
        public PropertyModel Property { get; set; }
        public ServiceModel Service { get; set; }
        public PropertyRatePlanModel RatePlan { get; set; }
    }
}
