﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class BookingAncillaryModel
    {
        [Key]
        public long BookingAncillaryId { get; set; }
        public long BookingId { get; set; }
        public long AncillaryId { get; set; }
        public long RatePlanId { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public BookingsModel Booking { get; set; }
    }
}
