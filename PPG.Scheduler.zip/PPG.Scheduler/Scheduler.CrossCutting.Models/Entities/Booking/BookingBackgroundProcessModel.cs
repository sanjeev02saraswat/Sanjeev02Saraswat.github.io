﻿using Scheduler.CrossCutting.Enums;
using Scheduler.CrossCutting.Enums.Booking;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
   public class BookingBackgroundProcessModel
    {
        [Key]
        public long BookingProcessId { get; set; }
        public long BookingId { get; set; }
        [Column("Status")]
        public string StatusString
        {
            get { return PMSStatus.ToString(); }
             set
            {
                PMSStatus = value.ParseEnum<BookingRoomStayStatus>();
            }
        }
        [NotMapped]
        public BookingRoomStayStatus PMSStatus { get; set; }
        public Int16 ProcessState { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public Int16 RetryCount { get; set; }
        public string OasisResponse { get; set; }
    }
}
