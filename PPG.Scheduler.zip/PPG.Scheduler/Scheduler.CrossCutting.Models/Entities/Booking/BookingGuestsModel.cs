﻿using Scheduler.CrossCutting.Enums.Booking;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class BookingGuestsModel
    {
        [Key]
        public long GuestId { get; set; }
        public long BookingId { get; set; }
        [Column("GuestType")]
        public string GuestTypeString
        {
            get { return GuestType.ToString(); }
            private set
            {
                GuestType = value.ParseEnum<GuestType>();
            }
        }
        [NotMapped]
        public GuestType GuestType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public long? ServiceId { get; set; }

        public BookingsModel Booking { get; set; }
    }
}
