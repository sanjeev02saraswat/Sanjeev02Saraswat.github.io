﻿using Scheduler.CrossCutting.Enums.RatePlan;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class BookingServicesModel
    {
        [Key]
        public long BookingServiceId { get; set; }
        public long BookingId { get; set; }
        public long ServiceId { get; set; }
        public long RatePlanId { get; set; }
        [Column("PricingType")]
        public string PricingString
        {
            get { return PricingType.ToString(); }
            private set
            {
                PricingType = value.ParseEnum<PolicyPricing>();
            }
        }
        [NotMapped]
        public PolicyPricing PricingType { get; set; }
        public decimal TotalServicePrice { get; set; }
        public string Slots { get; set; }
        public string Taxes { get; set; }
        public string ServiceName { get; set; }
        public string ServiceDesc { get; set; }
        public string RatePlanName { get; set; }
        public int AdultCount { get; set; }
        public int Child1Count { get; set; }
        public int Child2Count { get; set; }
        public int Child1Age { get; set; }
        public int Child2Age { get; set; }
        public string ServiceReservationId { get; set; }
        public System.DateTime MinSlotStartTime { get; set; }
        public System.DateTime MaxSlotEndTime { get; set; }
        public BookingsModel Booking { get; set; }
    }
}
