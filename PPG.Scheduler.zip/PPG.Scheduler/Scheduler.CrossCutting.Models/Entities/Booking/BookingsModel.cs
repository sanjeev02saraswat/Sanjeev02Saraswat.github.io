﻿using Scheduler.CrossCutting.Enums.Booking;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class BookingsModel
    {
        [Key]
        public long BookingId { get; set; }
        public string OrderRefNo { get; set; }
        public string VerificationID { get; set; }
        public long PropertyId { get; set; }
        public string ChannelName { get; set; }
        public string Currency { get; set; }
        public decimal TotalBookingPrice { get; set; }
        public DateTime BookingDate { get; set; }
        [Column("Status")]
        public string StatusString
        {
            get { return Status.ToString(); }
            private set
            {
                Status = value.ParseEnum<BookingStatus>();
            }
        }
        [NotMapped]
        public BookingStatus Status { get; set; }
        public string PaymentType { get; set; }
        public string PaymentId { get; set; }
        public string PaymentTransactionId { get; set; }
        public DateTime PaymentDateTime { get; set; }
        public string Comments { get; set; }
        public string SpecialRequest { get; set; }
        public string Source { get; set; }
        public string PropertyName { get; set; }
        public bool IsAvailed { get; set; }

        public ICollection<BookingGuestsModel> Guests { get; set; }
        public ICollection<BookingServicesModel> Services { get; set; }
        public ICollection<BookingAncillaryModel> Ancillary { get; set; }
        public PropertyModel Property { get; set; }

        public string PromoCode { get; set; }
    }
}
