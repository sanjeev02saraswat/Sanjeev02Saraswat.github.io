﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
 public class ChannelInventoryRuleModel
    {
        [Key]
        public long InventoryRuleId { get; set; }
        public long PropertyId { get; set; }
        public long ChannelId { get; set; }
        public long ServiceId { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateTo { get; set; }
        public string DaysOfWeek { get; set; }
        public int CloseRuleCount { get; set; }
        public int CapRuleCount { get; set; }
        public ChannelModel Channel { get; set; }

    }
}
