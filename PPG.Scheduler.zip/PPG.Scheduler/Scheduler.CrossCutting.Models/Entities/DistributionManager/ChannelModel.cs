﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class ChannelModel
    {
        [Key]
        public long ChannelID { get; set; }
        public long PropertyId { get; set; }
        public long OTAId { get; set; }
        public string ChannelPropertyId { get; set; }
        public string ChannelName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool Activate { get; set; }
        public ICollection<ChannelInventoryRuleModel> InventoryRules { get; set; }
        public ICollection<ChannelServiceRateMappingModel> ServicesAndRates { get; set; }

    }
}
