﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class ChannelServiceRateMappingModel
    {
        [Key]
        public long ID { get; set; }
        public long ChannelId { get; set; }
        public long OTAServiceRateId { get; set; }
        public long PropServiceId { get; set; }
        public long PropRateId { get; set; }        
        public string StartTime { get; set; }      
        public string EndTime { get; set; }
        public ChannelModel Channel { get; set; }
        public ServiceModel Service { get; set; }
        //public RatePlanModel Service { get; set; }
        public OTAServiceRateModel OTAServiceRate { get; set; }

    }
}
