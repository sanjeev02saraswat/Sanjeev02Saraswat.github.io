﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class OTAServiceRateModel
    {
        [Key]
        public long OTAServiceRateId { get; set; }
        public int OTAId { get; set; }
        public string ChannelId { get; set; }      
        public string ServiceRateName { get; set; }  
        
    }
}
