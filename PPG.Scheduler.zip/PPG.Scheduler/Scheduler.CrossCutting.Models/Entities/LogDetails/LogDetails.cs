﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class LogDetails
    {
        public LogDetails()
        {
            Timestamp = DateTime.Now;
        }

        public string Project { get; set; }
        public string Layer { get; set; }
        public string Location { get; set; }
        public string Hostname { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Message { get; set; }
        public DateTime Timestamp { get; private set; }
        public string CorrelationId { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public Dictionary<string, object> AdditionalInfo { get; set; }
        public Exception Excep { get; set; }
    }

    //private LogDetails GetLogDetails(string message)
    //{
    //    return new LogDetails
    //    {
    //        Project = Environment.CurrentDirectory,
    //        Layer = "Web Layer",
    //        Location = "Authentication Controller",
    //        Hostname = Environment.MachineName,
    //        Message = message,
    //        UserName = Environment.UserName
    //    };
    //}


}
