﻿using Scheduler.CrossCutting.Enums.PromoCode;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Scheduler.CrossCutting.Models.Entities
{
    public class PromoCodeModel
    {
        public long PromoCodeId { get; set; }
        public long CampaignId { get; set; }
        public string PromoCodeName { get; set; }
        public System.DateTime DurationStart { get; set; }
        public System.DateTime DurationEnd { get; set; }
        public PromoValueType DiscountType { get; set; }
        public decimal DiscountValue { get; set; }
        public long RedeemedCount { get; set; }
        public long RedemptionCount { get; set; }
        public string Applicability { get; set; }
        public CampaignModel CampaignMapping { get; set; }
        public ICollection<PromoCodeParamModel> PromoCodeMapping { get; set; } = new List<PromoCodeParamModel>();
    }
    public class CampaignModel
    {
        [Key]
        public long CampaignId { get; set; }
        public string CampaignName { get; set; }
        public ICollection<PromoCodeModel> PromoCodeMap { get; set; } = new List<PromoCodeModel>();

    }
}
