﻿namespace Scheduler.CrossCutting.Models.Entities
{
    public class PromoCodeParamModel
    {
        public int Id { get; set; }
        public long PromoCodeId { get; set; }
        public long PromoSetupId { get; set; }
        public long PropertyId { get; set; }
        public long RatePlanId { get; set; }
        public long ServiceId { get; set; }
        public string LocationId { get; set; }
        public PromoCodeModel PromoCode { get; set; }
    }
}
