﻿using Scheduler.CrossCutting.Enums;
using Scheduler.CrossCutting.Enums.Property;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyModel
    {
        public long PropertyId { get; set; }
        public string PropertyType { get; set; }        
        public string PropertyName { get; set; }
        public string PropertyCode { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Airport { get; set; }
        public string Terminal { get; set; }
        public string TerminalPoint { get; set; }
        public string PhoneCode { get; set; }
        public string PhoneNumber { get; set; }
        public string FaxCode { get; set; }
        public string FaxNumber { get; set; }
        public string HotelURL { get; set; }
        public bool IsActive { get; set; }
        public string WASLocationId { get; set; }

        public ICollection<PropertyParamModel> PropertyParams { get; set; }

        public ICollection<ServiceModel> Services { get; set; }
    }
}
