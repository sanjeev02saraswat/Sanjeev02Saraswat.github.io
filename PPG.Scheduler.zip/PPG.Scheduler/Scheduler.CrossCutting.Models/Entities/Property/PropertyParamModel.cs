﻿using Scheduler.CrossCutting.Enums.Property;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyParamModel
    {
        private string _key;
        public int PropertyParamId { get; set; }
        public long PropertyId { get; set; }
        public PropertyParamKeys ParamKey
        {
            set
            {
                _key = value.ToString();
            }
        }
        public string Key
        {
            get
            {
                return _key;
            }
        }
        public string Values { get; set; }
        public PropertyModel Property { get; set; }

    }
}
