﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyServiceModel
    {
        public Int64 Id { get; set; }
        public Int64 ServiceId { get; set; }
        public Int64 PropertyId { get; set; }
    }
}
