﻿using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyRatePlanModel
    {
        public Int64 RatePlanId { get; set; }
        public Int64 PropertyId { get; set; }
        public string RateModel { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        
        public ICollection<PropertyRatePlanParamsModel> RatePlanParams { get; set; } = new List<PropertyRatePlanParamsModel>();
        public ICollection<PropertyRatePlanServiceModel> RatePlanService { get; set; } = new List<PropertyRatePlanServiceModel>();
        public ICollection<TaxesRatePlansModel> TaxesRatePlans { get; set; } = new List<TaxesRatePlansModel>();
        public ICollection<TermsandConditionsLinkedRateModel> TermsConditionsRatePlans { get; set; } = new List<TermsandConditionsLinkedRateModel>();
        public ICollection<AncillaryRatePlanModel> AncillaryRatePlans { get; set; } = new List<AncillaryRatePlanModel>();
        //public ICollection<string> Photos { get; set; }
    }
}
