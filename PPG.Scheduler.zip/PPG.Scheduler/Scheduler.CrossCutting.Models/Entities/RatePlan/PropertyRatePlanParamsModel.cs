﻿using Scheduler.CrossCutting.Enums.RatePlan;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyRatePlanParamsModel
    {
        [Key]
        public Int64 RatePlanParamId { get; set; }
        [Column("Key")]
        public string ParamKey
        {
            get { return Key.ToString(); }
            private set
            {
                Key = value.ParseEnum<RatePlanParamKeys>();
            }
        }
        [NotMapped]
        public RatePlanParamKeys Key { get; set; }
        public string Values { get; set; }
        public long RatePlanId { get; set; }
        public PropertyRatePlanModel PropertyRatePlan { get; set; }
    }
}
