﻿using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class PropertyRatePlanServiceModel
    {
        
        public long Id { get; set; }
        public long ServiceId { get; set; }
        public long RatePlanId { get; set; }
        public ServiceModel Service { get; set; }
        public PropertyRatePlanModel PropertyRatePlan { get; set; }
    }
}
