﻿namespace Scheduler.CrossCutting.Models.Entities
{
    public class RatePlanModel
    {
        public long RatePlanId { get; set; }
        public long PropertyId { get; set; }
    }
}
