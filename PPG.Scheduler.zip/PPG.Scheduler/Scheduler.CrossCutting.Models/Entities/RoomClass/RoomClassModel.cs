﻿using Scheduler.CrossCutting.Enums.Service;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class RoomClassModel
    {
        public long RoomClassId { get; set; }
        public string RoomClassName { get; set; }
        [Column("ServiceTypes")]
        public string ServiceTypesString
        {
            get { return string.Join(",", ServiceTypes); }
            private set
            {
                ServiceTypes = value.Split(",").Select(x => x.ParseEnum<ServiceType>()).ToArray();
            }
        }
        [NotMapped]
        public ServiceType[] ServiceTypes { get; set; }
    }
}
