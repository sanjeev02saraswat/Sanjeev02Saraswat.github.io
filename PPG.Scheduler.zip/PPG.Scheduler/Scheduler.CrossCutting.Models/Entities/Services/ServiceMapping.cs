﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities.Services
{
    public class ServiceMapping
    {
        public long ServiceId { get; set; }
        public string ServiceName { get; set; }
        public string ShortDescription { get; set; }
    }
}
