﻿using Scheduler.CrossCutting.Enums.Service;
//using Scheduler.CrossCutting.Models.DTOs.AvailabilityAndPricing;
using Scheduler.CrossCutting.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class ServiceModel
    {
        public long PropertyId { get; set; }
        public long ServiceId { get; set; }
        public string ServiceName { get; set; }
        public string Timing { get; set; }
        [Column("ServiceType")]
        public string ServiceTypeString
        {
            get { return ServiceType.ToString(); }
            private set
            {
                ServiceType = value.ParseEnum<ServiceType>();
            }
        }
        [NotMapped]
        public ServiceType ServiceType { get; set; }
        public string ShortDescription { get; set; }      
        public string WASServiceId { get; set; }
        public PropertyModel Property { get; set; }
        public ICollection<PropertyRatePlanServiceModel> ServiceRatePlans { get; set; } = new List<PropertyRatePlanServiceModel>();
        public ICollection<ServiceParamModel> ServiceParams { get; set; } = new List<ServiceParamModel>();
        public ICollection<AvailabilityModel> InvAvailable { get; set; } = new List<AvailabilityModel>();
        public ICollection<InventoryPriceModel> InvPrice { get; set; } = new List<InventoryPriceModel>();
    }
}
