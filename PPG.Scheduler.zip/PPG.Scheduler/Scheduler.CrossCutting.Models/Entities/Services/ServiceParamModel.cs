﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Scheduler.CrossCutting.Enums.Service;
using Scheduler.CrossCutting.Utils.Extensions;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class ServiceParamModel
    {
        public Int64 ServiceParamId { get; set; }
        [Column("Key")]
        public string KeyString
        {
            get { return Key.ToString(); }
            private set
            {
                Key = value.ParseEnum<ServiceParamKeys>();
            }
        }
        [NotMapped]
        public ServiceParamKeys Key { get; set; }
        public string Value { get; set; }
        public long ServiceId { get; set; }
        public ServiceModel Service { get; set; }
    }
}
