﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities.Services
{
    public class ServicePhotosModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
        public string Width { get; set; }
        public string Height { get; set; }
        public string ImageRatio { get; set; }
    }
}