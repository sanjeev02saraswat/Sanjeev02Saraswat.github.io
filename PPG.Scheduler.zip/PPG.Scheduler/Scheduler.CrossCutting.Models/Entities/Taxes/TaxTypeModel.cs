﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class TaxTypeModel
    {
        [Key]
        public long TaxTypeID { get; set; }
        public string TaxTypeName { get; set; }
    }
}
