﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.Entities
{
   public class TaxesModel
    {
        [Key]
        public long TaxId { get; set; }
        public long PropertyId { get; set; }
        public string TaxName { get; set; }
        public string TaxType { get; set; }
        public string Value { get; set; }
        public string ValueType { get; set; }
        public string Currency { get; set; }

        public ICollection<TaxesRatePlansModel> TaxesRatePlans { get; set; } = new List<TaxesRatePlansModel>();


    }
}
