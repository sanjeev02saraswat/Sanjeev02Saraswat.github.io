﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using Scheduler.CrossCutting.Enums.Taxes;
using System.ComponentModel.DataAnnotations.Schema;
using Scheduler.CrossCutting.Utils.Extensions;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class TaxesRatePlansModel
    {

        [Key]
        public long TaxParamId { get; set; }
        public long TaxId { get; set; }
        public long RatePlanId { get; set; }
        [Column("BasedOn")]
        public string BasedOnString
        {
            get { return BasedOn.ToString(); }
            private set
            {
                BasedOn = value.ParseEnum<TaxComputationBasedOn>();
            }
        }
        [NotMapped]
        public TaxComputationBasedOn BasedOn { get; set; }
        [Column("Stay")]
        public string StayString
        {
            get { return Stay.ToString(); }
            private set
            {
                Stay = value.ParseEnum<TaxComputationStay>();
            }
        }
        [NotMapped]
        public TaxComputationStay Stay { get; set; }
        public bool ConfiguredPrice { get; set; }
        [Column("PriceOn")]
        public string PriceOnString
        {
            get { return PriceOn.ToString(); }
            private set
            {
                PriceOn = value.ParseEnum<TaxPriceOn>();
            }
        }
        [NotMapped]
        public TaxPriceOn PriceOn { get; set; }
        public TaxesModel Taxes { get; set; }
        public PropertyRatePlanModel PropertyRatePlan { get; set; }
    }
}
