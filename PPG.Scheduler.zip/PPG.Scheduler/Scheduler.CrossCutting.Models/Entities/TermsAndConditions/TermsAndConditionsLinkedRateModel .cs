﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class TermsandConditionsLinkedRateModel
    {
        [Key]
        public long TermsLinkedRateId { get; set; }
        public long TermsId { get; set; }
        public long RatePlanId { get; set; }
        public PropertyRatePlanModel RatePlan { get; set; }
        public TermsandConditionsModel TermsAndConditions { get; set; }
    }
}
