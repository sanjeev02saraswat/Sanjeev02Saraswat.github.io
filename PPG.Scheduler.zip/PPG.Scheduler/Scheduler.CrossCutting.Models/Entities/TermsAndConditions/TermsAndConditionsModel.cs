﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class TermsandConditionsModel
    {
        [Key]
        public long TermsId { get; set; }
        public long PropertyId { get; set; }
        [Required]
        [StringLength(30)]
        public string Name { get; set; }
        [Required]
        [StringLength(1024)]
        public string Descriptions { get; set; }

        public ICollection<TermsandConditionsLinkedRateModel> LinkedRatePlans { get; set; } = new List<TermsandConditionsLinkedRateModel>();
    }
}
