﻿using Scheduler.CrossCutting.Enums;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class RoleClaimModel
    {
        ////public Roles Role { get; set; }

        ////public virtual UserModel User { get; set; }

        ////public long UserId { get; set; }

        public long RoleClaimId { get; set; }

        public Roles RolesId { get; set; }
        public ClaimType ClaimTypeId { get; set; }

        public string Value { get; set; }


    }
}
