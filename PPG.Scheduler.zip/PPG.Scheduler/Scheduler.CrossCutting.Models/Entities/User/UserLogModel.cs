﻿using Scheduler.CrossCutting.Enums;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class UserLogModel
    {
        public DateTime DateTime { get; set; }

        public LogType LogType { get; set; }

        public string Message { get; set; }

        public long UserId { get; set; }

        public long UserLogId { get; set; }

        public virtual UserModel User { get; set; }

        public ICollection<UserLogParamModel> UserLogParams { get; set; }
    }
}
