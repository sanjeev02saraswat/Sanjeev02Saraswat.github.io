﻿using Scheduler.CrossCutting.Enums.UserLog;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class UserLogParamModel
    {
        //private string _key;
        public int UserLogParamId { get; set; }
      //  public long PropertyId { get; set; }
        public long UserLogId { get; set; }
        //public UserLogParamKeys ParamKey
        //{
        //    set
        //    {
        //        _key = value.ToString();
        //    }
        //}
        //public string Key
        //{
        //    get
        //    {
        //        return _key;
        //    }
        //}

        public string Key { get; set; }
        public string Values { get; set; }
        public UserLogModel UserLog { get; set; }
    }
}
