﻿using Scheduler.CrossCutting.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class UserModel
    {
        public string Email { get; set; }

        public string Login { get; set; }

        public string Name { get; set; }

        public string Password { get; set; }

        public string LastPassword { get; set; }

        public string SecondLastPassword { get; set; }

        public Status Status { get; set; }

        public string Surname { get; set; }

        public long UserId { get; set; }

        public int LoginAttempt { get; set; }

        public DateTime CreatedOn { get; set; }

        public DateTime LastUpdated { get; set; }

        public DateTime PasswordExpiryDate { get; set; }

        public string TempPassword { get; set; }

        public Roles Role { get; set; }

        public DateTime LastActivityDate { get; set; }

        public virtual ICollection<UserLogModel> UsersLogs { get; set; } = new HashSet<UserLogModel>();
    }
}
