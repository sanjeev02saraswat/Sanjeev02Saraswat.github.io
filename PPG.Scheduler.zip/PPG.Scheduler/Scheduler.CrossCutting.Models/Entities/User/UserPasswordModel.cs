﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.CrossCutting.Models
{
    public class UserPasswordModel
    {
        private bool includeLowercase = true;
        private bool includeUppercase = true;
        private bool includeNumeric = true;
        private bool includeSpecial = true;
        public bool IncludeLowercase
        {
            get
            {
                return includeLowercase;
            }
            set
            {
                includeLowercase = value;
            }
        }
        public bool IncludeUppercase
        {
            get
            {
                return includeUppercase;
            }
            set
            {
                includeUppercase = value;
            }
        }
        public bool IncludeNumeric
        {
            get
            {
                return includeNumeric;
            }
            set
            {
                includeNumeric = value;
            }
        }
        public bool IncludeSpecial
        {
            get
            {
                return includeSpecial;
            }
            set
            {
                includeSpecial = value;
            }
        }
        public int LengthOfPassword { get; set; }

    }
}
