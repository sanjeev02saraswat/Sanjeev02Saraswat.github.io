﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Scheduler.CrossCutting.Models.Entities
{
    public class UserPropertyMappingModel
    {
        [Key]
        public long UserPropertyMappingId { get; set; }
        public long UserId { get; set; }
        public long PropertyId { get; set; }
    }
}
