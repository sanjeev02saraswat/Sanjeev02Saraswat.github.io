﻿using Scheduler.CrossCutting.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Scheduler.CrossCutting.Configuration;
using Scheduler.CrossCutting.Models;
using Scheduler.Infrastructure.AmazonEmailService;
using System.Threading.Tasks;

namespace Scheduler.Infrastructure.AWS.SES
{
    public class BookingReportEmailBuilder
    {
        private IConfiguration Configuration;
        private IHostingEnvironment Environment;

        public BookingReportEmailBuilder(IConfiguration _configuration, IHostingEnvironment _environment)
        {
            Environment = _environment;
            Configuration = _configuration;
        }

        public async Task SendMailMessageForJon()
        {
            MailMessages Message = new MailMessages();
            try
            {
                Message.To = Configuration.ConfigSettings.JonReportConfig.To;
                Message.CC = Configuration.ConfigSettings.JonReportConfig.CC;
                Message.From = Configuration.ConfigSettings.JonReportConfig.From;
                Message.FromTitle = Configuration.ConfigSettings.JonReportConfig.FromTitle;
                Message.Subject = Configuration.ConfigSettings.JonReportConfig.Subject;
                Message.MailBody = "Please FInd Attached Booking Report";
                //Searching in Esther Folder , becasue as per requirement Jon also need Esther Report only
                string path = Path.Combine(Environment.WebRootPath, "Reports", "Esther");
                string[] files = Directory.GetFiles(path, "*.csv", SearchOption.AllDirectories);
                if (files.Length > 0)
                {
                    foreach (string file in files)
                    {
                        FileInfo fileinfo = new FileInfo(file);
                        if (fileinfo.CreationTime.Date.Equals(DateTime.Now.Date))
                        {
                            Message.Attachment = new System.Net.Mail.Attachment(file);
                            await EmailHelper.SendEmailWithAttachment(Message);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public async Task SendMailMessageForEsther()
        {
            MailMessages Message = new MailMessages();
            try
            {

                Message.To = Configuration.ConfigSettings.EstherReportConfig.To;
                Message.CC = Configuration.ConfigSettings.EstherReportConfig.CC;
                Message.BCC = Configuration.ConfigSettings.EstherReportConfig.BCC;
                Message.From = Configuration.ConfigSettings.EstherReportConfig.From;
                Message.FromTitle = Configuration.ConfigSettings.EstherReportConfig.FromTitle;
                Message.Subject = FormatMailSubJect("MonthlyBookingReport");
                Message.MailBody = "Please FInd Attached Monthly Booking Report";
                string path = Path.Combine(Environment.WebRootPath, "Reports", "Esther");
                string[] files = Directory.GetFiles(path, "*.csv", SearchOption.AllDirectories);
                if (files.Length > 0)
                {
                    foreach (string file in files)
                    {
                        FileInfo fileinfo = new FileInfo(file);
                        if (fileinfo.CreationTime.Date.Equals(DateTime.Now.Date))
                        {
                            Message.Attachment = new System.Net.Mail.Attachment(file);
                            await EmailHelper.SendEmailWithAttachment(Message);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public async Task SendMailMessageForServiceLevelBookingReport()
        {
            MailMessages Message = new MailMessages();
            try
            {

                Message.To = Configuration.ConfigSettings.ServiceLevelReportConfig.To;
                Message.CC = Configuration.ConfigSettings.ServiceLevelReportConfig.CC;
                Message.BCC = Configuration.ConfigSettings.ServiceLevelReportConfig.BCC;
                Message.From = Configuration.ConfigSettings.ServiceLevelReportConfig.From;
                Message.FromTitle = Configuration.ConfigSettings.ServiceLevelReportConfig.FromTitle;
                Message.Subject = FormatMailSubJect("ServiceLevelBookingReport"); ;
                Message.MailBody = "Please FInd Attached Service Level Booking Report";
                string path = Path.Combine(Environment.WebRootPath, "Reports", "ServiceLevelBookingReport");
                string[] files = Directory.GetFiles(path, "*.csv", SearchOption.AllDirectories);
                if (files.Length > 0)
                {
                    foreach (string file in files)
                    {
                        FileInfo fileinfo = new FileInfo(file);
                        if (fileinfo.CreationTime.Date.Equals(DateTime.Now.Date))
                        {
                            Message.Attachment = new System.Net.Mail.Attachment(file);
                            await EmailHelper.SendEmailWithAttachment(Message);
                        }
                    }
                }
                //await EmailHelper.SendEmailWithAttachment(Message);
            }
            catch (Exception)
            {

                throw;
            }

        }

        public String FormatMailSubJect(string ReportName)
        {
            string Subject = string.Empty;
            DateTime Today = DateTime.UtcNow;
            try
            {
                if (ReportName == "MonthlyBookingReport")
                {
                    var CurrentMonth = Today.Month;
                    var CurrentYear = Today.Year;
                    if (CurrentMonth == 1)
                    {
                        CurrentYear = CurrentYear - 1;
						CurrentMonth = 13;
                    }
                    DateTime TitleDate = new DateTime(CurrentYear, CurrentMonth - 1, 1);
                    Subject = Configuration.ConfigSettings.EstherReportConfig.Subject + " - " + TitleDate.ToString("MMM yyyy");
                }
                if(ReportName== "ServiceLevelBookingReport")
                {
                    var CurrentMonth = Today.Month;
                    var CurrentYear = Today.Year;
                    if (CurrentMonth == 1)
                    {
                        CurrentYear = CurrentYear - 1;
                    }
                    DateTime TitleDate = new DateTime(CurrentYear, CurrentMonth - 1, 1);
                    Subject = Configuration.ConfigSettings.ServiceLevelReportConfig.Subject ;
                }
            }
            catch (Exception)
            {

                throw;
            }
            return Subject;
        }

    }
}
