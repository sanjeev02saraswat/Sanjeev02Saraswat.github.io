﻿using Amazon;
using Amazon.Runtime;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using Scheduler.CrossCutting.Enums;
using Scheduler.CrossCutting.Models;
using Scheduler.CrossCutting.Models.DTOs;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Scheduler.Infrastructure.AmazonEmailService
{
    public class EmailHelper
    {
        private const string Access_Key_ID = "AKIAJFREKS5N2GSOIHSQ";
        private const string Secret_access_key = "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";
        public static async Task<SESResponse> SendMail(MailMessages mailMesage)
        {
            bool status = false;
            try
            {
                using (var client = new AmazonSimpleEmailServiceClient(RegionEndpoint.USEast1))
                {
                    var sendRequest = new SendEmailRequest
                    {
                        Source = mailMesage.FromTitle + " <" + mailMesage.From + ">",
                        Destination = new Destination
                        {
                            ToAddresses = mailMesage.To.Replace(", ", ",").Split(',').ToList(),
                            CcAddresses = mailMesage.CC?.Replace(", ", ",").Split(',').ToList(),
                            BccAddresses = mailMesage.BCC?.Replace(", ", ",").Split(',').ToList()
                        },
                        Message = new Message
                        {
                            Subject = new Content(mailMesage.Subject),
                            Body = new Body
                            {
                                Html = new Content
                                {
                                    Charset = "UTF-8",
                                    Data = mailMesage.MailBody
                                }
                            }
                        },
                    };

                    var response = await client.SendEmailAsync(sendRequest);
                    status = true;
                }
                return new SESResponse { Status = status, Message = "Email Sent successfully to " + mailMesage.To + " !!" };
            }
            catch (Exception e)
            {
                var logDetails = GetLogDetails("Error in SendMail");
                logDetails.Excep = e;
                //Logger.WriteError(logDetails);
                return new SESResponse { Status = status, Message = e.Message };
            }
        }

        public static async Task<SESResponse> SendEmailWithAttachment(MailMessages mailMessages)
        {
            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailMessages.MailBody, Encoding.UTF8, "text/html");
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(mailMessages.From, mailMessages.FromTitle);
            List<String> toAddresses = mailMessages.To.Replace(", ", ",").Split(',').ToList();

            foreach (String toAddress in toAddresses)
            {
                mailMessage.To.Add(new MailAddress(toAddress));
            }

            List<String> CCAddresses = new List<string>();
            if (!string.IsNullOrEmpty(mailMessages.CC))
            {
                CCAddresses = mailMessages.CC.Replace(", ", ",").Split(',').ToList();
                foreach (String CC in CCAddresses)
                {
                    mailMessage.CC.Add(new MailAddress(CC));
                }
            }

            List<String> bccAddresses = new List<string>();
            if (!string.IsNullOrEmpty(mailMessages.BCC))
            {
                bccAddresses = mailMessages.BCC.Replace(", ", ",").Split(',').ToList();
                foreach (String bccAddress in bccAddresses)
                {
                    mailMessage.Bcc.Add(new MailAddress(bccAddress));
                }
            }

            mailMessage.Subject = mailMessages.Subject;
            mailMessage.SubjectEncoding = Encoding.UTF8;

            if (mailMessages.MailBody != null)
            {
                mailMessage.AlternateViews.Add(htmlView);
            }

            if (mailMessages.Attachment != null)
            {
                mailMessage.Attachments.Add(mailMessages.Attachment);
            }
            if (mailMessages.ExtraAttachments != null && mailMessages.ExtraAttachments.Count > 0)
            {
                mailMessages.ExtraAttachments.ForEach(item => mailMessage.Attachments.Add(item));
            }
            RawMessage rawMessage = new RawMessage();
            using (MemoryStream memoryStream = ConvertMailMessageToMemoryStream(mailMessage))
            {
                rawMessage.Data = memoryStream;
            }

            SendRawEmailRequest request = new SendRawEmailRequest();
            request.RawMessage = rawMessage;
            request.Destinations = toAddresses;
            request.Source = mailMessage.From.Address;

            try
            {
                using (var client = new AmazonSimpleEmailServiceClient(new BasicAWSCredentials(Access_Key_ID, Secret_access_key), RegionEndpoint.USEast1))
                //using (var client = new AmazonSimpleEmailServiceClient(RegionEndpoint.USEast1))
                {
                    var response = await client.SendRawEmailAsync(request);
                    if (bccAddresses != null && bccAddresses.Any())
                    {
                        request.Destinations = bccAddresses;
                        response = await client.SendRawEmailAsync(request);
                    }
                    return new SESResponse { Status = true, Message = "Email Sent successfully to " + toAddresses.ToArray()[0] + " !!" };
                }
            }
            catch (Exception ex)
            {
                LogDetails logDetails = new LogDetails();
                logDetails = GetLogDetails("AWSSES : SendMail - " + ex.Message + "|" + ex.InnerException.ToString());
                //await Task.Factory.StartNew(() =>
                //{
                //    //Logger.WriteError(logDetails);
                //});
                return new SESResponse { Status = false, Message = "Email Sending failed " + toAddresses.ToArray()[0] + " !!" };
            }

        }

        public static MemoryStream ConvertMailMessageToMemoryStream(MailMessage message)
        {
            Assembly assembly = typeof(SmtpClient).Assembly;
            Type mailWriterType = assembly.GetType("System.Net.Mail.MailWriter");
            MemoryStream fileStream = new MemoryStream();
            ConstructorInfo mailWriterContructor = mailWriterType.GetConstructor(BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(Stream) }, null);
            object mailWriter = mailWriterContructor.Invoke(new object[] { fileStream });
            MethodInfo sendMethod = typeof(MailMessage).GetMethod("Send", BindingFlags.Instance | BindingFlags.NonPublic);
            sendMethod.Invoke(message, BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { mailWriter, true, true }, null);
            MethodInfo closeMethod = mailWriter.GetType().GetMethod("Close", BindingFlags.Instance | BindingFlags.NonPublic);
            closeMethod.Invoke(mailWriter, BindingFlags.Instance | BindingFlags.NonPublic, null, new object[] { }, null);
            return fileStream;
        }
               
        public static string GetAttachmentPath(string pdfFileName)
        {
            return Path.Combine("PDFPath", pdfFileName);
        }

        public static string ReadTemplate(string templatePath)
        {
            string fileContent;
            using (StreamReader reader = File.OpenText(templatePath))
            {
                fileContent = reader.ReadToEnd();
            }
            return fileContent;
        }

        public static string ParseTemplate(string templateContent, dynamic model)
        {
            string fileContent;
            using (StreamReader reader = File.OpenText(templateContent))
            {
                fileContent = reader.ReadToEnd();
            }
            return fileContent;
        }

        private static LogDetails GetLogDetails(string message)
        {
            return new LogDetails()
            {
                Project = Environment.CurrentDirectory,
                Layer = "AWS Email Helper",
                Location = "AWSEmailHelper.cs",
                Hostname = Environment.MachineName,
                Message = message,
                UserName = Environment.UserName
            };
        }

    }
}
