﻿namespace Scheduler.Infrastructure.AmazonEmailService
{
    public class SESResponse
    {
        public string Message { get; set; }
        public bool Status { get; set; }
    }
}
