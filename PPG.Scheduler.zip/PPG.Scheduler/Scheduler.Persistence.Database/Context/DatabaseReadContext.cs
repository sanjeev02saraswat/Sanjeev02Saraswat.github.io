﻿using Microsoft.EntityFrameworkCore;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.EntityTypeConfigurations;

namespace Scheduler.Persistence.Database.Context
{
    public class DatabaseReadContext : DbContext
    {
        public DbSet<UserModel> Users { get; set; }
        public DbSet<UserPropertyMappingModel> UserPropertyMapping { get; set; }
        public DbSet<UserLogModel> UsersLogs { get; set; }
        public DbSet<UserLogParamModel> UserLogsParam { get; set; }
        public DbSet<RoleClaimModel> RoleClaims { get; set; }
        public DbSet<PropertyModel> Property { get; set; }
        public DbSet<PropertyParamModel> PropertyParam { get; set; }
        public DbSet<ServiceModel> Service { get; set; }
        public DbSet<ServiceParamModel> ServiceParam { get; set; }
        public DbSet<PropertyRatePlanModel> PropertyRatePlan { get; set; }
        public DbSet<PropertyRatePlanParamsModel> PropertyRatePlanParam { get; set; }
        public DbSet<PropertyRatePlanServiceModel> PropertyRatePlanService { get; set; }
        public DbSet<AncillaryModel> Ancillary { get; set; }
        public DbSet<RoomClassModel> RoomClass { get; set; }
        public DbSet<AncillaryRatePlanModel> AnchillaryRatePlans { get; set; }
        public DbSet<AvailabilityModel> Inventory { get; set; }
        public DbSet<InventoryPriceModel> InventoryPrice { get; set; }
        public DbSet<TaxesModel> Taxes { get; set; }
        public DbSet<TaxesRatePlansModel> TaxesRatePlans { get; set; }
        public DbSet<ChannelModel> Channels { get; set; }
        public DbSet<TaxTypeModel> TaxType { get; set; }
        public DbSet<TermsandConditionsModel> TermsAndConditions { get; set; }
        public DbSet<ChannelInventoryRuleModel> InventoryRules { get; set; }
        public DbSet<ChannelServiceRateMappingModel> ChannelServicesAndRates { get; set; }
        public DbSet<OTAServiceRateModel> OTAServiceRates { get; set; }

        public DbSet<BookingsModel> Bookings { get; set; }
        public DbSet<BookingServicesModel> BookingServices { get; set; }
        public DbSet<BookingAncillaryModel> BookingAncillary { get; set; }
        public DbSet<BookingGuestsModel> BookingGuests { get; set; }
        public DbSet<TermsandConditionsLinkedRateModel> TermsandConditionsLinkedRates { get; set; }

        public DatabaseReadContext(DbContextOptions<DatabaseReadContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .ApplyConfiguration(new UserEntityTypeConfiguration())
                .ApplyConfiguration(new UserPropertyMappingEntityTypeConfiguration())
                .ApplyConfiguration(new UserLogEntityTypeConfiguration())
                .ApplyConfiguration(new UserLogParamEntityTypeConfiguration())
                .ApplyConfiguration(new RoleClaimEntityTypeConfiguration())
                .ApplyConfiguration(new PropertyConfiguration())
                .ApplyConfiguration(new PropertyParamConfiguration())
                .ApplyConfiguration(new ServicesConfiguration())
                .ApplyConfiguration(new ServicesParamConfiguration())
                .ApplyConfiguration(new PropertyRatePlanConfiguration())
                .ApplyConfiguration(new RoomClassConfiguration())
                .ApplyConfiguration(new PropertyRatePlanParamsConfiguration())
                .ApplyConfiguration(new PropertyRatePlanServiceConfiguration())
                .ApplyConfiguration(new AncillaryConfiguration())
                .ApplyConfiguration(new AncillaryRatePlanConfiguration())
                .ApplyConfiguration(new InventoryAvailabilityConfiguration())
                .ApplyConfiguration(new InventoryPriceConfiguration())
                .ApplyConfiguration(new TaxesConfiguration())
                .ApplyConfiguration(new ChannelConfiguration())
                .ApplyConfiguration(new TaxesRatePlansConfiguration())
                .ApplyConfiguration(new TaxTypeConfiguration())
                .ApplyConfiguration(new TermsAndConditionsConfiguration())
                .ApplyConfiguration(new InventoryRuleConfiguration())
                .ApplyConfiguration(new ChannelServicesAndRatesConfiguration())
                .ApplyConfiguration(new OTAServiceRateModelConfiguration())
                .ApplyConfiguration(new InventoryRuleConfiguration())
                .ApplyConfiguration(new ChannelServicesAndRatesConfiguration())
                .ApplyConfiguration(new BookingsConfiguration())
                .ApplyConfiguration(new BookingServicesConfiguration())
                .ApplyConfiguration(new BookingAncillaryConfiguration())
                .ApplyConfiguration(new BookingGuestsConfiguration())
                .ApplyConfiguration(new TermsAndConditionsLinkedRatesConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}
