﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
   public class AncillaryConfiguration : IEntityTypeConfiguration <AncillaryModel>
    {
        public void Configure(EntityTypeBuilder<AncillaryModel> builder)
        {            
            builder.HasKey(e => e.AncillaryId);
            //builder.Property(e => e.AncillaryId).ValueGeneratedOnAdd();
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.AncillaryName).HasMaxLength(50).IsRequired();
            builder.Property(e => e.ShortDescription).IsRequired();
            builder.Property(e => e.CalculationString);
            builder.Property(e => e.ChildPrice);
            builder.Property(e => e.Currency);
            builder.Property(e => e.Price);

           builder.HasMany(e => e.AncillaryRatePlans).WithOne(e => e.Ancillary).HasForeignKey(e => e.AncillaryId);
        }
    }
}
