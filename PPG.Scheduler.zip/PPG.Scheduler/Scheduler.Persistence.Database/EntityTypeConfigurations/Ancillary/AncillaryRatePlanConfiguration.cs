﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
  public  class AncillaryRatePlanConfiguration : IEntityTypeConfiguration<AncillaryRatePlanModel>
    {
        public void Configure(EntityTypeBuilder<AncillaryRatePlanModel> builder)
        {
            builder.HasKey(e => e.AncillaryRatePlanId);
            builder.Property(e => e.AncillaryId);
            builder.Property(e => e.RatePlanId);
            builder.Property(e => e.AddToPrice);
            builder.Property(e => e.MandatoryString);
            builder.Property(e => e.Order);
          
        }
    }
}
