﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class InventoryPriceConfiguration : IEntityTypeConfiguration<InventoryPriceModel>
    {
        public void Configure(EntityTypeBuilder<InventoryPriceModel> builder)
        {
            builder.HasKey(e => e.Id);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.RatePlanId).IsRequired();
            builder.Property(e => e.ServiceId).IsRequired();
            builder.Property(e => e.InvtPriceDate).IsRequired();
            builder.Property(e => e.Data).IsRequired();
            builder.Property(e => e.Pax).IsRequired();
            
        }
    }
}
