﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class BookingAncillaryConfiguration : IEntityTypeConfiguration<BookingAncillaryModel>
    {
        public void Configure(EntityTypeBuilder<BookingAncillaryModel> builder)
        {
            builder.HasKey(e => e.BookingAncillaryId);
            builder.Property(e => e.BookingId).IsRequired();
            builder.Property(e => e.AncillaryId);
            builder.Property(e => e.Price);
            builder.Property(e => e.Quantity);
            builder.Property(e => e.RatePlanId);
        }
    }
}
