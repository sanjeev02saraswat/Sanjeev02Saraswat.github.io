﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Scheduler.CrossCutting.Models.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class BookingBackgroundProcessConfiguration : IEntityTypeConfiguration<BookingBackgroundProcessModel>
    {
        public void Configure(EntityTypeBuilder<BookingBackgroundProcessModel> builder)
        {
            builder.HasKey(e => e.BookingProcessId);
            builder.Property(e => e.BookingId).IsRequired();
            builder.Property(e => e.StatusString);
            builder.Property(e => e.ProcessState);
            builder.Property(e => e.CreatedDate);
            builder.Property(e => e.LastModifiedDate);
            builder.Property(e => e.RetryCount);            
            builder.Property(e => e.OasisResponse);
        }
    }
}
