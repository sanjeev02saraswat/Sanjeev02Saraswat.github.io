﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class BookingGuestsConfiguration : IEntityTypeConfiguration<BookingGuestsModel>
    {
        public void Configure(EntityTypeBuilder<BookingGuestsModel> builder)
        {
            builder.HasKey(e => e.GuestId);
            builder.Property(e => e.BookingId).IsRequired();
            builder.Property(e => e.GuestTypeString);
            builder.Property(e => e.FirstName);
            builder.Property(e => e.LastName);
            builder.Property(e => e.ServiceId);
            builder.Property(e => e.Email);
            builder.Property(e => e.Age);
            builder.Property(e => e.Address);
        }
    }
}
