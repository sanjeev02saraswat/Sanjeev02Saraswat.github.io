﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class BookingServicesConfiguration : IEntityTypeConfiguration<BookingServicesModel>
    {
        public void Configure(EntityTypeBuilder<BookingServicesModel> builder)
        {
            builder.HasKey(e => e.BookingServiceId);
            builder.Property(e => e.BookingId).IsRequired();
            builder.Property(e => e.AdultCount);
            builder.Property(e => e.Child1Count);
            builder.Property(e => e.Child2Count);
            builder.Property(e => e.RatePlanId);
            builder.Property(e => e.RatePlanName);
            builder.Property(e => e.ServiceDesc);
            builder.Property(e => e.ServiceId);
            builder.Property(e => e.ServiceName);
            builder.Property(e => e.Slots);
            builder.Property(e => e.Taxes);
            builder.Property(e => e.TotalServicePrice);
            builder.Property(e => e.MinSlotStartTime);
            builder.Property(e => e.MaxSlotEndTime);
            builder.Property(e => e.ServiceReservationId);
        }
    }
}
