﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class BookingsConfiguration : IEntityTypeConfiguration<BookingsModel>
    {
        public void Configure(EntityTypeBuilder<BookingsModel> builder)
        {
            builder.HasKey(e => e.BookingId);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.BookingDate);
            builder.Property(e => e.ChannelName).HasMaxLength(5);
            builder.Property(e => e.Comments);
            builder.Property(e => e.OrderRefNo).HasMaxLength(25);
            builder.Property(e => e.VerificationID).HasMaxLength(20);
            builder.Property(e => e.Currency).HasMaxLength(3);
            builder.Property(e => e.IsAvailed);
            builder.Property(e => e.PaymentDateTime);
            builder.Property(e => e.PaymentId);
            builder.Property(e => e.PaymentType);
            builder.Property(e => e.PropertyName);
            builder.Property(e => e.StatusString);
            builder.Property(e => e.Source);
            builder.Property(e => e.SpecialRequest);
            builder.Property(e => e.TotalBookingPrice);

            builder.HasMany(e => e.Guests).WithOne(e => e.Booking).HasForeignKey(e => e.BookingId);
            builder.HasMany(e => e.Services).WithOne(e => e.Booking).HasForeignKey(e => e.BookingId);
            builder.HasMany(e => e.Ancillary).WithOne(e => e.Booking).HasForeignKey(e => e.BookingId);
        }
    }
}
