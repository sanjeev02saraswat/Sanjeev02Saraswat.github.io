﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class ChannelConfiguration : IEntityTypeConfiguration<ChannelModel>
    {
        public void Configure(EntityTypeBuilder<ChannelModel> builder)
        {
            builder.HasKey(e => e.ChannelID);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.ChannelName).IsRequired();
            builder.Property(e => e.ChannelPropertyId).IsRequired();
            builder.Property(e => e.UserName).IsRequired().HasMaxLength(50);
            builder.Property(e => e.Password).IsRequired().HasMaxLength(10);
            builder.Property(e => e.Activate).IsRequired();

            builder.HasMany(e => e.InventoryRules).WithOne(e => e.Channel).HasForeignKey(e => e.ChannelId);
            builder.HasMany(e => e.ServicesAndRates).WithOne(e => e.Channel).HasForeignKey(e => e.ChannelId);
            //builder.HasMany(e => e.ServicesAndRates).WithOne(e => e.Channel).HasForeignKey(e => e.ChannelId);
        }
    }
}