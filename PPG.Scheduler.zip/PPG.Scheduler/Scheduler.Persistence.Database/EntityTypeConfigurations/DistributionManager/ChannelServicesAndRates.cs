﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class ChannelServicesAndRatesConfiguration : IEntityTypeConfiguration<ChannelServiceRateMappingModel>
    {
        public void Configure(EntityTypeBuilder<ChannelServiceRateMappingModel> builder)
        {
            builder.HasKey(e => e.ID);
            builder.Property(e => e.ChannelId).IsRequired();
            builder.Property(e => e.OTAServiceRateId).IsRequired();
            builder.Property(e => e.PropRateId).IsRequired();
            builder.Property(e => e.PropServiceId).IsRequired();
            //builder.Property(e => e.ID).IsRequired().ValueGeneratedOnAdd();

            //builder.HasOne(e => e.OTAServiceRate).WithOne(e=>e.ChannelId).HasForeignKey(e => e.ChannelId);
            //builder.HasMany(e => e.ServicesAndRates).WithOne(e => e.Channel).HasForeignKey(e => e.ChannelId);
        }
    }
}