﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class InventoryRuleConfiguration : IEntityTypeConfiguration<ChannelInventoryRuleModel>
    {
        public void Configure(EntityTypeBuilder<ChannelInventoryRuleModel> builder)
        {            
            builder.HasKey(e => e.InventoryRuleId);
            //builder.Property(e => e.InventoryRuleId).ValueGeneratedOnAdd();

            builder.Property(e => e.ChannelId).IsRequired();
            builder.Property(e => e.ServiceId);
            builder.Property(e => e.DateFrom);
            builder.Property(e => e.DateTo);
            builder.Property(e => e.DaysOfWeek).IsRequired().HasMaxLength(15);
            builder.Property(e => e.CloseRuleCount);
            builder.Property(e => e.CapRuleCount);          
        }
    }
}