﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class OTAServiceRateModelConfiguration : IEntityTypeConfiguration<OTAServiceRateModel>
    {
        public void Configure(EntityTypeBuilder<OTAServiceRateModel> builder)
        {
            builder.HasKey(e => e.OTAServiceRateId);
            //builder.Property(e => e.Id).IsRequired().ValueGeneratedOnAdd();
            builder.Property(e => e.ChannelId).IsRequired();
            builder.Property(e => e.ServiceRateName);          
        }
    }
}