﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class CampaignConfiguration : IEntityTypeConfiguration<CampaignModel>
    {
        public void Configure(EntityTypeBuilder<CampaignModel> builder)
        {
            builder.HasKey(e => e.CampaignId);
            builder.Property(e => e.CampaignName).IsRequired();

            builder.HasMany(e => e.PromoCodeMap).WithOne(e => e.CampaignMapping).HasForeignKey(e => e.CampaignId);
        }
    }    
}
