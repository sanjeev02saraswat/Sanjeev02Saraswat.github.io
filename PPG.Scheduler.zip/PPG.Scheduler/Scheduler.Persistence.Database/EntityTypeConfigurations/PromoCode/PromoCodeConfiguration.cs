﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PromoCodeConfiguration : IEntityTypeConfiguration<PromoCodeModel>
    {
        public void Configure(EntityTypeBuilder<PromoCodeModel> builder)
        {
            builder.HasKey(e => e.PromoCodeId);
            builder.Property(e => e.CampaignId).IsRequired();
            builder.Property(e => e.PromoCodeName).IsRequired();
            builder.Property(e => e.DurationStart).IsRequired();
            builder.Property(e => e.DurationEnd).IsRequired();
            builder.Property(e => e.DiscountType).IsRequired();
            builder.Property(e => e.DiscountValue).IsRequired();
            builder.Property(e => e.RedemptionCount).IsRequired();
            builder.Property(e => e.RedeemedCount);
            builder.Property(e => e.Applicability).IsRequired();
            builder.HasMany(e => e.PromoCodeMapping).WithOne(e => e.PromoCode).HasForeignKey(e => e.PromoCodeId);

        }
    }    
}
