﻿using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PromoCodeParamConfiguration : IEntityTypeConfiguration<PromoCodeParamModel>
    {
        public void Configure(EntityTypeBuilder<PromoCodeParamModel> builder)
        {
            builder.HasKey(e => e.Id);
            builder.Property(e => e.PromoCodeId);
            builder.Property(e => e.PromoSetupId);
            builder.Property(e => e.LocationId);
            builder.Property(e => e.PropertyId);
            builder.Property(e => e.RatePlanId);
            builder.Property(e => e.ServiceId);

        }
    }
}
