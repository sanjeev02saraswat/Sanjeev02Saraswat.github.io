﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PropertyConfiguration : IEntityTypeConfiguration<PropertyModel>
    {
        public void Configure(EntityTypeBuilder<PropertyModel> builder)
        {
            builder.HasKey(e => e.PropertyId);
            builder.Property(e => e.PropertyName).HasMaxLength(75).IsRequired();
            builder.Property(e => e.PropertyCode);
            builder.Property(e => e.PropertyType).IsRequired();
            builder.Property(e => e.Address).IsRequired().HasMaxLength(150);
            builder.Property(e => e.City).IsRequired().HasMaxLength(50);
            builder.Property(e => e.Country).IsRequired();
            builder.Property(e => e.State).HasMaxLength(50); 
            builder.Property(e => e.ZipCode).HasMaxLength(10);
            builder.Property(e => e.PhoneCode).HasMaxLength(30);
            builder.Property(e => e.PhoneNumber).IsRequired().HasMaxLength(30);
            builder.Property(e => e.FaxCode).HasMaxLength(30);
            builder.Property(e => e.FaxNumber).HasMaxLength(30);
            builder.Property(e => e.HotelURL).IsRequired();
            builder.Property(e => e.IsActive).IsRequired();
            builder.Property(e => e.Region).IsRequired().HasMaxLength(50); 
            builder.Property(e => e.Airport).IsRequired(); 
            builder.Property(e => e.Terminal).HasMaxLength(20);
            builder.Property(e => e.TerminalPoint);
            builder.Property(e => e.WASLocationId);

            builder.HasMany(e => e.PropertyParams).WithOne(e => e.Property).HasForeignKey(e => e.PropertyId);
            builder.HasMany(e => e.Services).WithOne(e => e.Property).HasForeignKey(e => e.PropertyId);
        }
    }    
}
