﻿using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PropertyParamConfiguration : IEntityTypeConfiguration<PropertyParamModel>
    {
        public void Configure(EntityTypeBuilder<PropertyParamModel> builder)
        {
            builder.HasKey(e => e.PropertyParamId);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.Key).IsRequired();
            builder.Property(e => e.Values).IsRequired();
        }
    }
}
