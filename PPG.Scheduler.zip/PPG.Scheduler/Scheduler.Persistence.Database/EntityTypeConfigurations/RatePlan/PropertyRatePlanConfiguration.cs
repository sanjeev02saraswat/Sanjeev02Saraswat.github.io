﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PropertyRatePlanConfiguration : IEntityTypeConfiguration<PropertyRatePlanModel>
    {
        public void Configure(EntityTypeBuilder<PropertyRatePlanModel> builder)
        {
            builder.HasKey(e => e.RatePlanId);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.Name).IsRequired().HasMaxLength(50);
            builder.Property(e => e.Description).IsRequired().HasMaxLength(300);
            builder.Property(e => e.RateModel).IsRequired();
           
            //builder.Property(e => e.Photos);
            builder.HasMany(e => e.RatePlanParams).WithOne(e => e.PropertyRatePlan).HasForeignKey(e => e.RatePlanId);
            builder.HasMany(e => e.RatePlanService).WithOne(e => e.PropertyRatePlan).HasForeignKey(e => e.RatePlanId);
            builder.HasMany(e => e.TaxesRatePlans).WithOne(e => e.PropertyRatePlan).HasForeignKey(e => e.RatePlanId);
            builder.HasMany(e => e.AncillaryRatePlans).WithOne(e => e.PropertyRatePlan).HasForeignKey(e => e.RatePlanId);
            builder.HasMany(e => e.TermsConditionsRatePlans).WithOne(e => e.RatePlan).HasForeignKey(e => e.RatePlanId);

        }
    }
}
