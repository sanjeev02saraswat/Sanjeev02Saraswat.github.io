﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class PropertyRatePlanParamsConfiguration : IEntityTypeConfiguration<PropertyRatePlanParamsModel>
    {
        public void Configure(EntityTypeBuilder<PropertyRatePlanParamsModel> builder)
        {
            builder.HasKey(e => e.RatePlanParamId);
            builder.Property(e => e.RatePlanId).IsRequired();
            builder.Property(e => e.ParamKey).IsRequired();
            builder.Property(e => e.Values);
        }
    }
}
