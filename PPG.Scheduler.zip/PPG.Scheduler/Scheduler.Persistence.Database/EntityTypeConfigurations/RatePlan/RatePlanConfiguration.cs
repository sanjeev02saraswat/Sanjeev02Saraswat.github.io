﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class RatePlanConfiguration : IEntityTypeConfiguration<RatePlanModel>
    {
        public void Configure(EntityTypeBuilder<RatePlanModel> builder)
        {
            builder.HasKey(e => e.RatePlanId);
            builder.Property(e => e.PropertyId).IsRequired();
        }
    }
}
