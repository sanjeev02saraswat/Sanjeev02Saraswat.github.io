﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class RoomClassConfiguration : IEntityTypeConfiguration<RoomClassModel>
    {
        public void Configure(EntityTypeBuilder<RoomClassModel> builder)
        {
            builder.HasKey(e => e.RoomClassId);
            builder.Property(e => e.ServiceTypesString);
            builder.Property(e => e.RoomClassName);
        }
    }
}
