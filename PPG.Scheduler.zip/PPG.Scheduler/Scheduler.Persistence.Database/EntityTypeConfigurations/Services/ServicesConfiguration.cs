﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class ServicesConfiguration : IEntityTypeConfiguration<ServiceModel>
    {
        public void Configure(EntityTypeBuilder<ServiceModel> builder)
        {
            builder.HasKey(e => e.ServiceId);
            builder.Property(e => e.PropertyId).IsRequired();
            builder.Property(e => e.ServiceName).HasMaxLength(50).IsRequired();
            builder.Property(e => e.Timing).HasMaxLength(50);
            builder.Property(e => e.ServiceTypeString).IsRequired();
            builder.Property(e => e.ShortDescription).HasMaxLength(300).IsRequired();
            builder.Property(e => e.WASServiceId);

            builder.HasMany(e => e.ServiceParams).WithOne(e => e.Service).HasForeignKey(e => e.ServiceId);
            builder.HasMany(e => e.ServiceRatePlans).WithOne(e => e.Service).HasForeignKey(e => e.ServiceId);
            builder.HasMany(e => e.InvAvailable).WithOne(e => e.Service).HasForeignKey(e => e.ServiceId);
            builder.HasMany(e => e.InvPrice).WithOne(e => e.Service).HasForeignKey(e => e.ServiceId);
        }
    }
}
