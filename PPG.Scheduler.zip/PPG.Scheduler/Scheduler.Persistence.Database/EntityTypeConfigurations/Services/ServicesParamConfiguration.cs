﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    class ServicesParamConfiguration : IEntityTypeConfiguration<ServiceParamModel>
    {
        public void Configure(EntityTypeBuilder<ServiceParamModel> builder)
        {
            builder.HasKey(e => e.ServiceParamId);
            builder.Property(e => e.ServiceId).IsRequired();
            builder.Property(e => e.KeyString).IsRequired();
            builder.Property(e => e.Value).IsRequired();
        }
    }
}
