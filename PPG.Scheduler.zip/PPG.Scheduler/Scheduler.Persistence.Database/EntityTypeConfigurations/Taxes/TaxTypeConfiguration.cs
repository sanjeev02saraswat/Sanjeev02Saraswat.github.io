﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class TaxTypeConfiguration : IEntityTypeConfiguration<TaxTypeModel>
    {
        public void Configure(EntityTypeBuilder<TaxTypeModel> builder)
        {
            builder.HasKey(e => e.TaxTypeID);
            builder.Property(e => e.TaxTypeName);
           
        }
    }
}
