﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class TaxesConfiguration : IEntityTypeConfiguration<TaxesModel>
    {
        public void Configure(EntityTypeBuilder<TaxesModel> builder)
        {
            builder.HasKey(e => e.TaxId);
            builder.Property(e => e.TaxType);
            builder.Property(e => e.PropertyId);
            builder.Property(e => e.Value);
            builder.Property(e => e.ValueType);
            builder.Property(e => e.Currency);

            builder.HasMany(e => e.TaxesRatePlans).WithOne(e => e.Taxes).HasForeignKey(e => e.TaxId);
        }
    }
}
