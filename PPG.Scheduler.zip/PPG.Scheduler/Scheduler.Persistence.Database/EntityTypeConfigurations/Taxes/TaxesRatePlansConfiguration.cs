﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class TaxesRatePlansConfiguration : IEntityTypeConfiguration<TaxesRatePlansModel>
    {
        public void Configure(EntityTypeBuilder<TaxesRatePlansModel> builder)
        {
            builder.HasKey(e => e.TaxParamId);
            builder.Property(e => e.TaxId);
            builder.Property(e => e.RatePlanId);
            builder.Property(e => e.BasedOnString);
            builder.Property(e => e.ConfiguredPrice);
            builder.Property(e => e.StayString);
            builder.Property(e => e.PriceOnString);
        }
    }
}