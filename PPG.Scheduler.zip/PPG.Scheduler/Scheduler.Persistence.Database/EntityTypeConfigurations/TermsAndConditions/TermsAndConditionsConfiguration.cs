﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database
{
    public sealed class TermsAndConditionsConfiguration : IEntityTypeConfiguration<TermsandConditionsModel>
    {
        public void Configure(EntityTypeBuilder<TermsandConditionsModel> builder)
        {            
            builder.HasKey(x => x.TermsId);
            builder.Property(x => x.PropertyId);
            builder.Property(x => x.Name).IsRequired().HasMaxLength(50);
            builder.Property(x => x.Descriptions).IsRequired().HasMaxLength(1024);           
            builder.HasMany(e => e.LinkedRatePlans).WithOne(e => e.TermsAndConditions).HasForeignKey(e =>e.TermsId);

        }
    }
}
