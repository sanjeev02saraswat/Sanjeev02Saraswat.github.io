﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database
{
    public sealed class TermsAndConditionsLinkedRatesConfiguration : IEntityTypeConfiguration<TermsandConditionsLinkedRateModel>
    {
        public void Configure(EntityTypeBuilder<TermsandConditionsLinkedRateModel> builder)
        {            
            builder.HasKey(x => x.TermsLinkedRateId);
            builder.Property(e => e.TermsId);
            builder.Property(e => e.RatePlanId);
            
        }
    }
}
