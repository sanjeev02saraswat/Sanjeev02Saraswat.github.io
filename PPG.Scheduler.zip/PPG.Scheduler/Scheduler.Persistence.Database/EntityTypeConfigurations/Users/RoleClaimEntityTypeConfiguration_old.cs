﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database
{
    public sealed class RoleClaimEntityTypeConfiguration_old : IEntityTypeConfiguration<RoleClaimModel>
    {
        public void Configure(EntityTypeBuilder<RoleClaimModel> builder)
        {
            builder.HasKey(x => x.RoleClaimId);

            builder.Property(x => x.RolesId).IsRequired();
            builder.Property(x => x.ClaimTypeId).IsRequired();
            builder.Property(x => x.RoleClaimId).IsRequired().ValueGeneratedOnAdd();
            //builder.Property(x => x.Value);

            //builder.HasOne(x => x.User).WithMany(x => x.UsersClaims).HasForeignKey(x => (x.RolesId));
        }
    }
}
