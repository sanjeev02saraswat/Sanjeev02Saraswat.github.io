﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database
{
    public sealed class UserEntityTypeConfiguration : IEntityTypeConfiguration<UserModel>
    {
        public void Configure(EntityTypeBuilder<UserModel> builder)
        {
            //builder.ToTable("Users", "aerotel");

            builder.HasKey(x => x.UserId);

            builder.HasIndex(x => x.Email).IsUnique();
            builder.HasIndex(x => x.Login).IsUnique();

            builder.HasIndex(x => x.Email);
            builder.HasIndex(x => x.Login);

            builder.Property(x => x.Email).IsRequired().HasMaxLength(300);
            builder.Property(x => x.Login).IsRequired().HasMaxLength(100);
            builder.Property(x => x.Name).IsRequired().HasMaxLength(100);
            builder.Property(x => x.Password).IsRequired().HasMaxLength(500);
            builder.Property(x => x.Status).IsRequired();
            builder.Property(x => x.Surname).IsRequired().HasMaxLength(200);
            builder.Property(x => x.UserId).IsRequired().ValueGeneratedOnAdd();
            builder.Property(x => x.Role).IsRequired();
            builder.Property(x => x.CreatedOn).IsRequired();
            builder.Property(x => x.LastUpdated);
            builder.Property(x => x.PasswordExpiryDate);
            builder.Property(x => x.LoginAttempt);
            builder.Property(x => x.TempPassword);
            //c.DateTime(defaultValueSql: "GETDATE()")

            builder.HasMany(x => x.UsersLogs).WithOne(x => x.User).HasForeignKey(x => x.UserId);
            //builder.HasMany(x => x.UsersClaims).WithOne(x => x.User).HasForeignKey(x => x.RolesId);
            //builder.HasMany(x => x.UsersRoles).WithOne(x => x.User).HasForeignKey(x => x.UserId);
        }
    }
}
