﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Scheduler.Persistence.Database.EntityTypeConfigurations
{
    public class UserLogParamEntityTypeConfiguration : IEntityTypeConfiguration<UserLogParamModel>
    {
        public void Configure(EntityTypeBuilder<UserLogParamModel> builder)
        {
            builder.HasKey(e => e.UserLogParamId);
           // builder.Property(e => e.PropertyId);
            builder.Property(e => e.UserLogId).IsRequired();
            builder.Property(e => e.Key).IsRequired();
            builder.Property(e => e.Values).IsRequired();
        }
    }

    
}
