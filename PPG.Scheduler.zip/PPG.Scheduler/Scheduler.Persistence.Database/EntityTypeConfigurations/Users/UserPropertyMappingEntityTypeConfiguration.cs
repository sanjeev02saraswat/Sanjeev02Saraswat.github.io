﻿using Scheduler.CrossCutting.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database
{
    public sealed class UserPropertyMappingEntityTypeConfiguration : IEntityTypeConfiguration<UserPropertyMappingModel>
    {
        public void Configure(EntityTypeBuilder<UserPropertyMappingModel> builder)
        {
            builder.HasKey(x => x.UserPropertyMappingId);
            builder.Property(x => x.UserId).IsRequired();
            builder.Property(x => x.PropertyId).IsRequired();
            builder.Property(x => x.UserPropertyMappingId).IsRequired().ValueGeneratedOnAdd();
        }
    }
}
