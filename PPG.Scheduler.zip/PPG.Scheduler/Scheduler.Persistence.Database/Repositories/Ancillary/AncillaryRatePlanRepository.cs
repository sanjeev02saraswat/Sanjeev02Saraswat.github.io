﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Scheduler.CrossCutting.Utils;

 namespace Scheduler.Persistence.Database.Repositories
    {
  public class AncillaryRatePlanRepository : EntityFrameworkCoreRepository<AncillaryRatePlanModel>,IAncillaryRatePlanRepository
    {
        public AncillaryRatePlanRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }


    }
}
