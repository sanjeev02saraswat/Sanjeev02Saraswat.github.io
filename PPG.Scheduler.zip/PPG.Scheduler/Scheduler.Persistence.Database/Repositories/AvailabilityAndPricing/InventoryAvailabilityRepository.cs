﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.Repositories
{
    public class InventoryAvailabilityRepository : EntityFrameworkCoreRepository<AvailabilityModel>, IInventoryAvailabilityRepository
    {
        public InventoryAvailabilityRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
