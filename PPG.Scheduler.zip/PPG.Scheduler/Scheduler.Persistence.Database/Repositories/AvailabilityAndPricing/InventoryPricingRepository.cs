﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public class InventoryPricingRepository : EntityFrameworkCoreRepository<InventoryPriceModel>, IInventoryPricingRepository
    {
        public InventoryPricingRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
