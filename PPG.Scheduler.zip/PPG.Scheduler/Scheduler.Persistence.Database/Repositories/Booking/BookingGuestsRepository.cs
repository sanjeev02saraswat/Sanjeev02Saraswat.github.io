﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database.Repositories
{
    public class BookingGuestsRepository : EntityFrameworkCoreRepository<BookingGuestsModel>, IBookingGuestsRepository
    {
        public BookingGuestsRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
