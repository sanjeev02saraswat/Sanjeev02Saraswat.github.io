﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public class InventoryRuleRepository : EntityFrameworkCoreRepository<ChannelInventoryRuleModel>, IInventoryRuleRepository
    {
        public InventoryRuleRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
