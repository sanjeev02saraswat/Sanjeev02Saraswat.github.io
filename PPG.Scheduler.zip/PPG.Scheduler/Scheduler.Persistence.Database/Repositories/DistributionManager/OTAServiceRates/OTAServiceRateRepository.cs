﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Scheduler.CrossCutting.Utils;


namespace Scheduler.Persistence.Database.Repositories
{
public  class OTAServiceRateRepository : EntityFrameworkCoreRepository<OTAServiceRateModel>, IOTAServiceRateRepository
    {
        public OTAServiceRateRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
