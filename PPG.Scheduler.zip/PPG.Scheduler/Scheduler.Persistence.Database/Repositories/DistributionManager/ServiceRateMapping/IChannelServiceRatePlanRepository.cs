﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Scheduler.CrossCutting.Utils;


namespace Scheduler.Persistence.Database.Repositories
{
  public interface IChannelServiceRateRepository : IRepository<ChannelServiceRateMappingModel>
    {
    }
}
