﻿using Scheduler.CrossCutting.Models;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.CrossCutting.Utils;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scheduler.Persistence.Database
{
    public interface IPropertyRepository : IRepository<PropertyModel>
    {
       
    }
}
