﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database
{
    public class PropertyRepository : EntityFrameworkCoreRepository<PropertyModel>, IPropertyRepository
    {
        public PropertyRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
