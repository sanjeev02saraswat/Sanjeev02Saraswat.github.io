﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.CrossCutting.Utils;

namespace Scheduler.Persistence.Database.Repositories
{
    public interface IRatePlanRepository : IRepository<PropertyRatePlanModel>
    {
    }
}
