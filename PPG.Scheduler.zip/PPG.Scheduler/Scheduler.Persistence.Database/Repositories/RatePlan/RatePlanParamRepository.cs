﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories.RatePlan
{
    public class RatePlanParamRepository : EntityFrameworkCoreRepository<PropertyRatePlanParamsModel>, IRatePlanParamRepository
    {
        public RatePlanParamRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
