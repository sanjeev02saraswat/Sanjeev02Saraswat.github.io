﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories.RatePlan
{
    public class RatePlanServiceRepository : EntityFrameworkCoreRepository<PropertyRatePlanServiceModel>, IRatePlanServiceRepository
    {
        public RatePlanServiceRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
