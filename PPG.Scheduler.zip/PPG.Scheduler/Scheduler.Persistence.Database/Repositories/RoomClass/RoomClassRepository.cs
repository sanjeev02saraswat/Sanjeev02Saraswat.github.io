﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public class RoomClassRepository : EntityFrameworkCoreRepository<RoomClassModel>, IRoomClassRepository
    {
        public RoomClassRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
