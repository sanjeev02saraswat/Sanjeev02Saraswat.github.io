﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database
{
    public class ServiceRepository : EntityFrameworkCoreRepository<ServiceModel>, IServiceRepository
    {
        public ServiceRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
