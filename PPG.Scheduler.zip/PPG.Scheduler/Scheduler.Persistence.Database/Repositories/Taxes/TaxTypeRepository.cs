﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.CrossCutting.Utils;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
 public class TaxTypeRepository :  EntityFrameworkCoreRepository<TaxTypeModel>, ITaxTypeRepository
    {

        public TaxTypeRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
