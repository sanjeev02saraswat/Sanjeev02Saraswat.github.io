﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.CrossCutting.Utils;
using Scheduler.Persistence.EntityFrameworkCore;
using System.Linq;
using Scheduler.Persistence.Database.Repositories;
using Scheduler.Persistence.Database.Context;

namespace Scheduler.Persistence.Database.Repositories
{
    public class TaxesRatePlansRepository : EntityFrameworkCoreRepository<TaxesRatePlansModel>, ITaxesRatePlansRepository
    {
        public TaxesRatePlansRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
