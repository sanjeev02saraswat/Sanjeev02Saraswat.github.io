﻿using System;
using System.Collections.Generic;
using System.Text;
using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using System.Linq;


namespace Scheduler.Persistence.Database.Repositories
{
  public class TaxesRepository : EntityFrameworkCoreRepository<TaxesModel>, ITaxesRepository
    {
        public TaxesRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
