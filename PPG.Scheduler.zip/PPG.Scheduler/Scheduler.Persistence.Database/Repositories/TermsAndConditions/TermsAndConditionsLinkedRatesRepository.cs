﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public sealed class TermsAndConditionsLinkedRatesRepository : EntityFrameworkCoreRepository<TermsandConditionsLinkedRateModel>, ITermsAndConditionsLinkedRatesRepository
    {
        public TermsAndConditionsLinkedRatesRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {
        }
    }
}
