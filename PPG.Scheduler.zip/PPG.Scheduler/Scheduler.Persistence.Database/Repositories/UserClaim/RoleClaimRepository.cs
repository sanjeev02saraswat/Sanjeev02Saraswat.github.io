﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public sealed class RoleClaimRepository : EntityFrameworkCoreRepository<RoleClaimModel>, IRoleClaimRepository
    {
        public RoleClaimRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {

        }
    }
}
