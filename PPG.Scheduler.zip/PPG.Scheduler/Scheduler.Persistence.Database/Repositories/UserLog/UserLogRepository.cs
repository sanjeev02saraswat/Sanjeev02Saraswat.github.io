﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public sealed class UserLogRepository : EntityFrameworkCoreRepository<UserLogModel>, IUserLogRepository
    {
        public UserLogRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {
        }
    }
}
