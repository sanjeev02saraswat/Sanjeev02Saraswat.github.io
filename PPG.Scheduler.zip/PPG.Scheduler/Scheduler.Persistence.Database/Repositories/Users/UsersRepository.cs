﻿using Scheduler.CrossCutting.Models.Entities;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Scheduler.Persistence.Database.Repositories
{
    public sealed class UsersRepository : EntityFrameworkCoreRepository<UserModel>, IUsersRepository
    {
        public UsersRepository(DatabaseReadContext contextRead, DatabaseContext contextWrite) : base(contextRead, contextWrite)
        {
        }
    }
}
