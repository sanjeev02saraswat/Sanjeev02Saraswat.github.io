﻿using Scheduler.Persistence.Database;
using Scheduler.Persistence.Database.Context;
using Scheduler.Persistence.Database.Repositories;

namespace Scheduler.Persistence.Database.UnitOfWork
{
    public sealed class DatabaseUnitOfWork : IDatabaseUnitOfWork
    {
        public DatabaseUnitOfWork
            (
               IUserPropertyMappingRepository userPropertyMapping,
               IUserLogRepository userLog,
               IPropertyRepository property,
               IRoleClaimRepository roleClaim,
               IServiceRepository service,
               IAncillaryRepositary ancillary,
               IRoomClassRepository roomClass,
               ITaxesRepository taxes,
               ITaxesRatePlansRepository taxesParam,
               IRatePlanRepository ratePlan,
               IRatePlanParamRepository ratePlanParam,
               IInventoryPricingRepository inventoryPricing,
               IInventoryAvailabilityRepository inventoryAvailability,
               IAncillaryRatePlanRepository ancillaryRatePlan,
               IChannelRepository channel,
               ITaxTypeRepository taxType,
               ITermsAndConditionsRepository termsAndConditions,
               IInventoryRuleRepository channelInventoryRule,
               IOTAServiceRateRepository oTAServiceRateRepository,
               IChannelServiceRateRepository channelServiceRateMapping,
               ITermsAndConditionsLinkedRatesRepository termsAndConditionsLinkedRates,
               IBookingsRepository bookings,
               IBookingServicesRepository bookingServices,
               IBookingAncillaryRepository bookingAncillary,
               IBookingGuestsRepository bookingGuests,
               DatabaseContext context,
               IRatePlanServiceRepository ratePlanService,
               IBookingBackgroundProcessRepository bookingBackgroundProcess,
                ICampaignRepository campaigns,
               IPromoCodeRepository promoCodes,
               IUsersRepository users
            )
        {
            UserPropertyMapping = userPropertyMapping;
            UserLog = userLog;
            RoleClaim = roleClaim;
            Property = property;
            Service = service;
            Ancillary = ancillary;
            Taxes = taxes;
            RoomClass = roomClass;
            RatePlan = ratePlan;
            RatePlanParam = ratePlanParam;
            InventoryAvailability = inventoryAvailability;
            InventoryPricing = inventoryPricing;
            AncillaryRatePlan = ancillaryRatePlan;
            Channel = channel;

            TaxesParam = taxesParam;
            TermsAndConditions = termsAndConditions;
            ChannelInventoryRule = channelInventoryRule;
            ChannelServiceRateMapping = channelServiceRateMapping;

            Bookings = bookings;
            BookingServices = bookingServices;
            BookingAncillary = bookingAncillary;
            BookingGuests = bookingGuests;
            BookingBackgroundProcess = bookingBackgroundProcess;

            Context = context;
            OTAServiceRateMapping = oTAServiceRateRepository;
            TermsAndConditionsLinkedRates = termsAndConditionsLinkedRates;
            RatePlanService = ratePlanService;

            Campaigns = campaigns;
            PromoCodes = promoCodes;
            Users = users;
        }
        DatabaseContext Context { get; set; }
        public IUserPropertyMappingRepository UserPropertyMapping { get; }
        public IUserLogRepository UserLog { get; }
        public IRoleClaimRepository RoleClaim { get; }
        public IPropertyRepository Property { get; }
        public IServiceRepository Service { get; }
        public IAncillaryRepositary Ancillary { get; }
        public ITaxesRepository Taxes { get; }
        public ITaxesRatePlansRepository TaxesParam { get; }
        public IRatePlanRepository RatePlan { get; }
        public IRatePlanParamRepository RatePlanParam { get; }
        public IInventoryPricingRepository InventoryPricing { get; }
        public IInventoryAvailabilityRepository InventoryAvailability { get; }
        public IAncillaryRatePlanRepository AncillaryRatePlan { get; }
        public IChannelRepository Channel { get; }
        public IRoomClassRepository RoomClass { get; }
        public ITaxTypeRepository TaxType { get; }
        public ITermsAndConditionsRepository TermsAndConditions { get; }
        public IInventoryRuleRepository ChannelInventoryRule { get; }
        public IOTAServiceRateRepository OTAServiceRateMapping { get; }
        public IChannelServiceRateRepository ChannelServiceRateMapping { get; }
        public IBookingsRepository Bookings { get; }
        public IBookingServicesRepository BookingServices { get; }
        public IBookingGuestsRepository BookingGuests { get; }
        public IBookingAncillaryRepository BookingAncillary { get; }
        public ITermsAndConditionsLinkedRatesRepository TermsAndConditionsLinkedRates { get; }
        public IRatePlanServiceRepository RatePlanService { get; }
        public IBookingBackgroundProcessRepository BookingBackgroundProcess { get; }
        public ICampaignRepository Campaigns { get; }
        public IPromoCodeRepository PromoCodes { get; }

        public IUsersRepository Users { get; }
        public void DiscardChanges()
        {
            if (Context == null)
            {
                return;
            }

            Context.Dispose();
            Context = null;
        }

        public void SaveChanges()
        {
            Context.SaveChanges();
        }
    }
}
