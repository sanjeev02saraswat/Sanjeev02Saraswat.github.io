﻿using Scheduler.Persistence.Database.Repositories;

namespace Scheduler.Persistence.Database.UnitOfWork
{
    public interface IDatabaseUnitOfWork
    {        
        //IUserPropertyMappingRepository UserPropertyMapping { get; }
        //IUserLogRepository UserLog { get; }
        //IRoleClaimRepository RoleClaim { get; }
        //IPropertyRepository Property { get; }
        IServiceRepository Service { get; }
        //IAncillaryRepositary Ancillary { get; }
        IRatePlanRepository RatePlan { get; }
        //IRatePlanParamRepository RatePlanParam { get; }
        //ITaxesRepository Taxes { get; }
        ITaxesRatePlansRepository TaxesParam { get; }
        //IRoomClassRepository RoomClass { get; }
        //IInventoryPricingRepository InventoryPricing { get; }
        IInventoryAvailabilityRepository InventoryAvailability { get; }
        //IAncillaryRatePlanRepository AncillaryRatePlan { get; }
        //IChannelRepository Channel { get; }
        //ITaxTypeRepository TaxType { get; }
        //ITermsAndConditionsRepository TermsAndConditions { get; }
        //ITermsAndConditionsLinkedRatesRepository TermsAndConditionsLinkedRates { get; }
        //IInventoryRuleRepository ChannelInventoryRule { get; }
        //IOTAServiceRateRepository OTAServiceRateMapping { get; }
        //IChannelServiceRateRepository ChannelServiceRateMapping { get; }
        IBookingsRepository Bookings { get; }

        //IBookingServicesRepository and IBookingGuestsRepository were uncommented by saurabh to use in BookingReport Automation Task
        IBookingServicesRepository BookingServices { get; }
        IBookingGuestsRepository BookingGuests { get; }
        //IBookingAncillaryRepository BookingAncillary { get; }

        //IRatePlanServiceRepository RatePlanService { get; }

        ICampaignRepository Campaigns { get; }
        IPromoCodeRepository PromoCodes { get; }

        IBookingBackgroundProcessRepository BookingBackgroundProcess { get; }
        IUsersRepository Users { get; }
        void DiscardChanges();
        void SaveChanges();
    }
}
